<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Writer {

	function __construct()
	{
		$this->CI =& get_instance();
		$this->CI->load->model('apps_model');
		$this->CI->load->model('template_model');
		$this->CI->load->model('settings_model');
		$this->CI->load->model('icons_model');
	}

	/*
	 * Create zip for Phonegap build
	 * @param int $app_id
	 */
	function preparation_zip($app_id)
	{
		$app = $this->CI->apps_model->get_app($app_id);

		// Create hash
		$date = date('Y-m-d H:i:s');
		$value_1 = rand(0000000000, 5555555555);
		$hash = hash('sha256', $date."-".$value_1);

		$source = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www';
		$destination = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/'.$hash.'.zip';

		$zip = new ZipArchive();
	    if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
	        return false;
	    }

	    $source = str_replace('\\', '/', realpath($source));

	    if (is_dir($source) === true)
	    {
	        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source), RecursiveIteratorIterator::SELF_FIRST);

	        foreach ($files as $file)
	        {
	            $file = str_replace('\\', '/', $file);

	            // Ignore "." and ".." folders
	            if( in_array(substr($file, strrpos($file, '/')+1), array('.', '..')) )
	                continue;

	            $file = realpath($file);

	            if (is_dir($file) === true)
	            {
	                $zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
	            }
	            else if (is_file($file) === true)
	            {
	                $zip->addFromString(str_replace($source . '/', '', $file), file_get_contents($file));
	            }
	        }
	    }
	    else if (is_file($source) === true)
	    {
	        $zip->addFromString(basename($source), file_get_contents($source));
	    }

	    $zip->close();

	    if (file_exists($destination)) {

	    	return $destination;

	    } else {

	    	return 0;

	    }

	}

	/*
	 * Create directore for template
	 * @param string $path
	 */
	function create_path_template($path)
	{
		if (!mkdir(''.$_SERVER['DOCUMENT_ROOT'].'/templates/'.$path.'', 0755, true)) {

			return 0;

		} else {

			return 1;

		}
	}

	/*
	 * Create config file for Phonegap build
	 * @param int $app_id
	 */
	function create_config_app($app_id)
	{
		$app = $this->CI->apps_model->get_app($app_id);

		if ($app) {

			$setting = $this->CI->settings_model->get_settings($app->id);

			$icon = $this->CI->icons_model->get_icons($app->id);

			if (!$app->type) {

				$content = "<?xml version='1.0' encoding='UTF-8' ?>
					<widget xmlns   = 'http://www.w3.org/ns/widgets'
					    xmlns:gap   = 'http://phonegap.com/ns/1.0'
					    id          = '".$app->app_id."'
					    versionCode = '10'
					    version     = '".$app->version."' >

					<name>".$app->name."</name>

					<description>
					    ".$app->description_app."
					</description>

					<author>".$app->author."</author>

					<gap:plugin name='onesignal-cordova-plugin' spec='2.4.5' source='npm' />

	  				<plugin name='cordova-plugin-splashscreen' />

	  				<preference name='windows-appx-target' value='8.1-win' />

	  				<preference name='phonegap-version' value='cli-8.0.0' />

					<preference name='android-build-tool' value='gradle' />
					<preference name='android-minSdkVersion' value='16' />
					<preference name='orientation' value='portrait' />

					<preference name='windows-appx-target' value='8.1-phone' />
	  				<preference name='WindowsToastCapable' value='true' />
	          
	          		<preference name='SplashMaintainAspectRatio' value='true' />

	  				<platform name='android'>
					    <icon src='img/icon/android/".$icon->android."' />
					    <icon src='img/icon/android/".$icon->android_mdpi."' density='mdpi' />
					    <icon src='img/icon/android/".$icon->android_hdpi."' density='hdpi' />
					    <icon src='img/icon/android/".$icon->android_xhdpi."' density='xhdpi' />
					    <icon src='img/icon/android/".$icon->android_xxhdpi."' density='xxhdpi' />
					    <icon src='img/icon/android/".$icon->android_xxxhdpi."'  density='xxxhdpi' />

					    <splash src='img/screen/android/".$icon->android_screen_ldpi."' density='port-ldpi' />
					    <splash src='img/screen/android/".$icon->android_screen_mdpi."' density='port-mdpi' />
					    <splash src='img/screen/android/".$icon->android_screen_hdpi."' density='port-hdpi' />
					    <splash src='img/screen/android/".$icon->android_screen_xhdpi."' density='port-xhdpi' />
					    <splash src='img/screen/android/".$icon->android_screen_xxhdpi."' density='port-xxhdpi' />
					    <splash src='img/screen/android/".$icon->android_screen_xxxhdpi."' density='port-xxxhdpi' />

					    <allow-intent href='market:*'/>
					</platform>

					<platform name='ios'>
					    <icon src='img/icon/ios/".$icon->ios_icon_60_3x."' platform='ios' width='180' height='180' />

					    <icon src='img/icon/ios/".$icon->ios_icon_60."' platform='ios' width='60' height='60' />
					    <icon src='img/icon/ios/".$icon->ios_icon_60_2x."' platform='ios' width='120' height='120' />

					    <icon src='img/icon/ios/".$icon->ios_icon_76."' platform='ios' width='76' height='76' />
					    <icon src='img/icon/ios/".$icon->ios_icon_76_2x."' platform='ios' width='152' height='152' />
					    <icon src='img/icon/ios/".$icon->ios_icon_83_5_2x."' platform='ios' width='167' height='167' />

					    <icon src='img/icon/ios/".$icon->ios_icon_small."' platform='ios' width='29' height='29' />
					    <icon src='img/icon/ios/".$icon->ios_icon_small_2x."' platform='ios' width='58' height='58' />
					    <icon src='img/icon/ios/".$icon->ios_icon_small_3x."' platform='ios' width='87' height='87' />

					    <icon src='img/icon/ios/".$icon->ios_icon_40."' platform='ios' width='40' height='40' />
					    <icon src='img/icon/ios/".$icon->ios_icon_40_2x."' platform='ios' width='80' height='80' />
					    <icon src='img/icon/ios/".$icon->ios_icon_40_3x."' platform='ios' width='120' height='120' />

					    <icon src='img/icon/ios/".$icon->ios_icon."' platform='ios' width='57' height='57' />
					    <icon src='img/icon/ios/".$icon->ios_icon_2x."' platform='ios' width='114' height='114' />

					    <icon src='img/icon/ios/".$icon->ios_icon_72."' platform='ios' width='72' height='72' />
					    <icon src='img/icon/ios/".$icon->ios_icon_72_2x."' platform='ios' width='144' height='144' />

					    <icon src='img/icon/ios/".$icon->ios_icon_small."' platform='ios' width='29' height='29' />
					    <icon src='img/icon/ios/".$icon->ios_icon_small_2x."' platform='ios' width='58' height='58' />

					    <icon src='img/icon/ios/".$icon->ios_icon_50."' platform='ios' width='50' height='50' />
					    <icon src='img/icon/ios/".$icon->ios_icon_50_2x."' platform='ios' width='100' height='100' />
					    
					    <splash src='img/screen/ios/".$icon->ios_screen_default."' platform='ios' width='320' height='480' />
					    <splash src='img/screen/ios/".$icon->ios_screen_default_2."' platform='ios' width='640' height='960' />

					    <splash src='img/screen/ios/".$icon->ios_screen_iphone_5."' platform='ios' width='640' height='1136' />

					    <splash src='img/screen/ios/".$icon->ios_screen_667h."' platform='ios' width='750' height='1334' />
					    <splash src='img/screen/ios/".$icon->ios_screen_736h."' platform='ios' width='1242' height='2208' />

					    <splash src='img/screen/ios/".$icon->ios_screen_ipad."' platform='ios' width='768' height='1024' />

					    <splash src='img/screen/ios/".$icon->ios_screen_ipad_retina."' platform='ios' width='1536' height='2048' />

					    <allow-intent href='itms:*'/>
					    <allow-intent href='itms-apps:*'/>
					</platform>

					<access origin='*'/> 
					<plugin name='cordova-plugin-whitelist' />
					<allow-intent href='http://*/*'/>
					<allow-intent href='https://*/*'/>
					<allow-intent href='tel:*'/>
					<allow-intent href='sms:*'/>
					<allow-intent href='mailto:*'/>
					<allow-intent href='geo:*'/>
					</widget>
				";

			} else if ($app->type == 1) {

				$content = "<?xml version='1.0' encoding='UTF-8' ?>
					<widget xmlns   = 'http://www.w3.org/ns/widgets'
					    xmlns:gap   = 'http://phonegap.com/ns/1.0'
					    id          = '".$app->app_id."'
					    versionCode = '10'
					    version     = '".$app->version."' >

					<name>".$app->name."</name>

					<description>
					    ".$app->description_app."
					</description>

					<author>".$app->author."</author>

					<gap:plugin name='onesignal-cordova-plugin' spec='2.4.5' source='npm' />

	  				<plugin name='cordova-plugin-splashscreen' />

	  				<preference name='windows-appx-target' value='8.1-win' />

	  				<preference name='phonegap-version' value='cli-8.0.0' />

					<preference name='android-build-tool' value='gradle' />
					<preference name='android-minSdkVersion' value='16' />
					<preference name='orientation' value='portrait' />

					<preference name='windows-appx-target' value='8.1-phone' />
	  				<preference name='WindowsToastCapable' value='true' />
	          
	          		<preference name='SplashMaintainAspectRatio' value='true' />

	  				<platform name='android'>
					    <icon src='img/icon/android/".$icon->android."' />
					    <icon src='img/icon/android/".$icon->android_mdpi."' density='mdpi' />
					    <icon src='img/icon/android/".$icon->android_hdpi."' density='hdpi' />
					    <icon src='img/icon/android/".$icon->android_xhdpi."' density='xhdpi' />
					    <icon src='img/icon/android/".$icon->android_xxhdpi."' density='xxhdpi' />
					    <icon src='img/icon/android/".$icon->android_xxxhdpi."'  density='xxxhdpi' />

					    <splash src='img/screen/android/".$icon->android_screen_ldpi."' density='port-ldpi' />
					    <splash src='img/screen/android/".$icon->android_screen_mdpi."' density='port-mdpi' />
					    <splash src='img/screen/android/".$icon->android_screen_hdpi."' density='port-hdpi' />
					    <splash src='img/screen/android/".$icon->android_screen_xhdpi."' density='port-xhdpi' />
					    <splash src='img/screen/android/".$icon->android_screen_xxhdpi."' density='port-xxhdpi' />
					    <splash src='img/screen/android/".$icon->android_screen_xxxhdpi."' density='port-xxxhdpi' />

					    <allow-intent href='market:*'/>
					</platform>

					<platform name='ios'>
					    <icon src='img/icon/ios/".$icon->ios_icon_60_3x."' platform='ios' width='180' height='180' />

					    <icon src='img/icon/ios/".$icon->ios_icon_60."' platform='ios' width='60' height='60' />
					    <icon src='img/icon/ios/".$icon->ios_icon_60_2x."' platform='ios' width='120' height='120' />

					    <icon src='img/icon/ios/".$icon->ios_icon_76."' platform='ios' width='76' height='76' />
					    <icon src='img/icon/ios/".$icon->ios_icon_76_2x."' platform='ios' width='152' height='152' />
					    <icon src='img/icon/ios/".$icon->ios_icon_83_5_2x."' platform='ios' width='167' height='167' />

					    <icon src='img/icon/ios/".$icon->ios_icon_small."' platform='ios' width='29' height='29' />
					    <icon src='img/icon/ios/".$icon->ios_icon_small_2x."' platform='ios' width='58' height='58' />
					    <icon src='img/icon/ios/".$icon->ios_icon_small_3x."' platform='ios' width='87' height='87' />

					    <icon src='img/icon/ios/".$icon->ios_icon_40."' platform='ios' width='40' height='40' />
					    <icon src='img/icon/ios/".$icon->ios_icon_40_2x."' platform='ios' width='80' height='80' />
					    <icon src='img/icon/ios/".$icon->ios_icon_40_3x."' platform='ios' width='120' height='120' />

					    <icon src='img/icon/ios/".$icon->ios_icon."' platform='ios' width='57' height='57' />
					    <icon src='img/icon/ios/".$icon->ios_icon_2x."' platform='ios' width='114' height='114' />

					    <icon src='img/icon/ios/".$icon->ios_icon_72."' platform='ios' width='72' height='72' />
					    <icon src='img/icon/ios/".$icon->ios_icon_72_2x."' platform='ios' width='144' height='144' />

					    <icon src='img/icon/ios/".$icon->ios_icon_small."' platform='ios' width='29' height='29' />
					    <icon src='img/icon/ios/".$icon->ios_icon_small_2x."' platform='ios' width='58' height='58' />

					    <icon src='img/icon/ios/".$icon->ios_icon_50."' platform='ios' width='50' height='50' />
					    <icon src='img/icon/ios/".$icon->ios_icon_50_2x."' platform='ios' width='100' height='100' />
					    
					    <splash src='img/screen/ios/".$icon->ios_screen_default."' platform='ios' width='320' height='480' />
					    <splash src='img/screen/ios/".$icon->ios_screen_default_2."' platform='ios' width='640' height='960' />

					    <splash src='img/screen/ios/".$icon->ios_screen_iphone_5."' platform='ios' width='640' height='1136' />

					    <splash src='img/screen/ios/".$icon->ios_screen_667h."' platform='ios' width='750' height='1334' />
					    <splash src='img/screen/ios/".$icon->ios_screen_736h."' platform='ios' width='1242' height='2208' />

					    <splash src='img/screen/ios/".$icon->ios_screen_ipad."' platform='ios' width='768' height='1024' />

					    <splash src='img/screen/ios/".$icon->ios_screen_ipad_retina."' platform='ios' width='1536' height='2048' />

					    <allow-intent href='itms:*'/>
					    <allow-intent href='itms-apps:*'/>
					</platform>

					<access origin='*' browserOnly='true' subdomains='true' />

				    <content src='index.html' />

				    <allow-navigation href='".$app->source_path."' />

				    <plugin name='cordova-plugin-whitelist' source='npm' version='~1' />
				    <plugin name='cordova-plugin-inappbrowser' />

				    <preference name='permissions'                value='none'/>
				    <preference name='target-device'              value='universal'/>
				    <preference name='fullscreen'                 value='true'/>

				    </widget>

				";

			}

			$fp = fopen(''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app_id.'/www/config.xml',"wb");
			$checking = fwrite($fp,$content);
			fclose($fp);

			if ($checking) {

				$result = array('event' => 'success');

				return $result;

			} else {

				$result = array('event' => 'error', 'message' => 'File config.xml not created! Check folder permissions');

				return $result;

			}

		} else {

			$result = array('event' => 'error', 'message' => 'App not found!');

			return $result;

		}
	}

	/*
	 * Create index.js file for PUSH notifications
	 * @param int $app_id
	 */
	function create_index_js($app_id)
	{
		$app = $this->CI->apps_model->get_app($app_id);

		if ($app) {

			$settings = $this->CI->settings_model->get_settings($app->id);

			if ($settings->onesignal_api_key) {

				$content = "document.addEventListener('deviceready', function () {
					var notificationOpenedCallback = function(jsonData) {
						console.log('notificationOpenedCallback: ' + JSON.stringify(jsonData));
  					};

  					window.plugins.OneSignal
					    .startInit('".$settings->onesignal_api_key."')
					    .handleNotificationOpened(notificationOpenedCallback)
					    .endInit();
					}, false);
				";

				$fp = fopen(''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app_id.'/www/js/index.js',"wb");
				$checking = fwrite($fp,$content);
				fclose($fp);

				if ($checking) {

					$result = array('event' => 'success');

					return $result;

				} else {

					$result = array('event' => 'error', 'message' => 'File index.js not created! Check folder permissions');

					return $result;

				}

			} else {

				$content = "// API One Signal not connect";

				$fp = fopen(''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app_id.'/www/js/index.js',"wb");
				$checking = fwrite($fp,$content);
				fclose($fp);

				if ($checking) {

					$result = array('event' => 'success');

					return $result;

				} else {

					$result = array('event' => 'error', 'message' => 'File index.js not created! Check folder permissions');

					return $result;

				}

			}

		} else {

			$result = array('event' => 'error', 'message' => 'App not found!');

			return $result;

		}
	}

	/*
	 * Create zip for Phonegap build
	 * @param int $app_id, int $device
	 */
	function create_project($app_id, $device)
	{
		$app = $this->CI->apps_model->get_app($app_id);

		if ($app) {

			// check template
			$template = $this->CI->template_model->get_design_template($app->template);

			if ($template) {

				$template_root_path = ''.$_SERVER['DOCUMENT_ROOT'].'/templates/'.$template->path.'/index.html';

				// check empry template
				if (file_exists($template_root_path)) {

					// create project folder
					if (!mkdir(''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'', 0755, true)) {

					   	$result = array('event' => 'error', 'message' => 'Could not create application directory named '.$app->id.'!');

						return $result;

					} else {

						// create forlder "www" for project
						if (!mkdir(''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www', 0755, true)) {

							$result = array('event' => 'error', 'message' => 'Could not create application directory named "www"!');

							return $result;

						} else {

							// create forlder "local" for project
							if (!mkdir(''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/local', 0755, true)) {

								$result = array('event' => 'error', 'message' => 'Could not create application directory named "local"!');

								return $result;

							} else {

								$src = ''.$_SERVER['DOCUMENT_ROOT'].'/templates/'.$template->path.'';
								$dst = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www';

								// copy template file
								$this->recursive_copy($src, $dst);

								// create app.js file
								$appjs = $this->create_root_app($app->id, $template->id, $app->app_id, $device);

								if ($appjs) {

									$result = array('event' => 'success', 'message' => 'Success!');

									return $result;

								} else {

									$result = array('event' => 'error', 'message' => 'Could not create app.js file!');

									return $result;

								}

							}

						}

					}

				} else {

					$result = array('event' => 'error', 'message' => 'Index file for template not found! Check template path!');

					return $result;

				}

			} else {

				$result = array('event' => 'error', 'message' => 'Template not found!');

				return $result;

			}

		} else {

			$result = array('event' => 'error', 'message' => 'App not found!');

			return $result;

		}
	}

	/*
	 * Copy remplate files and folders
	 * @param string $src, string $dst
	 */
	private function recursive_copy($src,$dst) {

		$dir = opendir($src);

		@mkdir($dst);

		while(( $file = readdir($dir)) ) {

			if (( $file != '.' ) && ( $file != '..' )) {

				if ( is_dir($src . '/' . $file) ) {

					$this->recursive_copy($src .'/'. $file, $dst .'/'. $file);

				} else {

					copy($src .'/'. $file,$dst .'/'. $file);

				}

			}

		}

		closedir($dir);

	}

	/*
	 * Create app.js file for project
	 * @param string $src, string $dst
	 */
	private function create_root_app($app_id, $template, $app_data_id, $device) {

		$app = $this->CI->apps_model->get_app($app_id);

		if (!$app->type) {

			// rules create app.js file
			if ($device == 1) { // material theme

				$content = "
				var $$ = Dom7;

				var app_id = '".$app_id."';
				var api_link = '".base_url()."';
				var app = new Framework7({
				  id: '".$app_data_id."',
				  root: '#app',
				  theme: 'md',
				  data: function () {
				    return {
				      project: {
				        id: app_id,
				        api_link: api_link,
				      },
				    };
				  },
				  methods: {
				    helloWorld: function () {
				      app.dialog.alert('Hello World!');
				    },
				  },
				  routes: routes,
				  vi: {
				    placementId: '',
				  },
				});
				// Init/Create main view
				var mainView = app.views.create('.view-main', {
				  url: '/'
				});

				// Add statistic
				var userToken = localStorage.getItem('usertoken');

				// Check device
				if (app.device.ios) {
				  var device = 1;
				} else if (app.device.android) {
				  var device = 2;
				} else {
				  var device = 3;
				}

				app.request({
				  beforeSend: function (xhr) {
				    if (userToken) {
				      xhr.setRequestHeader('authorization', userToken);
				    }
				  },
				  url: api_link + 'api/app/add_statistic?app_id=' + app_id +'&device='+ device,
				  crossDomain: true,
				  method: 'GET',
				  success: function(response) {

				    var alertsNotify = JSON.parse(response);

				    //console.log(alertsNotify.count);

				    if (alertsNotify.event == 'success') {

				      var dialogs = app.dialog.create({
				        title: alertsNotify.alerts[0].name,
				        text: alertsNotify.alerts[0].message,
				        buttons: [
				          {
				            text: 'OK',
				            onClick: function(dialog, e) {
				              for (i = 1; i <= alertsNotify.count; i++) {
				                app.dialog.create({
				                  title: alertsNotify.alerts[i].name,
				                  text: alertsNotify.alerts[i].message,
				                  buttons: [
				                    {
				                      text: 'OK',
				                    }
				                  ],
				                }).open();
				              }
				            }
				          }
				        ],
				      }).open();

				    }

				  },
				  error: function (error) {

				    console.log('error');

				  },
				});
				var opened = 0;
				function exitApp(){
				  if (opened > 0) {
				    return false;
				  } else {
				    app.dialog.confirm('Are you sure you want to exit?', 'Exit App', 
				      function () {
				      navigator.app.exitApp();
				      },
				      function () {
				      opened = 0;  
				      return false;
				      }
				    );
				    opened = 1;
				  }
				}

				    
				function onBackKeyDown() {
				  // Handle the back button
				  if(app.views.main.history.length == 1){
				    exitApp();
				    e.preventDefault();
				  } else {
				    app.dialog.close();
				    app.views.main.router.back();
				    return false;
				  }
				}

				document.addEventListener('backbutton', onBackKeyDown, false);
				";

			} else if ($device == 2) { // iOS theme

				$content = "
				var $$ = Dom7;

				var app_id = '".$app_id."';
				var api_link = '".base_url()."';
				var app = new Framework7({
				  id: '".$app_data_id."',
				  root: '#app',
				  theme: 'ios',
				  data: function () {
				    return {
				      project: {
				        id: app_id,
				        api_link: api_link,
				      },
				    };
				  },
				  methods: {
				    helloWorld: function () {
				      app.dialog.alert('Hello World!');
				    },
				  },
				  routes: routes,
				  vi: {
				    placementId: '',
				  },
				});
				// Init/Create main view
				var mainView = app.views.create('.view-main', {
				  url: '/'
				});

				// Add statistic
				var userToken = localStorage.getItem('usertoken');

				// Check device
				if (app.device.ios) {
				  var device = 1;
				} else if (app.device.android) {
				  var device = 2;
				} else {
				  var device = 3;
				}

				app.request({
				  beforeSend: function (xhr) {
				    if (userToken) {
				      xhr.setRequestHeader('authorization', userToken);
				    }
				  },
				  url: api_link + 'api/app/add_statistic?app_id=' + app_id +'&device='+ device,
				  crossDomain: true,
				  method: 'GET',
				  success: function(response) {

				    var alertsNotify = JSON.parse(response);

				    //console.log(alertsNotify.count);

				    if (alertsNotify.event == 'success') {

				      var dialogs = app.dialog.create({
				        title: alertsNotify.alerts[0].name,
				        text: alertsNotify.alerts[0].message,
				        buttons: [
				          {
				            text: 'OK',
				            onClick: function(dialog, e) {
				              for (i = 1; i <= alertsNotify.count; i++) {
				                app.dialog.create({
				                  title: alertsNotify.alerts[i].name,
				                  text: alertsNotify.alerts[i].message,
				                  buttons: [
				                    {
				                      text: 'OK',
				                    }
				                  ],
				                }).open();
				              }
				            }
				          }
				        ],
				      }).open();

				    }

				  },
				  error: function (error) {

				    console.log('error');

				  },
				});
				var opened = 0;
				function exitApp(){
				  if (opened > 0) {
				    return false;
				  } else {
				    app.dialog.confirm('Are you sure you want to exit?', 'Exit App', 
				      function () {
				      navigator.app.exitApp();
				      },
				      function () {
				      opened = 0;  
				      return false;
				      }
				    );
				    opened = 1;
				  }
				}

				    
				function onBackKeyDown() {
				  // Handle the back button
				  if(app.views.main.history.length == 1){
				    exitApp();
				    e.preventDefault();
				  } else {
				    app.dialog.close();
				    app.views.main.router.back();
				    return false;
				  }
				}

				document.addEventListener('backbutton', onBackKeyDown, false);
				";

			} else if ($device == 3) { // Auto-detect Device (Material or iOS)

				$content = "
				var $$ = Dom7;

				var app_id = '".$app_id."';
				var api_link = '".base_url()."';
				// Theme
				var theme = 'auto';
				if (document.location.search.indexOf('theme=') >= 0) {
				  theme = document.location.search.split('theme=')[1].split('&')[0];
				}
				var app = new Framework7({
				  id: '".$app_data_id."',
				  root: '#app',
				  theme: theme,
				  data: function () {
				    return {
				      project: {
				        id: app_id,
				        api_link: api_link,
				      },
				    };
				  },
				  methods: {
				    helloWorld: function () {
				      app.dialog.alert('Hello World!');
				    },
				  },
				  routes: routes,
				  vi: {
				    placementId: '',
				  },
				});
				// Init/Create main view
				var mainView = app.views.create('.view-main', {
				  url: '/'
				});

				// Add statistic
				var userToken = localStorage.getItem('usertoken');

				// Check device
				if (app.device.ios) {
				  var device = 1;
				} else if (app.device.android) {
				  var device = 2;
				} else {
				  var device = 3;
				}

				app.request({
				  beforeSend: function (xhr) {
				    if (userToken) {
				      xhr.setRequestHeader('authorization', userToken);
				    }
				  },
				  url: api_link + 'api/app/add_statistic?app_id=' + app_id +'&device='+ device,
				  crossDomain: true,
				  method: 'GET',
				  success: function(response) {

				    var alertsNotify = JSON.parse(response);

				    //console.log(alertsNotify.count);

				    if (alertsNotify.event == 'success') {

				      var dialogs = app.dialog.create({
				        title: alertsNotify.alerts[0].name,
				        text: alertsNotify.alerts[0].message,
				        buttons: [
				          {
				            text: 'OK',
				            onClick: function(dialog, e) {
				              for (i = 1; i <= alertsNotify.count; i++) {
				                app.dialog.create({
				                  title: alertsNotify.alerts[i].name,
				                  text: alertsNotify.alerts[i].message,
				                  buttons: [
				                    {
				                      text: 'OK',
				                    }
				                  ],
				                }).open();
				              }
				            }
				          }
				        ],
				      }).open();

				    }

				  },
				  error: function (error) {

				    console.log('error');

				  },
				});
				var opened = 0;
				function exitApp(){
				  if (opened > 0) {
				    return false;
				  } else {
				    app.dialog.confirm('Are you sure you want to exit?', 'Exit App', 
				      function () {
				      navigator.app.exitApp();
				      },
				      function () {
				      opened = 0;  
				      return false;
				      }
				    );
				    opened = 1;
				  }
				}

				    
				function onBackKeyDown() {
				  // Handle the back button
				  if(app.views.main.history.length == 1){
				    exitApp();
				    e.preventDefault();
				  } else {
				    app.dialog.close();
				    app.views.main.router.back();
				    return false;
				  }
				}

				document.addEventListener('backbutton', onBackKeyDown, false);
				";

			}

		} else {

			$content = "
				var $$ = Dom7;

				var app_id = '".$app_id."';
				var api_link = '".base_url()."';
				// Theme
				var theme = 'auto';
				if (document.location.search.indexOf('theme=') >= 0) {
				  theme = document.location.search.split('theme=')[1].split('&')[0];
				}
				var app = new Framework7({
				  id: '".$app_data_id."',
				  root: '#app',
				  theme: theme,
				  data: function () {
				    return {
				      project: {
				        id: app_id,
				        api_link: api_link,
				      },
				    };
				  },
				  methods: {
				    helloWorld: function () {
				      app.dialog.alert('Hello World!');
				    },
				  },
				  routes: routes,
				  vi: {
				    placementId: '',
				  },
				});
				// Init/Create main view

				// Add statistic
				var userToken = localStorage.getItem('usertoken');

				// Check device
				if (app.device.ios) {
				  var device = 1;
				} else if (app.device.android) {
				  var device = 2;
				} else {
				  var device = 3;
				}

				app.request({
				  beforeSend: function (xhr) {
				    if (userToken) {
				      xhr.setRequestHeader('authorization', userToken);
				    }
				  },
				  url: api_link + 'api/app/add_statistic?app_id=' + app_id +'&device='+ device,
				  crossDomain: true,
				  method: 'GET',
				  success: function(response) {

				    var alertsNotify = JSON.parse(response);

				    //console.log(alertsNotify.count);

				    if (alertsNotify.event == 'success') {

				      

				    }

				  },
				  error: function (error) {

				    var dialogs = app.dialog.create({
				        title: 'No network connect',
				        text: 'Error network',
				    }).open();

				  },
				});
				var opened = 0;
				function exitApp(){
				  if (opened > 0) {
				    return false;
				  } else {
				    app.dialog.confirm('Are you sure you want to exit?', 'Exit App', 
				      function () {
				      navigator.app.exitApp();
				      },
				      function () {
				      opened = 0;  
				      return false;
				      }
				    );
				    opened = 1;
				  }
				}

				    
				function onBackKeyDown() {
				  // Handle the back button
				  if(app.views.main.history.length == 1){
				    exitApp();
				    e.preventDefault();
				  } else {
				    app.dialog.close();
				    app.views.main.router.back();
				    return false;
				  }
				}

				document.addEventListener('backbutton', onBackKeyDown, false);
				window.open('".$app->source_path."', '_self ', 'location=no,zoom=no');
				";

			$content_rout = "var routes = [  {
    						path: '/',
    						componentUrl: './pages/home.html',
    						},
    						];";
		}

		//$content = "some text here";
		$fp = fopen(''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app_id.'/www/js/app.js',"wb");
		$checking = fwrite($fp,$content);
		fclose($fp);

		if ($app->type) {

			$fp2 = fopen(''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app_id.'/www/js/routes.js',"wb");
			$checking2 = fwrite($fp2,$content_rout);
			fclose($fp2);

		}

		if (!$app->type) {

			if ($checking) {

				return 1;

			} else {

				return 0;

			}

		} else {

			if ($checking && $checking2) {

				return 1;

			} else {

				return 0;

			}

		}

	}
}