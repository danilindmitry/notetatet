<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Send_email {

	public function __construct() 
  	{
    	$this->CI =& get_instance();
    	$this->CI->load->model('apps_model');
    	$this->CI->load->model('settings_model');
  	}

  	/*
	 * Send email notifications
	 * @param int $app_id, string $email, string $title, string $message
	 */
	public function start_send($app_id, $email, $title, $message)
	{
		$CI =& get_instance();

		$settings = $this->CI->settings_model->get_settings($app_id);

		if ($settings) {

			if ($settings->mail_method == 1) { // CI sendmail

				$config = array(
		            'protocol'  => 'mail',
		            'charset'   => 'utf8',
		            'mailtype'  => 'html',
		            'wordwrap'  => 'true',
		        );

		        $CI->load->library('email', $config);

		        $CI->email->from($settings->cs_email, $settings->cs_sender);
		        $CI->email->to($email);

		        $CI->email->subject($title);
		        $CI->email->message($message);

		        $CI->email->send();

			} else if ($settings->mail_method == 2) { // SMTP

				$config = array(
		            'protocol'   => 'smtp',
		            'smtp_host'  => $settings->smtp_host,
		            'smtp_port'  => $settings->smtp_port,
		            'smtp_user'  => $settings->smtp_email,
		            'smtp_pass'  => $settings->smtp_password,
		            'charset'    => 'utf8',
		            'mailtype'   => 'html',
		            'wordwrap'   => 'true',
		        );

				$CI->load->library('email', $config);

				$CI->email->from($settings->smtp_email, $settings->smtp_sender);
		        $CI->email->to($email);

		        $CI->email->subject($title);
		        $CI->email->message($message);

		        $CI->email->send();

			}

		}

	}

}