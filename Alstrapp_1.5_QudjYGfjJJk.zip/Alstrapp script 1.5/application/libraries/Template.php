<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Template {

	private $CI;

  	var $template_data = array();
  
  	public function __construct() 
  	{
    	$this->CI =& get_instance();
    	$this->CI->load->model('users_model');
    	$this->CI->load->model('galleries_model');
    	$this->CI->load->model('posts_model');
    	$this->CI->load->model('comments_model');
    	$this->CI->load->model('forms_model');
    	$this->CI->load->model('messages_model');
    	$this->CI->load->model('navigation_model');
    	$this->CI->load->model('statistics_model');
    	$this->CI->load->model('builder_model');
    	$this->CI->load->model('template_model');
    	$this->CI->load->model('localization_model');
      $this->CI->load->model('icons_model');
  	}

  	function set($content_area, $value)
	{
	    $this->template_data[$content_area] = $value;
	}
  
	function load($template = '', $name ='', $view = '' , $view_data = array(), $return = FALSE)
	{
	   	$this->set($name, $this->CI->load->view($view, $view_data, TRUE));                       
	    $this->CI->load->view('layouts/'.$template, $this->template_data);
	}

	/*
	 * Get name group for users sort
	 * @param int $group_id
	 */
	function get_name_user_group($group_id)
	{
		if ($group_id == 0) {

			return 'No group';

		} else {

			$group = $this->CI->users_model->get_group($group_id);

	   		return $group->name;

		}

	}

	/*
	 * Get count users for group
	 * @param int $group_id
	 */
	function get_count_user_for_group($group_id)
	{
		$count = $this->CI->users_model->get_count_users_for_group($group_id);

		return $count;
	}

	/*
	 * Get count images for gallery
	 * @param int $gallery_id
	 */
	function get_count_images_for_gallery($gallery_id)
	{
		$count = $this->CI->galleries_model->get_count_images_for_gallery($gallery_id);

		return $count;
	}

	/*
	 * Get name categort for posts list
	 * @param int $group_id
	 */
	function get_name_post_category($category_id)
	{
		$category = $this->CI->posts_model->get_category($category_id);

		if ($category) {

			return $category->name;

		} else {

			return 'undefined';

		}

	}

	/*
	 * Get name post
	 * @param int $group_id
	 */
	function get_name_post($post_id)
	{
		$post = $this->CI->posts_model->get_post($post_id);

		if ($post) {

			return $post->name;

		} else {

			return 'undefined';

		}

	}

	/*
	 * Get count posts for category
	 * @param int $category_id
	 */
	function get_count_posts_for_category($category_id)
	{
		$count = $this->CI->posts_model->get_count_posts_for_category($category_id);

		return $count;
	}

	/*
	 * Get user avatar from Gravatar API
	 * @param int $user_id
	 */
	function get_user_avatar($user_id)
	{
		$user = $this->CI->users_model->get_user($user_id);

		if ($user) {

			$size = 80;

			$gravatar = "https://www.gravatar.com/avatar/".md5(strtolower(trim($user->email)))."&s=".$size;

        	return $gravatar;

		} else {

			return 'https://www.gravatar.com/avatar/97b1f054dfba771a7ee59fd3e45a64e7&s=80';

		}

	}

	/*
	 * Get user avatar from Gravatar API
	 * @param int $user_id
	 */
	function get_user_avatar_for_chat($user_id)
	{
		$user = $this->CI->users_model->get_user($user_id);

		if ($user) {

			$size = 80;

			$gravatar = "https://www.gravatar.com/avatar/".md5(strtolower(trim($user->email)))."&s=".$size;

        	return $gravatar;

		} else {

			return 'https://www.gravatar.com/avatar/97b1f054dfba771a7ee59fd3e45a64e7&s=80';

		}

	}

	/*
	 * Get user fullname
	 * @param int $user_id
	 */
	function get_user_fullname($user_id)
	{
		if ($user_id > 0) {

			$user = $this->CI->users_model->get_user($user_id);

			if ($user) {

				return ''.$user->first_name.' '.$user->last_name.'';

			} else {

				return 'unidentified';

			}

		} else {

			return 'Admin';

		}
	}

	/*
	 * Get user fullname for form
	 * @param int $user_id
	 */
	function get_user_fullname_for_form($user_id)
	{
		if ($user_id > 0) {

			$user = $this->CI->users_model->get_user($user_id);

			if ($user) {

				return ''.$user->first_name.' '.$user->last_name.'';

			} else {

				return 'unidentified';

			}

		} else {

			return 'Not registered';

		}
	}

	/*
	 * Get replyes for main comment
	 * @param int $app_id, int $post_id, int $reply_id
	 */
	function get_replyes($app_id, $post_id, $reply_id)
	{
		$replyes = $this->CI->comments_model->get_replyes_for_view($app_id, $post_id, $reply_id);

		return $replyes;
	}

	/*
	 * Get replyes for app
	 * @param int $app_id, int $post_id, int $reply_id
	 */
	function get_replyes_app($app_id, $post_id, $reply_id)
	{
		$replyes = $this->CI->comments_model->get_replyes_for_page($app_id, $post_id, $reply_id);

		return $replyes;
	}

	/*
	 * Get count unread form results
	 * @param int $form_id
	 */
	function get_count_unread_form_result($form_id)
	{
		$count = $this->CI->forms_model->get_count_unread_forms_received($form_id);

		return $count;
	}

	/*
	 * Get count all form results
	 * @param int $form_id
	 */
	function get_count_all_form_result($form_id)
	{
		$count = $this->CI->forms_model->get_count_all_forms_received($form_id);

		return $count;
	}

	/*
	 * Get count total messages for dialogue
	 * @param int $app_id, int $dialogue_id
	 */
	function get_count_total_messages_for_dialogue($app_id, $dialogue_id)
	{
		$count = $this->CI->messages_model->get_total_all_for_request($app_id, $dialogue_id);

		return $count;
	}

	/*
	 * Get last message and unred count for dialogue
	 * @param int $app_id, int $dialogue_id
	 */
	function get_last_messages_count($app_id, $dialogue_id)
	{
		$message = $this->CI->messages_model->get_dialogue_last_message($dialogue_id);

		if ($message) {

			$last_message = mb_strimwidth($message->message, 0, 80, " ...");

			$total_unread = $this->CI->messages_model->get_total_unread_for_request($app_id, $dialogue_id);

			if ($total_unread > 0) {

				return '<span class="badge badge-success mr-3">'.$total_unread.'</span><a href="'.base_url('my/apps/'.$app_id.'/messages/view/'.$dialogue_id.'').'">'.$last_message.'</a>';

			} else {

				return '<span class="badge badge-secondary mr-3">'.$total_unread.'</span><a href="'.base_url('my/apps/'.$app_id.'/messages/view/'.$dialogue_id.'').'">'.$last_message.'</a>';

			}

		} else {

			$old_message = $this->CI->messages_model->get_dialogue_old_message($dialogue_id);

			if ($old_message) {

				$last_message = mb_strimwidth($old_message->message, 0, 80, " ...");

				return '<span class="badge badge-secondary mr-3">0</span><a href="'.base_url('my/apps/'.$app_id.'/messages/view/'.$dialogue_id.'').'">'.$last_message.'</a>';

			} else {

				return '<span class="badge badge-secondary mr-3">0</span><a href="'.base_url('my/apps/'.$app_id.'/messages/view/'.$dialogue_id.'').'">No messages</a>';

			}

		}

	}

	/*
	 * Get id for menu item
	 * @param string $path
	 */
	function get_id_for_menu_item($path)
	{
		$id = explode("/", $path);

		return $id[2];
	}

	/*
	 * Get link for menu item
	 * @param int $item
	 */
	function get_link_for_menu_item($item)
	{
		$item = $this->CI->navigation_model->get_menu_detail($item);

		if ($item) {

			if ($item->path) {

				if ($item->type == 1) {

					return '<a href="'.$item->path.'" target="_blank">'.$item->path.'</a>';

				} else if ($item->type == 2) {

					$id = explode("/", $item->path);

					$category = $this->CI->posts_model->get_category($id[2]);

					if ($category) {

						return '<a href="'.base_url('my/apps/'.$item->app_id.'/posts/edit_category/'.$category->id.'').'">'.$category->name.'</a>';

					} else {

						return '<span class="text-danger">undefined</span>';

					}

				} else if ($item->type == 3) {

					$id = explode("/", $item->path);

					$post = $this->CI->posts_model->get_post($id[2]);

					if ($post) {

						return '<a href="'.base_url('my/apps/'.$item->app_id.'/posts/edit_post/'.$post->id.'').'">'.$post->name.'</a>';

					} else {

						return '<span class="text-danger">undefined</span>';

					}

				} else if ($item->type == 4) {

					$id = explode("/", $item->path);

					$gallery = $this->CI->galleries_model->get_gallery($id[2]);

					if ($gallery) {

						return '<a href="'.base_url('my/apps/'.$item->app_id.'/galleries/upload/'.$gallery->id.'').'">'.$gallery->name.'</a>';

					} else {

						return '<span class="text-danger">undefined</span>';

					}

				} else if ($item->type == 5) {

					$id = explode("/", $item->path);

					$form = $this->CI->forms_model->get_form($id[2]);

					if ($form) {

						return '<a href="'.base_url('my/apps/'.$item->app_id.'/forms/builder/'.$form->id.'').'">'.$form->name.'</a>';

					} else {

						return '<span class="text-danger">undefined</span>';

					}

				} else {

					return '<span class="text-danger">undefined</span>';

				}

			} else {

				return '<span class="text-danger">undefined</span>';

			}

		} else {

			return '<span class="text-danger">undefined</span>';

		}
	}

	/*
	 * Get items for statistics
	 * @param int $app_id, int $type, int $day, int $month, int $year
	 */
	function get_total_statistics_for_day($app_id, $type, $day, $month, $year)
	{
		$date = ''.$year.'-'.$month.'-'.$day.'';

		$total = $this->CI->statistics_model->get_total_for_day($app_id, $type, $date);

		return $total;
	}

	/*
	 * Get items for month statistics
	 * @param int $app_id, int $type, int $month, int $year
	 */
	function get_total_statistics_for_month($app_id, $type, $month, $year)
	{
		$start_date = ''.$year.'-'.$month.'-01 00:00:00';
		$end_date = ''.$year.'-'.$month.'-31 23:59:59';

		$total = $this->CI->statistics_model->get_total_for_month($app_id, $type, $start_date, $end_date);

		return $total;
	}

	/*
	 * Get unbulished comments for app list
	 * @param int $app_id
	 */
	function get_total_unbulished_comments_for_app_list($app_id)
	{
		$total = $this->CI->comments_model->get_total_ubpublished_comments($app_id);

		return $total;
	}

	/*
	 * Get unread forms for app list
	 * @param int $app_id
	 */
	function get_total_unread_forms_for_app_list($app_id)
	{
		$total = $this->CI->forms_model->get_total_received_forms($app_id);

		return $total;
	}

	/*
	 * Get unread messages for app list
	 * @param int $app_id
	 */
	function get_total_unread_messages_for_app_list($app_id)
	{
		$total = $this->CI->messages_model->get_total_unread_messages_for_apps($app_id);

		return $total;
	}

	/*
	 * Generate QR code
	 * @param int $version_id
	 */
	function get_qrcode($version_id)
	{
		$version = $this->CI->builder_model->get_version($version_id);

		if ($version) {

			if ($version->type == 1) { // phonegap link

				$qr_code = 'https://chart.googleapis.com/chart?chs=350x350&cht=qr&chl=https://build.phonegap.com/apps/'.$version->phonegap_id.'/download/android/?qr_key='.$version->path.'&choe=UTF-8';

			} else { // local link

			}

			return $qr_code;

		} else {

			return 0;

		}
	}

	/*
	 * Get template list for select
	 */
	function get_design_list()
	{
		$list = $this->CI->template_model->get_templates_design();

		return $list;
	}

	/*
	 * Get localizations list for select
	 */
	function get_localizations_list()
	{
		$localizations = $this->CI->localization_model->get_localizations();

		return $localizations;
	}
  
  /*
	 * Get icon app
   * @param int $app_id
	 */
	function get_icon_app($app_id)
	{
		$icon = $this->CI->icons_model->get_icon($app_id);

		return ''.base_url().'projects/'.$app_id.'/www/img/icon/android/'.$icon->android.'';
	}

}