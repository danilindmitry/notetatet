<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Samples {

	function __construct()
	{
		$this->CI =& get_instance();
		$this->CI->load->model('forms_model');
	}

	/*
	 * Generate simple form element
	 * @param int $type, int $required, string $prefix
	 */
	public function generate_form_selement($type, $required, $prefix)
	{
		if ($type == 1) { // input text

			if ($required == 1) {

				$element = '<div class="item-input-wrap"><input type="text" name="'.$prefix.'" required validate><span class="input-clear-button"></span></div>';

			} else {

				$element = '<div class="item-input-wrap"><input type="text" name="'.$prefix.'"><span class="input-clear-button"></span></div>';

			}

			return $element;

		} else if ($type == 2) { // input email

			$element = '<div class="item-input-wrap"><input type="email" name="'.$prefix.'" required validate><span class="input-clear-button"></span></div>';

			return $element;

		} else if ($type == 3) { // input numeric

			$element = '<div class="item-input-wrap"><input type="text" name="'.$prefix.'" required validate pattern="[0-9]*" data-error-message="Only numbers please!"><span class="input-clear-button"></span></div>';

			return $element;

		} else if ($type == 4) { // input date

			$element = '<div class="item-input-wrap"><input type="date" name="'.$prefix.'" value="2018-01-01"></div>';

			return $element;

		} else if ($type == 5) { // textarea

			$element = '<div class="item-input-wrap"><textarea name="'.$prefix.'"></textarea><span class="input-clear-button"></div>';

			return $element;

		} else if ($type == 7) { // checkbox

			$element = '<input type="checkbox" name="'.$prefix.'" value="yes"/>';

			return $element;

		} else if ($type == 9) { // toogle

			$element = '<input type="checkbox" name="'.$prefix.'" value="yes"><i class="toggle-icon"></i>';

			return $element;

		}
	}

	/*
	 * Generate extended form element
	 * @param int $type, string $prefix, array $options
	 */
	public function generate_extended_form_selement($type, $prefix, $values, $name)
	{
		if ($type == 6) { // select list

			$element = '<select name="'.$prefix.'">';

			foreach($values as $option) {

				$element .= '<option value="'.$option['option'].'">'.$option['option'].'</option>';

			}
			
			$element .= '</select>';

			return $element;

		} else if ($type == 8) {

			$element = '<li class="item-content item-input"><div class="item-title item-label">'.$name.'</div></li>';

			foreach($values as $option) {

				$element .= '<li><label class="item-radio item-content"><input type="radio" name="'.$prefix.'" value="'.$option['option'].'"><i class="icon icon-radio"></i><div class="item-inner"><div class="item-title">'.$option['option'].'</div></div></label></li>';

			}
			
			return $element;

		} else if ($type == 10) { // range

			$element = '<input type="range" name="'.$prefix.'" value="'.$values['value'].'" min="'.$values['min'].'" max="'.$values['max'].'" step="'.$values['step'].'">';

			return $element;

		}
	}

}