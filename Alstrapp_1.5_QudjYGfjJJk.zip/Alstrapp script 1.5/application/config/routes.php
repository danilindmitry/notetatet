<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'auth';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['my/apps/(:num)/dashboard'] = 'my/dashboard/index';

// users page
$route['my/apps/(:num)/users'] = 'my/users/index';
$route['my/apps/(:num)/users/index'] = 'my/users/index';
$route['my/apps/(:num)/users/index/(:num)'] = 'my/users/index';
$route['my/apps/(:num)/users/groups'] = 'my/users/groups';
$route['my/apps/(:num)/users/add_user'] = 'my/users/add_user';
$route['my/apps/(:num)/users/edit_user/(:num)'] = 'my/users/edit_user/$2';

// galleries
$route['my/apps/(:num)/galleries'] = 'my/galleries/index';
$route['my/apps/(:num)/galleries/index'] = 'my/galleries/index';
$route['my/apps/(:num)/galleries/index/(:num)'] = 'my/galleries/index';
$route['my/apps/(:num)/galleries/create_gallery'] = 'my/galleries/create_gallery';
$route['my/apps/(:num)/galleries/upload/(:num)'] = 'my/galleries/upload/$2';
$route['my/apps/(:num)/galleries/upload_images/(:num)'] = 'my/galleries/upload_images/$2';
$route['my/apps/(:num)/galleries/delete_image/(:num)'] = 'my/galleries/delete_image/$2';
$route['my/apps/(:num)/galleries/delete_gallery/(:num)'] = 'my/galleries/delete_gallery/$2';
$route['my/apps/(:num)/galleries/update_gallery/(:num)'] = 'my/galleries/update_gallery/$2';

// posts
$route['my/apps/(:num)/posts/categories'] = 'my/posts/categories';
$route['my/apps/(:num)/posts/add_category'] = 'my/posts/add_category';
$route['my/apps/(:num)/posts/create_category'] = 'my/posts/create_category';
$route['my/apps/(:num)/posts/categories/(:num)'] = 'my/posts/categories/$2';
$route['my/apps/(:num)/posts/unpublish/(:num)'] = 'my/posts/unpublish/$2';
$route['my/apps/(:num)/posts/publish/(:num)'] = 'my/posts/publish/$2';
$route['my/apps/(:num)/posts/delete_category/(:num)'] = 'my/posts/delete_category/$2';
$route['my/apps/(:num)/posts/edit_category/(:num)'] = 'my/posts/edit_category/$2';
$route['my/apps/(:num)/posts/update_category/(:num)'] = 'my/posts/update_category/$2';
$route['my/apps/(:num)/posts'] = 'my/posts/index';
$route['my/apps/(:num)/posts/index'] = 'my/posts/index';
$route['my/apps/(:num)/posts/index/(:num)'] = 'my/posts/index/$2';
$route['my/apps/(:num)/posts/add_post'] = 'my/posts/add_post';
$route['my/apps/(:num)/posts/edit_post/(:num)'] = 'my/posts/edit_post/$2';
$route['my/apps/(:num)/posts/create_post'] = 'my/posts/create_post';
$route['my/apps/(:num)/posts/unpublish_post/(:num)'] = 'my/posts/unpublish_post/$2';
$route['my/apps/(:num)/posts/publish_post/(:num)'] = 'my/posts/publish_post/$2';
$route['my/apps/(:num)/posts/delete_post/(:num)'] = 'my/posts/delete_post/$2';
$route['my/apps/(:num)/posts/update_post/(:num)'] = 'my/posts/update_post/$2';

// comments
$route['my/apps/(:num)/comments'] = 'my/comments/index';
$route['my/apps/(:num)/comments/index'] = 'my/comments/index';
$route['my/apps/(:num)/comments/index/(:num)'] = 'my/comments/index/$2';
$route['my/apps/(:num)/comments/view/(:num)'] = 'my/comments/view/$2';
$route['my/apps/(:num)/comments/create_comment/(:num)'] = 'my/comments/create_comment/$2';
$route['my/apps/(:num)/comments/delete_comment/(:num)'] = 'my/comments/delete_comment/$2';
$route['my/apps/(:num)/comments/unpublish/(:num)'] = 'my/comments/unpublish/$2';
$route['my/apps/(:num)/comments/publish/(:num)'] = 'my/comments/publish/$2';

// forms
$route['my/apps/(:num)/forms'] = 'my/forms/index';
$route['my/apps/(:num)/forms/create_form'] = 'my/forms/create_form';
$route['my/apps/(:num)/forms/index/(:num)'] = 'my/forms/index/$2';
$route['my/apps/(:num)/forms/index'] = 'my/forms/index';
$route['my/apps/(:num)/forms/update_form/(:num)'] = 'my/forms/update_form/$2';
$route['my/apps/(:num)/forms/builder/(:num)'] = 'my/forms/builder/$2';
$route['my/apps/(:num)/forms/create_element/(:num)'] = 'my/forms/create_element/$2';
$route['my/apps/(:num)/forms/delete_form_elements/(:num)'] = 'my/forms/delete_form_elements/$2';
$route['my/apps/(:num)/forms/update_code/(:num)'] = 'my/forms/update_code/$2';
$route['my/apps/(:num)/forms/delete_form/(:num)'] = 'my/forms/delete_form/$2';
$route['my/apps/(:num)/forms/inbox/(:num)'] = 'my/forms/inbox/$2';
$route['my/apps/(:num)/forms/inbox/(:num)/(:num)'] = 'my/forms/inbox/$2/$3';
$route['my/apps/(:num)/forms/delete_form_result/(:num)'] = 'my/forms/delete_form_result/$2';
$route['my/apps/(:num)/forms/detail_inbox/(:num)'] = 'my/forms/detail_inbox/$2';

// messages
$route['my/apps/(:num)/messages'] = 'my/messages/index';
$route['my/apps/(:num)/messages/unread_dialogues'] = 'my/messages/unread_dialogues';
$route['my/apps/(:num)/messages/all'] = 'my/messages/all';
$route['my/apps/(:num)/messages/all/(:num)'] = 'my/messages/all/$2';
$route['my/apps/(:num)/messages/view/(:num)'] = 'my/messages/view/$2';
$route['my/apps/(:num)/messages/create_message/(:num)'] = 'my/messages/create_message/$2';
$route['my/apps/(:num)/messages/check_new_messages/(:num)'] = 'my/messages/check_new_messages/$2';
$route['my/apps/(:num)/messages/clear_chat/(:num)'] = 'my/messages/clear_chat/$2';
$route['my/apps/(:num)/messages/user_ban/(:num)'] = 'my/messages/user_ban/$2';
$route['my/apps/(:num)/messages/user_unban/(:num)'] = 'my/messages/user_unban/$2';
$route['my/apps/(:num)/messages/create_dialogue'] = 'my/messages/create_dialogue';
$route['my/apps/(:num)/messages/add_dialogue'] = 'my/messages/add_dialogue';
$route['my/apps/(:num)/messages/search'] = 'my/messages/search';

// navigation
$route['my/apps/(:num)/navigation'] = 'my/navigation/index';
$route['my/apps/(:num)/navigation/auth'] = 'my/navigation/auth';
$route['my/apps/(:num)/navigation/user'] = 'my/navigation/user';
$route['my/apps/(:num)/navigation/create_item'] = 'my/navigation/create_item';
$route['my/apps/(:num)/navigation/build/(:num)'] = 'my/navigation/build/$2';
$route['my/apps/(:num)/navigation/build/(:num)/(:num)'] = 'my/navigation/build/$2/$3';
$route['my/apps/(:num)/navigation/update_item/(:num)'] = 'my/navigation/update_item/$2';
$route['my/apps/(:num)/navigation/delete_item/(:num)'] = 'my/navigation/delete_item/$2';

// notifications
$route['my/apps/(:num)/notifications'] = 'my/notifications/index';
$route['my/apps/(:num)/notifications/index'] = 'my/notifications/index';
$route['my/apps/(:num)/notifications/index/(:num)'] = 'my/notifications/index/$2';
$route['my/apps/(:num)/notifications/index'] = 'my/notifications/index';
$route['my/apps/(:num)/notifications/planned'] = 'my/notifications/planned';
$route['my/apps/(:num)/notifications/planned/(:num)'] = 'my/notifications/planned/$2';
$route['my/apps/(:num)/notifications/archive'] = 'my/notifications/archive';
$route['my/apps/(:num)/notifications/archive/(:num)'] = 'my/notifications/archive/$2';
$route['my/apps/(:num)/notifications/add_notice'] = 'my/notifications/add_notice';
$route['my/apps/(:num)/notifications/create_notice'] = 'my/notifications/create_notice';
$route['my/apps/(:num)/notifications/edit_notice/(:num)'] = 'my/notifications/edit_notice/$2';
$route['my/apps/(:num)/notifications/update_notice/(:num)'] = 'my/notifications/update_notice/$2';
$route['my/apps/(:num)/notifications/delete_notice/(:num)'] = 'my/notifications/delete_notice/$2';
$route['my/apps/(:num)/notifications/newsletter'] = 'my/notifications/newsletter';
$route['my/apps/(:num)/notifications/newsletter/(:num)'] = 'my/notifications/newsletter/$2';
$route['my/apps/(:num)/notifications/push_detail/(:any)'] = 'my/notifications/push_detail/$2';
$route['my/apps/(:num)/notifications/add_push'] = 'my/notifications/add_push';
$route['my/apps/(:num)/notifications/send_push'] = 'my/notifications/send_push';

// statistics
$route['my/apps/(:num)/statistics'] = 'my/statistics/index';
$route['my/apps/(:num)/statistics/index'] = 'my/statistics/index';
$route['my/apps/(:num)/statistics/index/(:num)'] = 'my/statistics/index/$2';
$route['my/apps/(:num)/statistics/delete_item/(:num)'] = 'my/statistics/delete_item/$2';
$route['my/apps/(:num)/statistics/annual'] = 'my/statistics/annual';
$route['my/apps/(:num)/statistics/annual/(:num)'] = 'my/statistics/annual/$2';

// builder
$route['my/apps/(:num)/builder'] = 'my/builder/index';
$route['my/apps/(:num)/builder/index'] = 'my/builder/index';
$route['my/apps/(:num)/builder/index/(:num)'] = 'my/builder/index/$2';
$route['my/apps/(:num)/builder/storage'] = 'my/builder/storage';
$route['my/apps/(:num)/builder/storage/(:num)'] = 'my/builder/storage/$2';
$route['my/apps/(:num)/builder/start_build'] = 'my/builder/start_build';
$route['my/apps/(:num)/builder/delete_version/(:num)'] = 'my/builder/delete_version/$2';
$route['my/apps/(:num)/builder/download_android/(:num)'] = 'my/builder/download_android/$2';
$route['my/apps/(:num)/builder/download_ios/(:num)'] = 'my/builder/download_ios/$2';
$route['my/apps/(:num)/builder/save_to_local/(:num)'] = 'my/builder/save_to_local/$2';
$route['my/apps/(:num)/builder/delete_local_version/(:num)'] = 'my/builder/delete_local_version/$2';
$route['my/apps/(:num)/builder/github'] = 'my/builder/github';

// settings
$route['my/apps/(:num)/settings'] = 'my/settings/index';
$route['my/apps/(:num)/settings/push'] = 'my/settings/push';
$route['my/apps/(:num)/settings/update_push'] = 'my/settings/update_push';
$route['my/apps/(:num)/settings/icons'] = 'my/settings/icons';
$route['my/apps/(:num)/settings/icons_ios'] = 'my/settings/icons_ios';
$route['my/apps/(:num)/settings/avatars'] = 'my/settings/avatars';
$route['my/apps/(:num)/settings/upload_icon'] = 'my/settings/upload_icon';
$route['my/apps/(:num)/settings/upload_splash'] = 'my/settings/upload_splash';
$route['my/apps/(:num)/settings/upload_avatar'] = 'my/settings/upload_avatar';
$route['my/apps/(:num)/settings/update_app_settings'] = 'my/settings/update_app_settings';
$route['my/apps/(:num)/settings/emails'] = 'my/settings/emails';
$route['my/apps/(:num)/settings/update_email_settings'] = 'my/settings/update_email_settings';