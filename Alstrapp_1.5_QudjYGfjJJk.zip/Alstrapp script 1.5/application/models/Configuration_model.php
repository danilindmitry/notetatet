<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Configuration_model extends CI_model {

	/*
	 * Configuration detail
	 */
	public function get_configuration() 
	{
		$where = array('id' => 1);
		$query = $this->db->where($where)->get("configuration");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Update configuration
	 * @param array $data
	 */
	public function update_configuration($data) 
	{
		$where = array('id' => 1);
		$this->db->where($where)->update("configuration", $data);
	}

}