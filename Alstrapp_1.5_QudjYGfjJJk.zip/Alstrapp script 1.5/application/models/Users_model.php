<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Users_model extends CI_model {

	/*
	 * Total user groups
	 * @param int $app_id
	 */
	public function get_total_groups($app_id) 
	{
		// all groups
		$query = $this->db->where("app_id", $app_id)->get("users_groups");

		return $query->num_rows();
	}

	/*
	 * Get list user groups
	 * @param int $limit, int $start, int $app_id
	 */
	public function get_groups($limit, $start, $app_id) 
	{
		$this->db->limit($limit, $start);

		// all apps
		$query = $this->db->where("app_id", $app_id)->order_by('id', 'asc')->get("users_groups");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list groups without pagination
	 * @param int $app_id
	 */
	public function get_groups_list($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->order_by('id', 'asc')->where($where)->get("users_groups");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Add user group
	 * @param array $data
	 */
	public function add_group($data)
	{
		$this->db->insert("users_groups", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Group detail
	 * @param int $id
	 */
	public function get_group($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("users_groups");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Delete group
	 * @param int $id
	 */
  	public function del_group($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("users_groups");
	}

	/*
	 * Update group
	 * @param int $group_id, array $data
	 */
	public function update_group($group_id, $data) 
	{
		$where = array('id' => $group_id);
		$this->db->where($where)->update("users_groups", $data);
	}

	/*
	 * Count users for group
	 * @param int $group_id
	 */
	public function get_count_users_for_group($group_id) 
	{
		$where = array('user_group' => $group_id);

		// all users
		$query = $this->db->where($where)->get("users");

		return $query->num_rows();
	}

	/*
	 * Total users
	 * @param int $app_id, string $search
	 */
	public function get_total_users($app_id, $search) 
	{
		$where = array('app_id' => $app_id);

		if (!$search) {

			// all users
			$query = $this->db->where($where)->get("users");

		} else {

			// searching results
			$query = $this->db->where($where)->like('username', $search)->or_like('email', $search)->or_like('first_name', $search)->or_like('last_name', $search)->get("users");

		}

		return $query->num_rows();
	}

	/*
	 * Get list users
	 * @param int $limit, int $start, int $app_id, string $search
	 */
	public function get_users($limit, $start, $app_id, $search) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id);

		if (!$search) {

			// all users
			$query = $this->db->where($where)->order_by('id', 'desc')->get("users");

		} else {

			// searching results
			$query = $this->db->where($where)->like('username', $search)->or_like('email', $search)->or_like('first_name', $search)->or_like('last_name', $search)->order_by('id', 'desc')->get("users");
		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Total users for group sort
	 * @param int $app_id, int $group, string $search
	 */
	public function get_total_users_for_group($app_id, $group, $search) 
	{
		$where = array('app_id' => $app_id, 'user_group' => $group);

		if (!$search) {

			// all users
			$query = $this->db->where($where)->get("users");

		} else {

			// searching results
			$query = $this->db->where($where)->like('username', $search)->or_like('email', $search)->or_like('first_name', $search)->or_like('last_name', $search)->get("users");

		}

		return $query->num_rows();
	}

	/*
	 * Get list users for group sort
	 * @param int $limit, int $start, int $app_id, int $group, string $search
	 */
	public function get_users_for_group($limit, $start, $app_id, $group, $search) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'user_group' => $group);

		if (!$search) {

			// all users
			$query = $this->db->where($where)->order_by('id', 'desc')->get("users");

		} else {

			// searching results
			$query = $this->db->where($where)->like('username', $search)->or_like('email', $search)->or_like('first_name', $search)->or_like('last_name', $search)->order_by('id', 'desc')->get("users");
		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * User detail
	 * @param int $id
	 */
	public function get_user($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("users");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * User detail from email
	 * @param string $email
	 */
	public function get_user_from_email($email) 
	{
		$where = array('email' => $email);
		$query = $this->db->where($where)->get("users");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * User detail from username
	 * @param string $email
	 */
	public function get_user_from_username($username) 
	{
		$where = array('username' => $username);
		$query = $this->db->where($where)->get("users");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * User detail from token
	 * @param string $token
	 */
	public function get_user_from_token($token) 
	{
		$where = array('token' => $token);
		$query = $this->db->where($where)->get("users");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Add user
	 * @param array $data
	 */
	public function add_user($data)
	{
		$this->db->insert("users", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Update user
	 * @param int $user_id, array $data
	 */
	public function update_user($user_id, $data) 
	{
		$where = array('id' => $user_id);
		$this->db->where($where)->update("users", $data);
	}

	/*
	 * Delete user
	 * @param int $id
	 */
  	public function del_user($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("users");
	}

	/*
	 * Get list users in group for verify delete group
	 * @param int $group_id
	 */
	public function get_users_in_group($group_id) 
	{
		$where = array('user_group' => $group_id);
		$query = $this->db->where($where)->get("users");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all users for app
	 * @param int $app_id
	 */
	public function get_all_users_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("users");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all users group group for app
	 * @param int $app_id
	 */
	public function get_all_users_groups_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("users_groups");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

}