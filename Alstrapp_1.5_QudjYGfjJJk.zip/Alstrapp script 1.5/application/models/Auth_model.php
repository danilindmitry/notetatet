<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_model {

	/*
	 * Select password stamp for sign in form
	 * @param string $email
	 */
  	public function get_admin($email) 
	{
		$query = $this->db->where("email", $email)->get("admins");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Get admin detail
	 * @param int $id
	 */
  	public function get_admin_from_id($id) 
	{
		$query = $this->db->where("id", $id)->get("admins");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Update admin
	 * @param int $admin, array $data
	 */
  	public function update_admin($admin, $data) 
	{
		$where = array('id' => $admin);
		$this->db->where($where)->update("admins", $data);
	}

}