<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Notifications_model extends CI_model {

	/*
	 * Total active notifications
	 * @param int $app_id, string $end_date
	 */
	public function get_total_active_notifications($app_id, $end_date) 
	{
		$where = array('app_id' => $app_id, 'end_date >=' => $end_date, 'start_date <' => $end_date);

		// all users
		$query = $this->db->where($where)->get("notifications");

		return $query->num_rows();
	}

	/*
	 * Total planned notifications
	 * @param int $app_id, string $start_date
	 */
	public function get_total_planned_notifications($app_id, $start_date) 
	{
		$where = array('app_id' => $app_id, 'start_date >' => $start_date);

		// all users
		$query = $this->db->where($where)->get("notifications");

		return $query->num_rows();
	}

	/*
	 * Total archive notifications
	 * @param int $app_id, string $start_date
	 */
	public function get_total_archive_notifications($app_id, $start_date) 
	{
		$where = array('app_id' => $app_id, 'end_date <' => $start_date);

		// all users
		$query = $this->db->where($where)->get("notifications");

		return $query->num_rows();
	}

	/*
	 * Get list archive notifications
	 * @param int $limit, int $start, int $app_id, string $start_date
	 */
	public function get_archive_notifications($limit, $start, $app_id, $start_date)
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'end_date <' => $start_date);

		$query = $this->db->where($where)->order_by('id', 'desc')->get("notifications");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list planned notifications
	 * @param int $limit, int $start, int $app_id, string $start_date
	 */
	public function get_planned_notifications($limit, $start, $app_id, $start_date)
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'start_date >' => $start_date);

		$query = $this->db->where($where)->order_by('id', 'desc')->get("notifications");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list active notifications
	 * @param int $limit, int $start, int $app_id, string $end_date
	 */
	public function get_active_notifications($limit, $start, $app_id, $end_date)
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'end_date >=' => $end_date, 'start_date <' => $end_date);

		$query = $this->db->where($where)->order_by('id', 'desc')->get("notifications");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Alert detail
	 * @param int $id
	 */
	public function get_alert($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("notifications");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Add notification
	 * @param array $data
	 */
	public function add_notification($data)
	{
		$this->db->insert("notifications", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Update notification
	 * @param int $id, array $data
	 */
	public function update_notice($id, $data) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->update("notifications", $data);
	}

	/*
	 * Delete alert
	 * @param int $id
	 */
  	public function del_alert($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("notifications");
	}

	/*
	 * Total alert notifications for register_users
	 * @param int $app_id, int $user_group, datatime $end_date
	 */
	public function get_total_alerts_for_register_users($app_id, $user_group, $end_date) 
	{	
		/*
		if ($user_group) {

			$wheres = '(app_id = '.$app_id.' AND rights != 1 AND users_group = 0) OR (app_id = '.$app_id.' AND rights != 1 AND users_group = '.$user_group.')';

		} else {

			$wheres = 'app_id = '.$app_id.' AND rights != 1 AND users_group = 0';

		}
		*/

		if ($user_group) {

			$query = $this->db
	        ->group_start()
	                ->or_group_start()
	                        ->where('app_id', $app_id)
	                        ->where('end_date >=', $end_date)
	                        ->where('start_date <', $end_date)
	                        ->where('rights !=', 1)
	                        ->where('users_group', 0)
	                ->group_end()
	                ->or_group_start()
	                        ->where('app_id', $app_id)
	                        ->where('end_date >=', $end_date)
	                        ->where('start_date <', $end_date)
	                        ->where('rights !=', 1)
	                        ->where('users_group', $user_group)
	                ->group_end()
	        ->group_end()
			->order_by('id', 'desc')->get("notifications");

		} else {

			$query = $this->db
	        ->group_start()
	                ->or_group_start()
	                        ->where('app_id', $app_id)
	                        ->where('end_date >=', $end_date)
	                        ->where('start_date <', $end_date)
	                        ->where('rights !=', 1)
	                        ->where('users_group', 0)
	                ->group_end()
	        ->group_end()
			->order_by('id', 'desc')->get("notifications");

		}

		// all users
		//$query = $this->db->where($wheres)->get("notifications");

		return $query->num_rows();
	}

	/*
	 * Total alert notifications for unregister_users
	 * @param int $app_id, datatime $end_date
	 */
	public function get_total_alerts_for_unregister_users($app_id, $end_date) 
	{

		$query = $this->db
	    ->group_start()
	            ->or_group_start()
	                    ->where('app_id', $app_id)
	                    ->where('end_date >=', $end_date)
	                    ->where('start_date <', $end_date)
	                    ->where('rights !=', 2)
	                    ->where('users_group', 0)
	            ->group_end()
	    ->group_end()
		->order_by('id', 'desc')->get("notifications");

		// all users
		//$query = $this->db->where($wheres)->get("notifications");

		return $query->num_rows();
	}

	/*
	 * Get list alert notifications for unregister_users
	 * @param int $app_id, datatime $end_date
	 */
	public function get_alerts_for_unregister_users($app_id, $end_date) 
	{

		$query = $this->db
	    ->group_start()
	            ->or_group_start()
	                    ->where('app_id', $app_id)
	                    ->where('end_date >=', $end_date)
	                    ->where('start_date <', $end_date)
	                    ->where('rights !=', 2)
	                    ->where('users_group', 0)
	            ->group_end()
	    ->group_end()
		->order_by('id', 'desc')->get("notifications");
		
		//$query = $this->db->where($wheres)->order_by('id', 'desc')->get("notifications");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list alert notifications for register_users
	 * @param int $app_id, int $user_group, datatime $end_date
	 */
	public function get_alerts_for_register_users($app_id, $user_group, $end_date) 
	{
		/*
		if ($user_group) {

			$wheres = '(app_id = '.$app_id.' AND end_date >= '.$end_date.' AND start_date < '.$end_date.' AND rights != 1 AND users_group = 0) OR (app_id = '.$app_id.' AND rights != 1 AND users_group = '.$user_group.')';

		} else {

			$wheres = 'app_id = '.$app_id.' AND rights != 1 AND users_group = 0';

		}
		*/

		if ($user_group) {

			$query = $this->db
	        ->group_start()
	                ->or_group_start()
	                        ->where('app_id', $app_id)
	                        ->where('end_date >=', $end_date)
	                        ->where('start_date <', $end_date)
	                        ->where('rights !=', 1)
	                        ->where('users_group', 0)
	                ->group_end()
	                ->or_group_start()
	                        ->where('app_id', $app_id)
	                        ->where('end_date >=', $end_date)
	                        ->where('start_date <', $end_date)
	                        ->where('rights !=', 1)
	                        ->where('users_group', $user_group)
	                ->group_end()
	        ->group_end()
			->order_by('id', 'desc')->get("notifications");

		} else {

			$query = $this->db
	        ->group_start()
	                ->or_group_start()
	                        ->where('app_id', $app_id)
	                        ->where('end_date >=', $end_date)
	                        ->where('start_date <', $end_date)
	                        ->where('rights !=', 1)
	                        ->where('users_group', 0)
	                ->group_end()
	        ->group_end()
			->order_by('id', 'desc')->get("notifications");

		}
		
		//$query = $this->db->where($wheres)->order_by('id', 'desc')->get("notifications");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all notifications for app
	 * @param int $app_id
	 */
	public function get_all_notifications_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("notifications");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

}