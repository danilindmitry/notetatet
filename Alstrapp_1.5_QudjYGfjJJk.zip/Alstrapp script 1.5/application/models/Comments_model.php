<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Comments_model extends CI_model {

	/*
	 * Total unpublished comments
	 * @param int $app_id, string $search
	 */
	public function get_total_ubpublished_comments($app_id) 
	{
		$where = array('app_id' => $app_id, 'status' => 2);
		// all comments
		$query = $this->db->where($where)->get("comments");

		return $query->num_rows();
	}

	/*
	 * Total comments
	 * @param int $app_id, string $search
	 */
	public function get_total($app_id, $search) 
	{
		if (!$search) {

			// all comments
			$query = $this->db->where("app_id", $app_id)->get("comments");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('comment', $search)->get("comments");

		}

		return $query->num_rows();
	}

	/*
	 * Get last 5 unpublished comments
	 * @param int $app_id
	 */
	public function get_last_comments($app_id) 
	{
		$where = array('app_id' => $app_id, 'status' => 2);

		// all apps
		$query = $this->db->where($where)->limit(5)->order_by('id', 'desc')->get("comments");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list comments
	 * @param int $limit, int $start, int $app_id, string $search
	 */
	public function get_comments($limit, $start, $app_id, $search) 
	{
		$this->db->limit($limit, $start);

		if (!$search) {

			// all apps
			$query = $this->db->where("app_id", $app_id)->order_by('id', 'desc')->get("comments");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('comment', $search)->order_by('id', 'desc')->get("comments");

		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Total comments for status sort
	 * @param int $app_id, int $status
	 */
	public function get_total_for_status($app_id, $status) 
	{
		$where = array('app_id' => $app_id, 'status' => $status);

		$query = $this->db->where($where)->get("comments");

		return $query->num_rows();
	}

	/*
	 * Get list comments for status sort
	 * @param int $limit, int $start, int $app_id, int $status
	 */
	public function get_comments_for_status($limit, $start, $app_id, $status) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'status' => $status);

		$query = $this->db->where($where)->order_by('id', 'desc')->get("comments");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Comment detail
	 * @param int $id
	 */
	public function get_comment($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("comments");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Add comment
	 * @param array $data
	 */
	public function add_comment($data)
	{
		$this->db->insert("comments", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Update comment
	 * @param int $comment_id, array $data
	 */
	public function update_comment($comment_id, $data) 
	{
		$where = array('id' => $comment_id);
		$this->db->where($where)->update("comments", $data);
	}

	/*
	 * Delete comment
	 * @param int $id
	 */
  	public function del_comment($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("comments");
	}

	/*
	 * Get list all comments for view
	 * @param int $app_id, int $post_id
	 */
	public function get_comments_for_view($app_id, $post_id) 
	{
		$where = array('app_id' => $app_id, 'post_id' => $post_id, 'type' => 1);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'desc')->get("comments");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list comments for start page
	 * @param int $app_id, int $post_id
	 */
	public function get_comments_for_start_page($app_id, $post_id) 
	{
		$where = array('app_id' => $app_id, 'post_id' => $post_id, 'status' => 1);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'asc')->get("comments");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list comments for page
	 * @param int $app_id, int $post_id
	 */
	public function get_comments_for_page($app_id, $post_id) 
	{
		$where = array('app_id' => $app_id, 'post_id' => $post_id, 'status' => 1);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'asc')->limit(3)->get("comments");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list comments for infiniti scroll
	 * @param int $start, int $app_id, int $post_id
	 */
	public function get_comments_for_infiniti($start, $app_id, $post_id) 
	{
		$this->db->limit(10, $start);

		$where = array('app_id' => $app_id, 'post_id' => $post_id, 'status' => 1);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'asc')->get("comments");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get total comments for infiniti for unregister
	 * @param int $start, int $app_id, int $category_id
	 */
	public function get_total_comments_infiniti_scroll($start, $app_id, $post_id) 
	{
		$this->db->limit(10, $start);
		$where = array('app_id' => $app_id, 'post_id' => $post_id, 'status' => 1);
		$query = $this->db->where($where)->get("comments");
		return $query->num_rows();
	}

	/*
	 * Get total comments for infiniti for unregister
	 * @param int $app_id, int $post_id, int $reply_id
	 */
	public function get_total_reply_comments($app_id, $post_id, $reply_id) 
	{
		$where = array('app_id' => $app_id, 'post_id' => $post_id, 'reply_id' => $reply_id, 'status' => 1);

		$query = $this->db->where($where)->get("comments");

		return $query->num_rows();
	}

	/*
	 * Total comments for page
	 * @param int $app_id, int $status
	 */
	public function get_total_for_page($app_id, $post_id) 
	{
		$where = array('app_id' => $app_id, 'post_id' => $post_id, 'status' => 1);

		$query = $this->db->where($where)->get("comments");

		return $query->num_rows();
	}

	/*
	 * Get list reply
	 * @param int $app_id, int $post_id, int $reply_id
	 */
	public function get_replyes_for_view($app_id, $post_id, $reply_id) 
	{
		$where = array('app_id' => $app_id, 'post_id' => $post_id, 'type' => 2, 'reply_id' => $reply_id);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'desc')->get("comments");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list reply
	 * @param int $app_id, int $post_id, int $reply_id
	 */
	public function get_replyes_for_page($app_id, $post_id, $reply_id) 
	{
		$where = array('app_id' => $app_id, 'post_id' => $post_id, 'type' => 2, 'reply_id' => $reply_id, 'status' => 1);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'desc')->get("comments");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get all reply
	 * @param int $comment_id
	 */
	public function get_reply_for_delete($comment_id) 
	{
		$where = array('reply_id' => $comment_id);
		$query = $this->db->where($where)->get("comments");

		foreach ($query->result_array() as $row)
		{
		    $data[] = $row['id'];
		}
	 
	    return $data;
	}

	/*
	 * Delete all reply
	 * @param array $items
	 */
	public function del_all_reply($items) 
	{
		$this->db->where_in('id', $items)->delete("comments");
	}

	/*
	 * Get all comments for app
	 * @param int $app_id
	 */
	public function get_all_comments_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("comments");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

}