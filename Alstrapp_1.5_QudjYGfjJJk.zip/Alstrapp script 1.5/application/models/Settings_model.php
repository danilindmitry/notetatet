<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Settings_model extends CI_model {

	/*
	 * Settings detail
	 * @param int $app_id
	 */
	public function get_settings($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("settings");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Update settings
	 * @param int $app_id, array $data
	 */
	public function update_settings($app_id, $data) 
	{
		$where = array('app_id' => $app_id);
		$this->db->where($where)->update("settings", $data);
	}

	/*
	 * Add settings
	 * @param array $data
	 */
	public function add_settings($data)
	{
		$this->db->insert("settings", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Delete settings
	 * @param int $id
	 */
  	public function del_settings($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("settings");
	}

}