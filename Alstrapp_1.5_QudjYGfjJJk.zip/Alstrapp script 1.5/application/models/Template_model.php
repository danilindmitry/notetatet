<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Template_model extends CI_model {

	/*
	 * Get list design templates
	 */
	public function get_templates_design() 
	{
		$query = $this->db->order_by('id', 'asc')->get("templates_design");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Design templates detail
	 * @param int $id
	 */
	public function get_design_template($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("templates_design");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Add design template
	 * @param array $data
	 */
	public function add_design_template($data)
	{
		$this->db->insert("templates_design", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Delete idesign template
	 * @param int $id
	 */
  	public function del_design_template($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("templates_design");
	}

	/*
	 * Get list email templates
	 */
	public function get_templates_email() 
	{
		$query = $this->db->order_by('sort', 'asc')->get("templates_email");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Email templates detail
	 * @param int $id
	 */
	public function get_email_template($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("templates_email");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Update mail template
	 * @param int $template_id, array $data
	 */
	public function update_email_template($template_id, $data) 
	{
		$where = array('id' => $template_id);
		$this->db->where($where)->update("templates_email", $data);
	}

}