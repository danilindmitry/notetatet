<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Galleries_model extends CI_model {

	/*
	 * Total galleries
	 * @param int $app_id, string $search
	 */
	public function get_total($app_id, $search) 
	{
		if (!$search) {

			// all galleries
			$query = $this->db->where("app_id", $app_id)->get("galleries");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('name', $search)->get("galleries");

		}

		return $query->num_rows();
	}

	/*
	 * Get list galleries
	 * @param int $limit, int $start, int $app_id, string $search
	 */
	public function get_galleries($limit, $start, $app_id, $search) 
	{
		$this->db->limit($limit, $start);

		if (!$search) {

			// all apps
			$query = $this->db->where("app_id", $app_id)->order_by('id', 'desc')->get("galleries");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('name', $search)->order_by('id', 'desc')->get("galleries");

		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list galleries for select
	 * @param int $app_id
	 */
	public function get_galleries_for_select($app_id) 
	{
		$where = array('app_id' => $app_id);
		
		// all apps
		$query = $this->db->where($where)->order_by('id', 'desc')->get("galleries");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Add gallery
	 * @param array $data
	 */
	public function add_gallery($data)
	{
		$this->db->insert("galleries", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Gallery detail
	 * @param int $id
	 */
	public function get_gallery($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("galleries");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Delete gallery
	 * @param int $id
	 */
  	public function del_gallery($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("galleries");
	}

	/*
	 * Update gallery
	 * @param int $gallery_id, array $data
	 */
	public function update_gallery($gallery_id, $data) 
	{
		$where = array('id' => $gallery_id);
		$this->db->where($where)->update("galleries", $data);
	}

	/*
	 * Add images for gallery
	 * @param array $data
	 */
	public function add_images($data = array()) 
	{
        $this->db->insert_batch('galleries_items', $data);
    }

    /*
	 * Get all images for gallery
	 * @param int $gallery_id
	 */
	public function get_gallery_items($gallery_id) 
	{
		$where = array('gallery_id' => $gallery_id);
		$query = $this->db->order_by('id', 'desc')->where($where)->get("galleries_items");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all images for delete gallery
	 * @param int $gallery_id
	 */
	public function get_gallery_items_for_delete($gallery_id) 
	{
		$where = array('gallery_id' => $gallery_id);
		$query = $this->db->where($where)->get("galleries_items");

		foreach ($query->result_array() as $row)
		{
		    $data[] = $row['id'];
		}
	 
	    return $data;
	}

	/*
	 * Delete item gallery
	 * @param int $id
	 */
  	public function del_item_gallery($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("galleries_items");
	}

	/*
	 * Gallery detail
	 * @param int $id
	 */
	public function get_item_gallery($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("galleries_items");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Delete all images for gallery
	 * @param array $items
	 */
	public function del_all_items($items) 
	{
		$this->db->where_in('id', $items)->delete("galleries_items");
	}

	/*
	 * Count images for gallery
	 * @param int $gallery_id
	 */
	public function get_count_images_for_gallery($gallery_id) 
	{
		$where = array('gallery_id' => $gallery_id);

		// all users
		$query = $this->db->where($where)->get("galleries_items");

		return $query->num_rows();
	}

	/*
	 * Get all gallery for app
	 * @param int $app_id
	 */
	public function get_all_gallery_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("galleries");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all gallery utems for app
	 * @param int $app_id
	 */
	public function get_all_gallery_items_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("galleries_items");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

}