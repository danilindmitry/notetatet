<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Localization_model extends CI_model {

	/*
	 * Get list localizations
	 */
	public function get_localizations() 
	{
		$query = $this->db->order_by('id', 'asc')->get("localizations");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Localizations detail
	 * @param int $id
	 */
	public function get_localization($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("localizations");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Add localization
	 * @param array $data
	 */
	public function add_localization($data)
	{
		$this->db->insert("localizations", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Delete localization
	 * @param int $id
	 */
  	public function del_localization($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("localizations");
	}

}