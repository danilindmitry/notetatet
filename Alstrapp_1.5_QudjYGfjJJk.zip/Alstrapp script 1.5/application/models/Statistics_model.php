<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Statistics_model extends CI_model {

	/*
	 * Total for day
	 * @param int $app_id, int $type, string $date
	 */
	public function get_total_for_day($app_id, $type, $date) 
	{
		$where = array('app_id' => $app_id, 'device' => $type);

		$query = $this->db->where($where)->like('date', $date)->get("statistics");

		return $query->num_rows();
	}

	/*
	 * Total for day
	 * @param int $app_id, int $type, string $start_date, string $end_date
	 */
	public function get_total_for_month($app_id, $type, $start_date, $end_date) 
	{

		$where = array('app_id' => $app_id, 'device' => $type, 'date >=' => $start_date, 'date <=' => $end_date);
		/*
		$this->db->where('app_id', $app_id);
		$this->db->where('device', $type);
		$this->db->where('date >=', $start_date);
		$this->db->where('date <=', $end_date);
		*/
		$query = $this->db->where($where)->get("statistics");

		return $query->num_rows();
	}

	/*
	 * Total for year
	 * @param int $app_id, string $start_date, string $end_date
	 */
	public function get_total_for_year_all($app_id, $start_date, $end_date) 
	{

		$where = array('app_id' => $app_id, 'date >=' => $start_date, 'date <=' => $end_date);
		/*
		$this->db->where('app_id', $app_id);
		$this->db->where('device', $type);
		$this->db->where('date >=', $start_date);
		$this->db->where('date <=', $end_date);
		*/
		$query = $this->db->where($where)->get("statistics");

		return $query->num_rows();
	}

	/*
	 * Total for day without device
	 * @param int $app_id, string $start_date, string $end_date
	 */
	public function get_total_for_month_all($app_id, $start_date, $end_date) 
	{

		$where = array('app_id' => $app_id, 'date >=' => $start_date, 'date <=' => $end_date);
		$query = $this->db->where($where)->get("statistics");

		return $query->num_rows();
	}

	/*
	 * Get list statistic for for_month all device
	 * @param int $limit, int $start, string $start_date, string $end_date
	 */
	public function get_statistic_for_month_all($limit, $start, $app_id, $start_date, $end_date) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'date >=' => $start_date, 'date <=' => $end_date);

		// all users
		$query = $this->db->where($where)->order_by('id', 'desc')->get("statistics");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Item detail
	 * @param int $id
	 */
	public function get_item($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("statistics");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Delete item
	 * @param int $id
	 */
  	public function del_item($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("statistics");
	}

	/*
	 * Add item
	 * @param array $data
	 */
	public function add_item($data)
	{
		$this->db->insert("statistics", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Get all statistics for app
	 * @param int $app_id
	 */
	public function get_all_statistics_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("statistics");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

}