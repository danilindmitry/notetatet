<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Builder_model extends CI_model {

	/*
	 * Add version
	 * @param array $data
	 */
	public function add_version($data)
	{
		$this->db->insert("versions", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Total versions for app
	 * @param int $app_id
	 */
	public function get_total_versions($app_id) 
	{
		$where = array('app_id' => $app_id, 'type' => 1);

		$query = $this->db->where($where)->get("versions");

		return $query->num_rows();
	}

	/*
	 * Total local versions for app
	 * @param int $app_id
	 */
	public function get_total_local_versions($app_id) 
	{
		$where = array('app_id' => $app_id, 'type' => 2);

		$query = $this->db->where($where)->get("versions");

		return $query->num_rows();
	}

	/*
	 * Get list versions
	 * @param int $limit, int $start, int $app_id
	 */
	public function get_versions($limit, $start, $app_id) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'type' => 1);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'desc')->get("versions");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list local versions
	 * @param int $limit, int $start, int $app_id
	 */
	public function get_local_versions($limit, $start, $app_id) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'type' => 2);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'desc')->get("versions");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Version detail
	 * @param array $data
	 */
	public function get_version($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("versions");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Version detail
	 * @param array $data
	 */
	public function get_version_phonegap($phonegap_id) 
	{
		$where = array('phonegap_id' => $phonegap_id);
		$query = $this->db->where($where)->get("versions");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Delete app
	 * @param int $id
	 */
  	public function del_app($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("versions");
	}

	/*
	 * Update version
	 * @param int $id, array $data
	 */
	public function update_version($id, $data) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->update("versions", $data);
	}

	/*
	 * Get all versions for app
	 * @param int $app_id
	 */
	public function get_all_versions_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("versions");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

}