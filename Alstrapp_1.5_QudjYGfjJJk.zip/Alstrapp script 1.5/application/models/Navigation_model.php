<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Navigation_model extends CI_model {

	/*
	 * Get list items for main menu
	 * @param int $app_id
	 */
	public function get_main_menu($app_id) 
	{
		$where = array('app_id' => $app_id, 'view' => 1);
		$query = $this->db->order_by('sort', 'asc')->where($where)->get("navigation_main");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list items for auth menu
	 * @param int $app_id
	 */
	public function get_auth_menu($app_id) 
	{
		$where = array('app_id' => $app_id, 'view' => 2);
		$query = $this->db->order_by('sort', 'asc')->where($where)->get("navigation_main");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list items for user menu
	 * @param int $app_id
	 */
	public function get_user_menu($app_id) 
	{
		$where = array('app_id' => $app_id, 'view' => 3);
		$query = $this->db->order_by('sort', 'asc')->where($where)->get("navigation_main");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Item detail
	 * @param int $id
	 */
	public function get_menu_detail($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("navigation_main");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Add item for main menu
	 * @param array $data
	 */
	public function add_main_item($data)
	{
		$this->db->insert("navigation_main", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Delete item for main menu
	 * @param int $id
	 */
  	public function del_main_item($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("navigation_main");
	}

	/*
	 * Update main menu item
	 * @param int $id, array $data
	 */
	public function update_main_item($id, $data) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->update("navigation_main", $data);
	}

	/*
	 * Get list items main menu for user
	 * @param int $app_id, int $user_group
	 */
	public function get_main_menu_for_register_user($app_id, $user_group)
	{
		//$where = array('app_id' => $app_id, 'view' => 1, 'user_group' => $user_group, 'status' => 1, 'rights !=' => 1);
		if ($user_group) {

			$wheres = 'app_id = '.$app_id.' AND view = 1 AND status = 1 AND rights != 1 AND user_group = 0 OR user_group = '.$user_group.'';

		} else {

			$wheres = 'app_id = '.$app_id.' AND view = 1 AND status = 1 AND rights != 1 AND user_group = 0';

		}

		$query = $this->db->order_by('sort', 'asc')->where($wheres)->get("navigation_main");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list items user menu for user
	 * @param int $app_id, int $user_group
	 */
	public function get_user_menu_for_register_user($app_id, $user_group)
	{
		//$where = array('app_id' => $app_id, 'view' => 3, 'user_group' => $user_group, 'status' => 1, 'rights !=' => 1);
		if ($user_group) {

			$wheres = 'app_id = '.$app_id.' AND view = 3 AND status = 1 AND rights != 1 AND user_group = 0 OR user_group = '.$user_group.'';

		} else {

			$wheres = 'app_id = '.$app_id.' AND view = 3 AND status = 1 AND rights != 1 AND user_group = 0';

		}
		$query = $this->db->order_by('sort', 'asc')->where($wheres)->get("navigation_main");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list items auth menu for user
	 * @param int $app_id
	 */
	public function get_auth_menu_for_unregister_user($app_id)
	{
		$where = array('app_id' => $app_id, 'view' => 2, 'status' => 1);
		$query = $this->db->order_by('sort', 'asc')->where($where)->get("navigation_main");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list items main menu for user
	 * @param int $app_id
	 */
	public function get_main_menu_for_unregister_user($app_id)
	{
		$where = array('app_id' => $app_id, 'view' => 1, 'status' => 1, 'user_group' => 0, 'rights !=' => 2);
		$query = $this->db->order_by('sort', 'asc')->where($where)->get("navigation_main");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all navigation for app
	 * @param int $app_id
	 */
	public function get_all_navigation_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("navigation_main");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

}