<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Apps_model extends CI_model {

	/*
	 * Total apps
	 * @param int $sort
	 */
	public function get_total_apps($sort) 
	{
		if (!$sort) {

			// all apps
			$query = $this->db->get("apps");

		} else if ($sort == 1) {

			// drafts apps
			$query = $this->db->where('status', 1)->get("apps");

		} else if ($sort == 2) {

			// active apps
			$query = $this->db->where('status', 2)->get("apps");

		}

		return $query->num_rows();
	}

	/*
	 * Get list apps
	 * @param int $sort, int $limit, int $start
	 */
	public function get_apps($limit, $start, $sort) 
	{
		$this->db->limit($limit, $start);

		if (!$sort) {

			// all apps
			$query = $this->db->order_by('id', 'desc')->get("apps");

		} else if ($sort == 1) {

			// drafts apps
			$query = $this->db->order_by('id', 'desc')->where('status', 1)->get("apps");

		} else if ($sort == 2) {

			// active apps
			$query = $this->db->order_by('id', 'desc')->where('status', 2)->get("apps");

		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Add app
	 * @param array $data
	 */
	public function add_app($data)
	{
		$this->db->insert("apps", $data);
    	return $this->db->insert_id();
	}

	/*
	 * App detail
	 * @param array $data
	 */
	public function get_app($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("apps");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Delete app
	 * @param array $data
	 */
  	public function del_app($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("apps");
	}

	/*
	 * Update app
	 * @param int $id, array $data
	 */
	public function update_app($id, $data) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->update("apps", $data);
	}

}