<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Forms_model extends CI_model {

	/*
	 * Total received forms for Dashboard
	 * @param int $app_id
	 */
	public function get_total_received_forms($app_id) 
	{
		$where = array('app_id' => $app_id, 'status' => 2);
		// all galleries
		$query = $this->db->where($where)->get("forms_received");

		return $query->num_rows();
	}

	/*
	 * Total received forms for apps list
	 * @param int $app_id
	 */
	public function get_total_unread_forms_for_apps($app_id) 
	{
		// all galleries
		$query = $this->db->where("app_id", $app_id)->get("forms_received");

		return $query->num_rows();
	}

	/*
	 * Add form
	 * @param array $data
	 */
	public function add_form($data)
	{
		$this->db->insert("forms", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Get list forms for select
	 * @param int $app_id
	 */
	public function get_forms_for_select($app_id) 
	{
		$where = array('app_id' => $app_id);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'desc')->get("forms");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Total forms
	 * @param int $app_id, string $search
	 */
	public function get_total($app_id, $search) 
	{
		if (!$search) {

			// all galleries
			$query = $this->db->where("app_id", $app_id)->get("forms");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('name', $search)->get("forms");

		}

		return $query->num_rows();
	}

	/*
	 * Get list forms
	 * @param int $limit, int $start, int $app_id, string $search
	 */
	public function get_forms($limit, $start, $app_id, $search) 
	{
		$this->db->limit($limit, $start);

		if (!$search) {

			// all apps
			$query = $this->db->where("app_id", $app_id)->order_by('id', 'desc')->get("forms");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('name', $search)->order_by('id', 'desc')->get("forms");

		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Form detail
	 * @param int $id
	 */
	public function get_form($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("forms");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Delete form
	 * @param int $id
	 */
  	public function del_form($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("forms");
	}

	/*
	 * Update form
	 * @param int $form_id, array $data
	 */
	public function update_form($form_id, $data) 
	{
		$where = array('id' => $form_id);
		$this->db->where($where)->update("forms", $data);
	}

	/*
	 * Check uniqueness prefix
	 * @param int $app_id, int $form_id, string $prefix
	 */
	public function get_form_uniqueness_prefix($app_id, $form_id, $prefix) 
	{
		$where = array('app_id' => $app_id, 'form_id' => $form_id, 'prefix' => $prefix);

		// all apps
		$query = $this->db->where($where)->get("form_elements");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Add form element
	 * @param array $data
	 */
	public function add_form_element($data)
	{
		$this->db->insert("form_elements", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Total form elements
	 * @param int $app_id, int form_id
	 */
	public function get_total_form_elements($app_id, $form_id) 
	{
		$where = array('app_id' => $app_id, 'form_id' => $form_id);

		// all galleries
		$query = $this->db->where("app_id", $app_id)->get("form_elements");

		return $query->num_rows();
	}

	/*
	 * Get list form element
	 * @param int $app_id, int form_id
	 */
	public function get_form_elements($app_id, $form_id) 
	{
		$where = array('app_id' => $app_id, 'form_id' => $form_id);

		// all elements
		$query = $this->db->where($where)->order_by('sort', 'asc')->get("form_elements");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Update form elements
	 * @param int $form_id, array $data
	 */
	public function update_form_elements($form_id, $data) 
	{
		$where = array('id' => $form_id);
		$this->db->where($where)->update("form_elements", $data);
	}

	/*
	 * Form element detail
	 * @param int $id
	 */
	public function get_form_element($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("form_elements");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Delete form element
	 * @param int $id
	 */
  	public function del_form_element($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("form_elements");
	}

	/*
	 * Get all form elements for delete form
	 * @param int $form_id
	 */
	public function get_form_items_for_delete($form_id) 
	{
		$where = array('form_id' => $form_id);
		$query = $this->db->where($where)->get("form_elements");

		foreach ($query->result_array() as $row)
		{
		    $data[] = $row['id'];
		}
	 
	    return $data;
	}

	/*
	 * Delete all form elements for form
	 * @param array $elements
	 */
	public function del_all_form_elements($elements) 
	{
		$this->db->where_in('id', $elements)->delete("form_elements");
	}

	/*
	 * Total received forms
	 * @param int $app_id, int $form_id, string $search
	 */
	public function get_total_received($app_id, $form_id, $search) 
	{
		$where = array('app_id' => $app_id, 'form_id' => $form_id);

		if (!$search) {

			// all galleries
			$query = $this->db->where($where)->get("forms_received");

		} else {

			$query = $this->db->where($where)->like('result', $search)->get("forms_received");

		}

		return $query->num_rows();
	}

	/*
	 * Get list forms received
	 * @param int $limit, int $start, int $app_id, string $search
	 */
	public function get_forms_inbox($limit, $start, $app_id, $form_id, $search) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'form_id' => $form_id);

		if (!$search) {

			// all apps
			$query = $this->db->where($where)->order_by('id', 'desc')->get("forms_received");

		} else {

			$query = $this->db->where($where)->like('result', $search)->order_by('id', 'desc')->get("forms_received");

		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Total received forms unread
	 * @param int $app_id, int $form_id, string $search
	 */
	public function get_total_received_unread($app_id, $form_id, $search) 
	{
		$where = array('app_id' => $app_id, 'form_id' => $form_id, 'status' => 2);

		if (!$search) {

			// all galleries
			$query = $this->db->where($where)->get("forms_received");

		} else {

			$query = $this->db->where($where)->like('result', $search)->get("forms_received");

		}

		return $query->num_rows();
	}

	/*
	 * Get list forms unread received
	 * @param int $limit, int $start, int $app_id, string $search
	 */
	public function get_forms_inbox_unread($limit, $start, $app_id, $form_id, $search) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'form_id' => $form_id, 'status' => 2);

		if (!$search) {

			// all apps
			$query = $this->db->where($where)->order_by('id', 'desc')->get("forms_received");

		} else {

			$query = $this->db->where($where)->like('result', $search)->order_by('id', 'desc')->get("forms_received");

		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Form received detail
	 * @param int $id
	 */
	public function get_form_received($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("forms_received");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Delete form received
	 * @param int $id
	 */
  	public function del_form_received($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("forms_received");
	}

	/*
	 * Update form received
	 * @param int $id, array $data
	 */
	public function update_form_received($id, $data) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->update("forms_received", $data);
	}

	/*
	 * Count unread form results
	 * @param int $form_id
	 */
	public function get_count_unread_forms_received($form_id) 
	{
		$where = array('form_id' => $form_id, 'status' => 2);

		$query = $this->db->where($where)->get("forms_received");

		return $query->num_rows();
	}

	/*
	 * Count unread form results
	 * @param int $form_id
	 */
	public function get_count_all_forms_received($form_id) 
	{
		$where = array('form_id' => $form_id);

		$query = $this->db->where($where)->get("forms_received");

		return $query->num_rows();
	}

	/*
	 * Get all form received for delete form
	 * @param int $form_id
	 */
	public function get_form_received_for_delete($form_id) 
	{
		$where = array('form_id' => $form_id);
		$query = $this->db->where($where)->get("forms_received");

		foreach ($query->result_array() as $row)
		{
		    $data[] = $row['id'];
		}
	 
	    return $data;
	}

	/*
	 * Delete all form received for form
	 * @param array $elements
	 */
	public function del_all_form_received($elements) 
	{
		$this->db->where_in('id', $elements)->delete("forms_received");
	}

	/*
	 * Add receive form
	 * @param array $data
	 */
	public function add_form_receive($data)
	{
		$this->db->insert("forms_received", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Get all forms for app
	 * @param int $app_id
	 */
	public function get_all_forms_for_app($app_id)
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("forms");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all received forms for app
	 * @param int $app_id
	 */
	public function get_all_received_forms_for_app($app_id)
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("forms_received");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all forms elements for app
	 * @param int $app_id
	 */
	public function get_all_elements_forms_for_app($app_id)
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("form_elements");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

}