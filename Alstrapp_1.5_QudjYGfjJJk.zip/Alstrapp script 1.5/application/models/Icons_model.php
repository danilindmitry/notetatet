<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Icons_model extends CI_model {

	/*
	 * Add app icons array
	 * @param array $data
	 */
	public function add_icons($data)
	{
		$this->db->insert("icons", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Icon detail for app
	 * @param int $app_id
	 */
	public function get_icons($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("icons");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Update icon
	 * @param int $app_id, array $data
	 */
	public function update_icon($app_id, $data) 
	{
		$where = array('app_id' => $app_id);
		$this->db->where($where)->update("icons", $data);
	}

	/*
	 * Delete icon
	 * @param int $id
	 */
  	public function del_icon($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("icons");
	}
  
  /*
	 * Icon detail
	 * @param int $app_id
	 */
	public function get_icon($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("icons");
	    $row = $query->row();
	    return $row;
	}

}