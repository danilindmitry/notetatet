<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Posts_model extends CI_model {

	/*
	 * Add posts category
	 * @param array $data
	 */
	public function add_category($data)
	{
		$this->db->insert("posts_categories", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Total posts
	 * @param int $app_id, string $search
	 */
	public function get_total_posts($app_id, $search) 
	{
		if (!$search) {

			// all galleries
			$query = $this->db->where("app_id", $app_id)->get("posts");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('name', $search)->or_like('content', $search)->or_like('author', $search)->get("posts");

		}

		return $query->num_rows();
	}

	/*
	 * Total active posts
	 * @param int $app_id
	 */
	public function get_total_active_posts($app_id) 
	{
		$where = array('app_id' => $app_id, 'status' => 1);

		// all galleries
		$query = $this->db->where($where)->get("posts");

		return $query->num_rows();
	}

	/*
	 * Get list posts
	 * @param int $limit, int $start, int $app_id, string $search
	 */
	public function get_posts($limit, $start, $app_id, $search) 
	{
		$this->db->limit($limit, $start);

		if (!$search) {

			// all apps
			$query = $this->db->where("app_id", $app_id)->order_by('id', 'desc')->get("posts");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('name', $search)->or_like('content', $search)->or_like('author', $search)->order_by('id', 'desc')->get("posts");

		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list active posts
	 * @param int $limit, int $start, int $app_id
	 */
	public function get_active_posts($limit, $start, $app_id) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'status' => 1);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'desc')->get("posts");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}


	/*
	 * Total posts for category sort
	 * @param int $app_id, int $category_id
	 */
	public function get_total_posts_for_category($app_id, $category_id)
	{
		$where = array('app_id' => $app_id, 'category' => $category_id);

		// all galleries
		$query = $this->db->where($where)->get("posts");

		return $query->num_rows();
	}

	/*
	 * Get list posts for category sort
	 * @param int $limit, int $start, int $app_id, int $category_id
	 */
	public function get_posts_for_category($limit, $start, $app_id, $category_id) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'category' => $category_id);

		// all apps
		$query = $this->db->where($where)->order_by('id', 'desc')->get("posts");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Total categories
	 * @param int $app_id, string $search
	 */
	public function get_total_categories($app_id, $search) 
	{
		if (!$search) {

			// all galleries
			$query = $this->db->where("app_id", $app_id)->get("posts_categories");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('name', $search)->or_like('info', $search)->get("posts_categories");

		}

		return $query->num_rows();
	}

	/*
	 * Get list categories
	 * @param int $limit, int $start, int $app_id, string $search
	 */
	public function get_categories($limit, $start, $app_id, $search) 
	{
		$this->db->limit($limit, $start);

		if (!$search) {

			// all apps
			$query = $this->db->where("app_id", $app_id)->order_by('sort', 'asc')->get("posts_categories");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('name', $search)->or_like('info', $search)->order_by('sort', 'asc')->get("posts_categories");

		}

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list categories for select
	 * @param int $app_id
	 */
	public function get_categories_for_select($app_id) 
	{
		$where = array('app_id' => $app_id, 'status' => 1);

		// all apps
		$query = $this->db->where($where)->order_by('sort', 'asc')->get("posts_categories");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Post detail for unregister user
	 * @param int $id
	 */
	public function get_post_unregister($id) 
	{
		$where = array('id' => $id, 'status' => 1, 'users_group' => 0, 'rights !=' => 2);
		$query = $this->db->where($where)->get("posts");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Post detail for register user
	 * @param int $id, int $user_group
	 */
	public function get_post_register($id, $user_group) 
	{
		if ($user_group) {

			$wheres = '(id = '.$id.' AND status = 1 AND rights != 1 AND users_group = 0) OR (id = '.$id.' AND status = 1 AND rights != 1 OR users_group = '.$user_group.')';

		} else {

			$wheres = 'id = '.$id.' AND status = 1 AND rights != 1 AND users_group = 0';

		}
		$query = $this->db->where($wheres)->get("posts");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Get list posts for infiniti scroll unregister users
	 * @param int $start, int $app_id, int $category_id
	 */
	public function get_infiniti_posts_for_unregister_users($start, $app_id, $category_id) 
	{
		$this->db->limit(10, $start);

		$where = array('app_id' => $app_id, 'status' => 1, 'category' => $category_id, 'users_group' => 0, 'rights !=' => 2);

		$query = $this->db->order_by('id', 'desc')->where($where)->get("posts");
	 
	    if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get total posts for infiniti scroll unregister_users
	 * @param int $start, int $app_id, int $category_id
	 */
	public function get_total_posts_infiniti_scroll($start, $app_id, $category_id) 
	{
		$this->db->limit(10, $start);
		$where = array('app_id' => $app_id, 'status' => 1, 'category' => $category_id, 'users_group' => 0, 'rights !=' => 2);
		$query = $this->db->where($where)->get("posts");
		return $query->num_rows();
	}

	/*
	 * Get list posts for infiniti scroll register users
	 * @param int $start, int $app_id, int $category_id, int $user_group
	 */
	public function get_infiniti_posts_for_register_users($start, $app_id, $category_id, $user_group) 
	{
		$this->db->limit(10, $start);

		if ($user_group) {

			$wheres = '(app_id = '.$app_id.' AND status = 1 AND category = '.$category_id.' AND rights != 1 AND users_group = 0) OR (app_id = '.$app_id.' AND status = 1 AND category = '.$category_id.' AND rights != 1 AND users_group = '.$user_group.')';

		} else {

			$wheres = 'app_id = '.$app_id.' AND status = 1 AND category = '.$category_id.' AND rights != 1 AND users_group = 0';

		}
		

		$query = $this->db->order_by('id', 'desc')->where($wheres)->get("posts");
	 
	    if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get total posts for infiniti scroll register_users
	 * @param int $start, int $app_id, int $category_id, int $user_group
	 */
	public function get_total_posts_infiniti_scroll_register($start, $app_id, $category_id, $user_group) 
	{
		$this->db->limit(10, $start);
		if ($user_group) {

			$wheres = '(app_id = '.$app_id.' AND status = 1 AND category = '.$category_id.' AND rights != 1 AND users_group = 0) OR (app_id = '.$app_id.' AND status = 1 AND category = '.$category_id.' AND rights != 1 AND users_group = '.$user_group.')';

		} else {

			$wheres = 'app_id = '.$app_id.' AND status = 1 AND category = '.$category_id.' AND rights != 1 AND users_group = 0';

		}
		$query = $this->db->where($wheres)->get("posts");
		return $query->num_rows();
	}

	/*
	 * Get list posts for start app page for unregister_users
	 * @param int $app_id, int $category_id
	 */
	public function get_start_posts_for_unregister_users($app_id, $category_id) 
	{
		$where = array('app_id' => $app_id, 'status' => 1, 'category' => $category_id, 'users_group' => 0, 'rights !=' => 2);
		
		$query = $this->db->where($where)->order_by('id', 'desc')->limit(10)->get("posts");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list posts for start app page for register_users
	 * @param int $app_id, int $category_id, int $user_group
	 */
	public function get_start_posts_for_register_users($app_id, $category_id, $user_group) 
	{
		if ($user_group) {

			$wheres = '(app_id = '.$app_id.' AND status = 1 AND category = '.$category_id.' AND rights != 1 AND users_group = 0) OR (app_id = '.$app_id.' AND status = 1 AND category = '.$category_id.' AND rights != 1 AND users_group = '.$user_group.')';

		} else {

			$wheres = 'app_id = '.$app_id.' AND status = 1 AND category = '.$category_id.' AND rights != 1 AND users_group = 0';

		}
		
		$query = $this->db->where($wheres)->order_by('id', 'desc')->limit(10)->get("posts");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list categories for start app page for register_users
	 * @param int $app_id, int $user_group
	 */
	public function get_start_categories_for_register_users($app_id, $user_group) 
	{
		//$where = array('app_id' => $app_id, 'status' => 1);
		if ($user_group) {

			$wheres = '(app_id = '.$app_id.' AND status = 1 AND rights != 1 AND users_group = 0) OR (app_id = '.$app_id.' AND status = 1 AND rights != 1 AND users_group = '.$user_group.')';

		} else {

			$wheres = 'app_id = '.$app_id.' AND status = 1 AND rights != 1 AND users_group = 0';

		}

		$query = $this->db->where($wheres)->order_by('sort', 'asc')->limit(10)->get("posts_categories");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list categories for start app page for unregister_users
	 * @param int $app_id
	 */
	public function get_start_categories_for_unregister_users($app_id) 
	{
		$where = array('app_id' => $app_id, 'status' => 1, 'users_group' => 0, 'rights !=' => 2);
		
		$query = $this->db->where($where)->order_by('sort', 'asc')->limit(10)->get("posts_categories");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get list categories for infiniti scroll register_users
	 * @param int $start, int $app_id, int $user_group
	 */
	public function get_infiniti_categories_for_register_users($start, $app_id, $user_group) 
	{
		$this->db->limit(10, $start);

		if ($user_group) {

			$wheres = '(app_id = '.$app_id.' AND status = 1 AND rights != 1 AND users_group = 0) OR (app_id = '.$app_id.' AND status = 1 AND rights != 1 AND users_group = '.$user_group.')';

		} else {

			$wheres = 'app_id = '.$app_id.' AND status = 1 AND rights != 1 AND users_group = 0';

		}

		$query = $this->db->order_by('id', 'asc')->where($wheres)->get("posts_categories");
	 
	    if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get total categories for infiniti scroll register_users
	 * @param int $start, int $app_id, int $user_group
	 */
	public function get_total_categories_infiniti_scroll_register($start, $app_id, $user_group) 
	{
		$this->db->limit(10, $start);
		if ($user_group) {

			$wheres = '(app_id = '.$app_id.' AND status = 1 AND rights != 1 AND users_group = 0) OR (app_id = '.$app_id.' AND status = 1 AND rights != 1 AND users_group = '.$user_group.')';

		} else {

			$wheres = 'app_id = '.$app_id.' AND status = 1 AND rights != 1 AND users_group = 0';

		}
		$query = $this->db->where($wheres)->get("posts_categories");
		return $query->num_rows();
	}

	/*
	 * Get list categories for infiniti scroll unregister_users
	 * @param int $start, int $app_id
	 */
	public function get_infiniti_categories_for_unregister_users($start, $app_id) 
	{
		$this->db->limit(10, $start);

		$where = array('app_id' => $app_id, 'status' => 1, 'users_group' => 0, 'rights !=' => 2);

		$query = $this->db->order_by('sort', 'asc')->where($where)->get("posts_categories");
	 
	    if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get total categories for infiniti scroll unregister_users
	 * @param int $start, int $app_id
	 */
	public function get_total_categories_infiniti_scroll($start, $app_id) 
	{
		$this->db->limit(10, $start);
		$where = array('app_id' => $app_id, 'status' => 1, 'users_group' => 0, 'rights !=' => 2);
		$query = $this->db->where($where)->get("posts_categories");
		return $query->num_rows();
	}

	/*
	 * Total category for status
	 * @param int $app_id, int $status, int $search
	 */
	public function get_total_category_for_status($app_id, $status) 
	{
		$where = array('app_id' => $app_id, 'status' => $status);

		$query = $this->db->where($where)->order_by('sort', 'asc')->get("posts_categories");

		return $query->num_rows();
	}

	/*
	 * Get list categories for status
	 * @param int $limit, int $start, int $app_id, int $status
	 */
	public function get_categorie_for_status($limit, $start, $app_id, $status) 
	{
		$this->db->limit($limit, $start);

		$where = array('app_id' => $app_id, 'status' => $status);

		// all apps
		$query = $this->db->where($where)->order_by('sort', 'asc')->get("posts_categories");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Category detail
	 * @param int $id
	 */
	public function get_category($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("posts_categories");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Post detail
	 * @param int $id
	 */
	public function get_post($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("posts");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Post active detail
	 * @param int $id
	 */
	public function get_active_post($id) 
	{
		$where = array('id' => $id, 'status' => 1);
		$query = $this->db->where($where)->get("posts");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Update post
	 * @param int $post_id, array $data
	 */
	public function update_post($post_id, $data) 
	{
		$where = array('id' => $post_id);
		$this->db->where($where)->update("posts", $data);
	}

	/*
	 * Delete post
	 * @param int $id
	 */
  	public function del_post($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("posts");
	}

	/*
	 * Update category
	 * @param int $category_id, array $data
	 */
	public function update_category($category_id, $data) 
	{
		$where = array('id' => $category_id);
		$this->db->where($where)->update("posts_categories", $data);
	}

	/*
	 * Delete category
	 * @param int $id
	 */
  	public function del_category($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("posts_categories");
	}

	/*
	 * Add post
	 * @param array $data
	 */
	public function add_post($data)
	{
		$this->db->insert("posts", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Count posts for category
	 * @param int $category_id
	 */
	public function get_count_posts_for_category($category_id) 
	{
		$where = array('category' => $category_id);

		$query = $this->db->where($where)->get("posts");

		return $query->num_rows();
	}

	/*
	 * Get all posts for app
	 * @param int $app_id
	 */
	public function get_all_posts_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("posts");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all posts categories for app
	 * @param int $app_id
	 */
	public function get_all_posts_categories_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("posts_categories");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

}