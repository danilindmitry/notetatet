<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Messages_model extends CI_model {

	/*
	 * Total unread_messages for apps list
	 * @param int $app_id
	 */
	public function get_total_unread_messages_for_apps($app_id) 
	{
		$where = array('app_id' => $app_id, 'type' => 2, 'status' => 1);

		$query = $this->db->where($where)->get("messages");

		return $query->num_rows();
	}

	/*
	 * Total unread_messages for user
	 * @param int $app_id, int $dialogue_id
	 */
	public function get_total_unread_messages_for_user($app_id, $dialogue_id) 
	{
		$where = array('app_id' => $app_id, 'dialogue' => $dialogue_id, 'type' => 1, 'status' => 1);

		$query = $this->db->where($where)->get("messages");

		return $query->num_rows();
	}

	/*
	 * Total dialogues
	 * @param int $app_id
	 */
	public function get_total_dialogues($app_id) 
	{

		$query = $this->db->where("app_id", $app_id)->get("messages_dialogues");

		return $query->num_rows();
	}

	/*
	 * Get listdialogues
	 * @param int $limit, int $start, int $app_id
	 */
	public function get_all_dialogues($limit, $start, $app_id) 
	{
		$this->db->limit($limit, $start);

		$query = $this->db->where("app_id", $app_id)->order_by('id', 'desc')->get("messages_dialogues");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list dialogues
	 * @param int $app_id
	 */
	public function get_dialogues($app_id) 
	{
		$where = array('app_id' => $app_id);

		// all elements
		$query = $this->db->where($where)->order_by('id', 'desc')->get("messages_dialogues");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Total messages
	 * @param int $app_id, string $search
	 */
	public function get_total($app_id, $search) 
	{
		if (!$search) {

			// all galleries
			$query = $this->db->where("app_id", $app_id)->get("messages");

		} else {

			$query = $this->db->where("app_id", $app_id)->like('message', $search)->get("messages");

		}

		return $query->num_rows();
	}

	/*
	 * Total messages
	 * @param int $app_id, int $dialogue
	 */
	public function get_total_all_for_request($app_id, $dialogue)
	{
		$where = array('app_id' => $app_id, 'dialogue' => $dialogue);

		$query = $this->db->where($where)->get("messages");

		return $query->num_rows();
	}

	/*
	 * Total unread messages
	 * @param int $app_id, int $dialogue, string $search
	 */
	public function get_total_unread_for_request($app_id, $dialogue)
	{
		$where = array('app_id' => $app_id, 'dialogue' => $dialogue, 'status' => 1, 'type' => 2);

		$query = $this->db->where($where)->get("messages");

		return $query->num_rows();
	}

	/*
	 * Total all unread messages for app
	 * @param int $app_id, string $search
	 */
	public function get_total_unread_all($app_id)
	{
		$where = array('app_id' => $app_id, 'status' => 1, 'type' => 2);

		$query = $this->db->where($where)->get("messages");

		return $query->num_rows();
	}

	/*
	 * Get list unread messages
	 * @param int $app_id, int $dialogue
	 */
	public function get_messages_unread($app_id, $dialogue) 
	{
		$where = array('app_id' => $app_id, 'dialogue' => $dialogue, 'status' => 1, 'type' => 2);

		// all elements
		$query = $this->db->where($where)->order_by('id', 'desc')->get("messages");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Dialogue detail
	 * @param int $id
	 */
	public function get_dialogue_detail($id) 
	{
		$where = array('id' => $id);
		$query = $this->db->where($where)->get("messages_dialogues");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Dialogue detail for user
	 * @param string $token
	 */
	public function get_dialogue_detail_for_user($token) 
	{
		$where = array('token' => $token);
		$query = $this->db->where($where)->get("messages_dialogues");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Total all unread messages for user chat
	 * @param int $app_id, int $dialogue_id
	 */
	public function get_total_unread_for_user($app_id, $dialogue_id)
	{
		$where = array('app_id' => $app_id, 'dialogue' => $dialogue_id, 'status' => 1, 'type' => 1);

		$query = $this->db->where($where)->get("messages");

		return $query->num_rows();
	}

	/*
	 * Dialogue detail from user
	 * @param int $user
	 */
	public function get_dialogue_detail_from_user($user) 
	{
		$where = array('user' => $user);
		$query = $this->db->where($where)->get("messages_dialogues");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Last message for dialogue
	 * @param int $id
	 */
	public function get_dialogue_last_message($id) 
	{
		$where = array('dialogue' => $id, 'status' => 1);
		$query = $this->db->where($where)->order_by('id','desc')->limit(1)->get("messages");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Old message for dialogue
	 * @param int $id
	 */
	public function get_dialogue_old_message($id) 
	{
		$where = array('dialogue' => $id);
		$query = $this->db->where($where)->order_by('id','desc')->limit(1)->get("messages");
	    $row = $query->row();
	    return $row;
	}

	/*
	 * Get list messages
	 * @param int $app_id, int $dialogue
	 */
	public function get_messages($app_id, $dialogue) 
	{
		$where = array('app_id' => $app_id, 'dialogue' => $dialogue);

		// all elements
		$query = $this->db->where($where)->order_by('id', 'asc')->get("messages");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list start messages
	 * @param int $app_id, int $dialogue
	 */
	public function get_start_messages($app_id, $dialogue) 
	{
		$where = array('app_id' => $app_id, 'dialogue' => $dialogue);

		// all elements
		$query = $this->db->where($where)->order_by('id', 'asc')->get("messages");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get list new messages for user
	 * @param int $app_id, int $dialogue
	 */
	public function get_new_messages_for_user($app_id, $dialogue) 
	{
		$where = array('app_id' => $app_id, 'dialogue' => $dialogue, 'status' => 1, 'type' => 1);

		// all elements
		$query = $this->db->where($where)->order_by('id', 'asc')->get("messages");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Add message
	 * @param array $data
	 */
	public function add_message($data)
	{
		$this->db->insert("messages", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Update message
	 * @param int $message_id, array $data
	 */
	public function update_message($message_id, $data) 
	{
		$where = array('id' => $message_id);
		$this->db->where($where)->update("messages", $data);
	}

	/*
	 * Get all messages for clear
	 * @param int $dialogue
	 */
	public function get_messages_for_delete($dialogue) 
	{
		$where = array('dialogue' => $dialogue);
		$query = $this->db->where($where)->get("messages");

		foreach ($query->result_array() as $row)
		{
		    $data[] = $row['id'];
		}
	 
	    return $data;
	}

	/*
	 * Delete all messages for dialogue
	 * @param array $elements
	 */
	public function del_all_messages($elements) 
	{
		$this->db->where_in('id', $elements)->delete("messages");
	}

	/*
	 * Update dialogue
	 * @param int $dialogue_id, array $data
	 */
	public function update_dialogue($dialogue_id, $data) 
	{
		$where = array('id' => $dialogue_id);
		$this->db->where($where)->update("messages_dialogues", $data);
	}

	/*
	 * Add dialogue
	 * @param array $data
	 */
	public function add_dialogue($data)
	{
		$this->db->insert("messages_dialogues", $data);
    	return $this->db->insert_id();
	}

	/*
	 * Get search result
	 * @param int $limit, int $start, int $app_id, string $search
	 */
	public function get_all_messages_for_search($limit, $start, $app_id, $search) 
	{
		$this->db->limit($limit, $start);

		$query = $this->db->where("app_id", $app_id)->like('message', $search)->order_by('id', 'desc')->get("messages");

		if ($query->num_rows() > 0) 
	    {
	      foreach ($query->result() as $row) 
	      {
	        $data[] = $row;
	      }
	             
	      return $data;
	    }
	 
	    return false;
	}

	/*
	 * Get all messages for app
	 * @param int $app_id
	 */
	public function get_all_messages_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("messages");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Get all messages for app
	 * @param int $app_id
	 */
	public function get_all_dialogues_for_app($app_id) 
	{
		$where = array('app_id' => $app_id);
		$query = $this->db->where($where)->get("messages_dialogues");

        if ($query->num_rows() > 0)
        {
            foreach ($query->result() as $row)
            {
                $data[] = $row;
            }

            return $data;
        }

        return false;
	}

	/*
	 * Delete message
	 * @param int $id
	 */
  	public function del_message($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("messages");
	}

	/*
	 * Delete dialogues
	 * @param int $id
	 */
  	public function del_dialogues($id) 
	{
		$where = array('id' => $id);
		$this->db->where($where)->delete("messages_dialogues");
	}

}