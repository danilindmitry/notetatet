<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <title><?php echo $title;?></title>

        <link href="<?php echo base_url();?>themes/alstrapp/css/bootstrap.css" rel="stylesheet">
        <link href="<?php echo base_url();?>themes/alstrapp/css/alstrapp.css" rel="stylesheet">
        <link href="<?php echo base_url();?>themes/alstrapp/css/themify-icons.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="<?php echo base_url();?>themes/alstrapp/js/plugins/summernote/summernote-bs4.css" rel="stylesheet">
        <link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">
        <link href="<?php echo base_url();?>themes/alstrapp/js/plugins/dates/css/datepicker.css" rel="stylesheet">

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.js"></script>

        <!-- Codemirror-->
        <link href="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/lib/codemirror.css" rel="stylesheet">
        <link href="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/theme/material.css" rel="stylesheet">
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/lib/codemirror.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/edit/matchbrackets.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/hint/show-hint.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/hint/xml-hint.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/hint/html-hint.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/mode/xml/xml.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/mode/javascript/javascript.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/mode/css/css.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/display/autorefresh.js"></script>

        <script src="<?php echo base_url();?>themes/alstrapp/js/jquery/jquery.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/summernote/summernote-bs4.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/summernote/plugin/ddclass/summernote-ext-addclass.js"></script>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.28.11/dist/sweetalert2.all.min.js"></script>
    </head>

    <body>
        
        <div class="wrapper">

            <nav id="sidebar-a">
                <div class="sidebar-header">
                    <img src="<?php echo base_url();?>themes/alstrapp/img/alstrapp_logo_mini.png" class="logo-image">
                </div>
                <ul class="list-unstyled components">
                    <li>
                        <a href="#" data-toggle="modal" data-target="#add_app" class="btn btn-success btn-circle"><span class="ti-plus"></span></a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('my/apps');?>" class="btn btn-secondary btn-circle" data-toggle="tooltip" data-placement="right" title="<?php echo $this->lang->line('layout_1');?>"><span class="ti-layout-grid2"></span></a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('my/configuration');?>" class="btn btn-secondary btn-circle" data-toggle="tooltip" data-placement="right" title="<?php echo $this->lang->line('layout_2');?>"><span class="ti-settings"></span></a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('my/account');?>" class="btn btn-secondary btn-circle" data-toggle="tooltip" data-placement="right" title="<?php echo $this->lang->line('layout_3');?>"><span class="ti-id-badge"></span></a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('auth/logout');?>" class="btn btn-danger btn-circle" data-toggle="tooltip" data-placement="right" title="<?php echo $this->lang->line('layout_4');?>"><span class="ti-power-off"></span></a>
                    </li>
                </ul>
  
            </nav>

            <?php if ($this->session->flashdata('error')) : // Error message ?>
            <div class="alert-notify">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $this->session->flashdata('error');?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('success')) : // Success message ?>
            <div class="alert-notify">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $this->session->flashdata('success');?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <!-- Page Content Holder -->
            <div id="content_app">
                
                <?php echo $contents;?>

            </div>

        </div>

        <!-- Add app -->
        <div class="modal" id="add_app" tabindex="-1" role="dialog" aria-labelledby="add_app" aria-hidden="true" data-backdrop="static">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content border-none">
                    <div id="step">
                        <div class="row mb-5">
                            <div class="col-md-10">
                                <h2><span class="text-primary"><?php echo $this->lang->line('layout_43');?></span> <?php echo $this->lang->line('layout_44');?></h2>
                            </div>
                            <div class="col-md-2 text-right">
                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card-app">
                                    <a href="#" onclick="show('id1');">
                                        <div class="card">
                                            <img src="<?php echo base_url();?>themes/alstrapp/img/two-build.png" class="card-img-top">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo $this->lang->line('layout_39');?></h5>
                                                <p class="card-text"><?php echo $this->lang->line('layout_40');?></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card-app">
                                    <a href="#" onclick="show('id2');">
                                        <div class="card">
                                            <img src="<?php echo base_url();?>themes/alstrapp/img/one-build.png" class="card-img-top">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo $this->lang->line('layout_41');?></h5>
                                                <p class="card-text"><?php echo $this->lang->line('layout_42');?></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="id1" style="display:none">
                        <?php echo form_open(site_url("my/apps/create_app")) ?>
                        <input type="hidden" name="type" value="0">
                        <input type="hidden" name="source_path" value="0">
                        <div class="row mb-5">
                            <div class="col-md-10">
                                <h2><span class="text-primary"><?php echo $this->lang->line('layout_45');?></span> <?php echo $this->lang->line('layout_46');?></h2>
                            </div>
                            <div class="col-md-2 text-right">
                                <a href="#" class="text-muted h4" onclick="hide('id1');"><span class="ti-arrow-left"></span></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_6');?></label>
                                    <input type="text" class="form-control" name="name" placeholder="Alstrapp">
                                </div>
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_7');?></label>
                                    <input type="text" class="form-control" name="id_app" placeholder="com.alstrapp.testapp">
                                </div>
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_8');?></label>
                                    <select class="form-control" name="template">
                                        <?php $design_list = $this->template->get_design_list(); ?>
                                        <?php if ($design_list) : ?>
                                        <?php foreach ($design_list as $data_template) : ?>
                                        <option value="<?php echo $data_template->id; ?>"><?php echo $data_template->name; ?></option>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_9');?></label>
                                    <select class="form-control" name="device">
                                        <option value="1">Material</option>
                                        <option value="2">iOS</option>
                                        <option value="3">Auto Detect Device</option>
                                    </select>
                                </div>
                                <div class="text-right">
                                    <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('layout_11');?></button>
                                    <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('layout_12');?></button>
                                </div>
                            </div>
                        </div>
                        <?php echo form_close(); ?> 
                    </div>
                    <div id="id2" style="display:none">
                        <?php echo form_open(site_url("my/apps/create_app")) ?>
                        <input type="hidden" name="type" value="1">
                        <input type="hidden" name="device" value="3">
                        <div class="row mb-5">
                            <div class="col-md-10">
                                <h2><span class="text-primary"><?php echo $this->lang->line('layout_45');?></span> <?php echo $this->lang->line('layout_47');?></h2>
                            </div>
                            <div class="col-md-2 text-right">
                                <a href="#" class="text-muted h4" onclick="hide('id2');"><span class="ti-arrow-left"></span></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_6');?></label>
                                    <input type="text" class="form-control" name="name" placeholder="Alstrapp">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_7');?></label>
                                    <input type="text" class="form-control" name="id_app" placeholder="com.alstrapp.testapp">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_8');?></label>
                                    <select class="form-control" name="template">
                                        <?php $design_list = $this->template->get_design_list(); ?>
                                        <?php if ($design_list) : ?>
                                        <?php foreach ($design_list as $data_template) : ?>
                                        <option value="<?php echo $data_template->id; ?>"><?php echo $data_template->name; ?></option>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_48');?></label>
                                    <input type="text" class="form-control" name="source_path" placeholder="https://alstrapp.com">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="text-right">
                                    <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('layout_11');?></button>
                                    <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('layout_12');?></button>
                                </div>
                            </div>
                        </div>
                        <?php echo form_close(); ?> 
                    </div>
                </div>
            </div>
        </div>

        <script src="<?php echo base_url();?>themes/alstrapp/js/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/jquery-easing/jquery.easing.min.js"></script>

        <script type="text/javascript">
            function show(elementId) { 
             document.getElementById("step").style.display="none";
             document.getElementById(elementId).style.display="block";
            }
        </script>

        <script type="text/javascript">
            function hide(elementId) { 
             document.getElementById("step").style.display="block";
             document.getElementById(elementId).style.display="none";
            }
        </script>

        <script>
            $(function () {
              $('[data-toggle="tooltip"]').tooltip()
            })
        </script>

    </body>

</html>