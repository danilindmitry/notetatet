<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <title><?php echo $title;?></title>

        <link href="<?php echo base_url();?>themes/alstrapp/css/bootstrap.css" rel="stylesheet">
        <link href="<?php echo base_url();?>themes/alstrapp/css/alstrapp.css" rel="stylesheet">
        <link href="<?php echo base_url();?>themes/alstrapp/css/themify-icons.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="<?php echo base_url();?>themes/alstrapp/js/plugins/summernote/summernote-bs4.css" rel="stylesheet">
        <link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css">
        <link href="<?php echo base_url();?>themes/alstrapp/js/plugins/dates/css/datepicker.css" rel="stylesheet">

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.bundle.js"></script>

        <!-- Codemirror-->
        <link href="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/lib/codemirror.css" rel="stylesheet">
        <link href="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/theme/material.css" rel="stylesheet">
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/lib/codemirror.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/edit/matchbrackets.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/hint/show-hint.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/hint/xml-hint.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/hint/html-hint.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/mode/xml/xml.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/mode/javascript/javascript.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/mode/css/css.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/codemirror/addon/display/autorefresh.js"></script>

        <script src="<?php echo base_url();?>themes/alstrapp/js/jquery/jquery.min.js"></script>
        <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/summernote/summernote-bs4.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/summernote/plugin/ddclass/summernote-ext-addclass.js"></script>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.28.11/dist/sweetalert2.all.min.js"></script>
    </head>

    <body>
        
        <div class="wrapper">

            <nav id="sidebar-a">
                <div class="sidebar-header">
                    <img src="<?php echo base_url();?>themes/alstrapp/img/alstrapp_logo_mini.png" class="logo-image">
                </div>
                <ul class="list-unstyled components">
                    <li>
                        <a href="#" data-toggle="modal" data-target="#add_app" class="btn btn-success btn-circle"><span class="ti-plus"></span></a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('my/apps');?>" class="btn btn-secondary btn-circle" data-toggle="tooltip" data-placement="right" title="<?php echo $this->lang->line('layout_1');?>"><span class="ti-layout-grid2"></span></a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('my/configuration');?>" class="btn btn-secondary btn-circle" data-toggle="tooltip" data-placement="right" title="<?php echo $this->lang->line('layout_2');?>"><span class="ti-settings"></span></a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('my/account');?>" class="btn btn-secondary btn-circle" data-toggle="tooltip" data-placement="right" title="<?php echo $this->lang->line('layout_3');?>"><span class="ti-id-badge"></span></a>
                    </li>
                    <li>
                        <a href="<?php echo base_url('auth/logout');?>" class="btn btn-danger btn-circle" data-toggle="tooltip" data-placement="right" title="<?php echo $this->lang->line('layout_4');?>"><span class="ti-power-off"></span></a>
                    </li>
                </ul>
            </nav>

            <nav id="sidebar">
                <div class="sidebar-header">
                    <div class="row">
                        <div class="col-md-3">
                            <img src="<?php echo $this->template->get_icon_app($app->id); ?>" class="app-logo">
                        </div>
                        <div class="col-md-9">
                            <a href="<?php echo base_url('my/apps/'.$app->id.'/dashboard');?>"><?php echo $app->name;?></a>
                            <p class="text-muted">ID: <?php echo $app->id;?></p>
                        </div>
                    </div>
                </div>
                <ul class="list-unstyled components">
                    <li class="<?php echo activate_menu('dashboard'); ?>">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/dashboard');?>"><span class="ti-dashboard mr-3"></span><?php echo $this->lang->line('layout_13');?></a>
                    </li>
                    <?php if (!$app->type) : ?>
                    <li class="<?php echo activate_menu('navigation'); ?>">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/navigation');?>"><span class="ti-view-list-alt mr-3"></span><?php echo $this->lang->line('layout_14');?></a>
                    </li>
                    <li class="<?php echo activate_menu('posts'); ?>">
                        <a href="#postSubmenu" data-toggle="collapse" aria-expanded="<?php if (activate_ul_menu('posts')) : ?>true<?php else : ?>false<?php endif; ?>"><span class="ti-pin-alt mr-3"></span><?php echo $this->lang->line('layout_15');?></a>
                        <ul class="collapse list-unstyled <?php echo activate_ul_menu('posts'); ?>" id="postSubmenu">
                            <li class="<?php if ($this->uri->segment(5) == 'add_post') : ?>active<?php else : ?><?php endif; ?>"><a href="<?php echo base_url('my/apps/'.$app->id.'/posts/add_post');?>"><?php echo $this->lang->line('layout_16');?></a></li>
                            <li class="<?php if (!$this->uri->segment(5) & $this->uri->segment(4) == 'posts') : ?>active<?php else : ?><?php endif; ?>"><a href="<?php echo base_url('my/apps/'.$app->id.'/posts');?>"><?php echo $this->lang->line('layout_17');?></a></li>
                            <li class="<?php if ($this->uri->segment(5) == 'categories') : ?>active<?php else : ?><?php endif; ?>"><a href="<?php echo base_url('my/apps/'.$app->id.'/posts/categories');?>"><?php echo $this->lang->line('layout_18');?></a></li>
                        </ul>
                    </li>
                    <li class="<?php echo activate_menu('comments'); ?>">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/comments');?>"><span class="ti-comment-alt mr-3"></span><?php echo $this->lang->line('layout_19');?><?php if ($this->template->get_total_unbulished_comments_for_app_list($app->id)) : ?><span class="badge badge-danger"><?php echo $this->template->get_total_unbulished_comments_for_app_list($app->id); ?></span><?php endif; ?></a>
                    </li>
                    <li class="<?php echo activate_menu('users'); ?>">
                        <a href="#userSubmenu" data-toggle="collapse" aria-expanded="<?php if (activate_ul_menu('users')) : ?>true<?php else : ?>false<?php endif; ?>"><span class="ti-user mr-3"></span><?php echo $this->lang->line('layout_20');?></a>
                        <ul class="collapse list-unstyled <?php echo activate_ul_menu('users'); ?>" id="userSubmenu">
                            <li class="<?php if ($this->uri->segment(5) == 'add_user') : ?>active<?php else : ?><?php endif; ?>"><a href="<?php echo base_url('my/apps/'.$app->id.'/users/add_user');?>"><?php echo $this->lang->line('layout_21');?></a></li>
                            <li class="<?php if (!$this->uri->segment(5) & $this->uri->segment(4) == 'users') : ?>active<?php else : ?><?php endif; ?>"><a href="<?php echo base_url('my/apps/'.$app->id.'/users');?>"><?php echo $this->lang->line('layout_22');?></a></li>
                            <li class="<?php if ($this->uri->segment(5) == 'groups' OR $this->uri->segment(5) == 'add_group') : ?>active<?php else : ?><?php endif; ?>"><a href="<?php echo base_url('my/apps/'.$app->id.'/users/groups');?>"><?php echo $this->lang->line('layout_23');?></a></li>
                        </ul>
                    </li>
                    <li class="<?php echo activate_menu('galleries'); ?>">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/galleries');?>"><span class="ti-image mr-3"></span><?php echo $this->lang->line('layout_24');?></a>
                    </li>
                    <li class="<?php echo activate_menu('forms'); ?>">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/forms');?>"><span class="ti-check-box mr-3"></span><?php echo $this->lang->line('layout_25');?><?php if ($this->template->get_total_unread_forms_for_app_list($app->id)) : ?><span class="badge badge-danger"><?php echo $this->template->get_total_unread_forms_for_app_list($app->id); ?></span><?php endif; ?></a>
                    </li>
                    <li class="<?php echo activate_menu('messages'); ?>">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/messages');?>"><span class="ti-comments mr-3"></span><?php echo $this->lang->line('layout_26');?><?php if ($this->template->get_total_unread_messages_for_app_list($app->id)) : ?><span class="badge badge-danger"><?php echo $this->template->get_total_unread_messages_for_app_list($app->id); ?></span><?php endif; ?></a>
                    </li>
                    <li class="<?php echo activate_menu('notifications'); ?>">
                        <a href="#notifySubmenu" data-toggle="collapse" aria-expanded="<?php if (activate_ul_menu('notifications')) : ?>true<?php else : ?>false<?php endif; ?>"><span class="ti-announcement mr-3"></span><?php echo $this->lang->line('layout_27');?></a>
                        <ul class="collapse list-unstyled <?php echo activate_ul_menu('notifications'); ?>" id="notifySubmenu">
                            <li class="<?php if ($this->uri->segment(5) == 'newsletter' OR $this->uri->segment(5) == 'newsletter') : ?>active<?php else : ?><?php endif; ?>"><a href="<?php echo base_url('my/apps/'.$app->id.'/notifications/newsletter');?>"><?php echo $this->lang->line('layout_28');?></a></li>
                            <li class="<?php if (!$this->uri->segment(5) & $this->uri->segment(4) == 'notifications' OR $this->uri->segment(5) == 'planned' OR $this->uri->segment(5) == 'archive') : ?>active<?php else : ?><?php endif; ?>"><a href="<?php echo base_url('my/apps/'.$app->id.'/notifications');?>"><?php echo $this->lang->line('layout_29');?></a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <li class="<?php echo activate_menu('notifications'); ?>">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/notifications/newsletter');?>"><span class="ti-announcement mr-3"></span><?php echo $this->lang->line('layout_28');?></a>
                    </li>
                    <li class="<?php echo activate_menu('statistics'); ?>">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/statistics');?>"><span class="ti-pulse mr-3"></span><?php echo $this->lang->line('layout_30');?></a>
                    </li>
                    <li class="<?php echo activate_menu('settings'); ?>">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/settings');?>"><span class="ti-panel mr-3"></span><?php echo $this->lang->line('layout_31');?></a>
                    </li>
                </ul>
            </nav>

            <?php if ($this->session->flashdata('error')) : // Error message ?>
            <div class="alert-notify-cms">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $this->session->flashdata('error');?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <!-- Page Content Holder -->
            <div id="content">
                <div class="row mb-2">
                    <div class="col-md-6">
                        <small class="text-muted"><?php echo $this->lang->line('layout_32');?> <?php echo $app->version;?> / <?php echo $this->lang->line('layout_33');?> <?php echo $app->published;?></small>
                    </div>
                    <div class="col-md-6 text-right">
                        <?php if ($app->status == 1) : ?>
                        <span class="text-muted mr-4"><span class="ti-eraser mr-2"></span><?php echo $this->lang->line('layout_34');?></span>
                        <?php else : ?>
                        <span class="text-success mr-4"><span class="ti-check mr-2"></span><?php echo $this->lang->line('layout_35');?></span>
                        <?php endif; ?>
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/builder');?>" class="btn btn-success btn-sm mr-3"><span class="ti-wand mr-2"></span><?php echo $this->lang->line('layout_36');?></a>
                         <?php if (!$app->type) : ?>
                        <a href="#start_preview" data-toggle="modal" data-target="#exampleModal3" class="btn btn-light btn-sm"><span class="ti-eye mr-2"></span><?php echo $this->lang->line('layout_37');?></a>
                        <?php endif; ?>
                    </div>
                </div>

                
                <?php echo $contents;?>

            </div>

        </div>

        <?php if ($this->session->flashdata('success')) : // Success message ?>
        <div id="toast-success">
            <div id="img"><span class="ti-check"></span></div>
            <div id="desc">
                <?php echo $this->session->flashdata('success');?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Preview app -->
        <div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel3" aria-hidden="true" data-backdrop="static">
            <div class="modal-dialog modal-dialog-slideout" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('layout_37');?></h5>
                        <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                            <span class="ti-close"></span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div id="print_preview">
                            <div class="load-wrap-build">
                                <div class="loader"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>

        <!-- Add app -->
        <div class="modal" id="add_app" tabindex="-1" role="dialog" aria-labelledby="add_app" aria-hidden="true" data-backdrop="static">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content border-none">
                    <div id="step">
                        <div class="row mb-5">
                            <div class="col-md-10">
                                <h2><span class="text-primary"><?php echo $this->lang->line('layout_43');?></span> <?php echo $this->lang->line('layout_44');?></h2>
                            </div>
                            <div class="col-md-2 text-right">
                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card-app">
                                    <a href="#" onclick="shows('id1');">
                                        <div class="card">
                                            <img src="<?php echo base_url();?>themes/alstrapp/img/two-build.png" class="card-img-top">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo $this->lang->line('layout_39');?></h5>
                                                <p class="card-text"><?php echo $this->lang->line('layout_40');?></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card-app">
                                    <a href="#" onclick="shows('id2');">
                                        <div class="card">
                                            <img src="<?php echo base_url();?>themes/alstrapp/img/one-build.png" class="card-img-top">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo $this->lang->line('layout_41');?></h5>
                                                <p class="card-text"><?php echo $this->lang->line('layout_42');?></p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="id1" style="display:none">
                        <?php echo form_open(site_url("my/apps/create_app")) ?>
                        <input type="hidden" name="type" value="0">
                        <input type="hidden" name="source_path" value="0">
                        <div class="row mb-5">
                            <div class="col-md-10">
                                <h2><span class="text-primary"><?php echo $this->lang->line('layout_45');?></span> <?php echo $this->lang->line('layout_46');?></h2>
                            </div>
                            <div class="col-md-2 text-right">
                                <a href="#" class="text-muted h4" onclick="hide('id1');"><span class="ti-arrow-left"></span></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_6');?></label>
                                    <input type="text" class="form-control" name="name" placeholder="Alstrapp">
                                </div>
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_7');?></label>
                                    <input type="text" class="form-control" name="id_app" placeholder="com.alstrapp.testapp">
                                </div>
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_8');?></label>
                                    <select class="form-control" name="template">
                                        <?php $design_list = $this->template->get_design_list(); ?>
                                        <?php if ($design_list) : ?>
                                        <?php foreach ($design_list as $data_template) : ?>
                                        <option value="<?php echo $data_template->id; ?>"><?php echo $data_template->name; ?></option>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_9');?></label>
                                    <select class="form-control" name="device">
                                        <option value="1">Material</option>
                                        <option value="2">iOS</option>
                                        <option value="3">Auto Detect Device</option>
                                    </select>
                                </div>
                                <div class="text-right">
                                    <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('layout_11');?></button>
                                    <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('layout_12');?></button>
                                </div>
                            </div>
                        </div>
                        <?php echo form_close(); ?> 
                    </div>
                    <div id="id2" style="display:none">
                        <?php echo form_open(site_url("my/apps/create_app")) ?>
                        <input type="hidden" name="type" value="1">
                        <input type="hidden" name="device" value="3">
                        <div class="row mb-5">
                            <div class="col-md-10">
                                <h2><span class="text-primary"><?php echo $this->lang->line('layout_45');?></span> <?php echo $this->lang->line('layout_47');?></h2>
                            </div>
                            <div class="col-md-2 text-right">
                                <a href="#" class="text-muted h4" onclick="hide('id2');"><span class="ti-arrow-left"></span></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_6');?></label>
                                    <input type="text" class="form-control" name="name" placeholder="Alstrapp">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_7');?></label>
                                    <input type="text" class="form-control" name="id_app" placeholder="com.alstrapp.testapp">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_8');?></label>
                                    <select class="form-control" name="template">
                                        <?php $design_list = $this->template->get_design_list(); ?>
                                        <?php if ($design_list) : ?>
                                        <?php foreach ($design_list as $data_template) : ?>
                                        <option value="<?php echo $data_template->id; ?>"><?php echo $data_template->name; ?></option>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('layout_48');?></label>
                                    <input type="text" class="form-control" name="source_path" placeholder="https://alstrapp.com">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="text-right">
                                    <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('layout_11');?></button>
                                    <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('layout_12');?></button>
                                </div>
                            </div>
                        </div>
                        <?php echo form_close(); ?> 
                    </div>
                </div>
            </div>
        </div>

        <script src="<?php echo base_url();?>themes/alstrapp/js/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/jquery-easing/jquery.easing.min.js"></script>
        <script src="<?php echo base_url();?>themes/alstrapp/js/plugins/dates/js/datepicker.min.js"></script>
        <script>
            $.fn.datepicker.language['ru'] = {days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
            daysShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            daysMin: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
            months: ['January','February','March','April','May','June', 'July','August','September','October','November','December'],
            monthsShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            today: 'Today',
            clear: 'Clear',
            dateFormat: 'yyyy-mm-dd',
            timeFormat: 'hh:ii',
            firstDay: 0}
        </script>

        <script type="text/javascript">
            function shows(elementId) { 
             document.getElementById("step").style.display="none";
             document.getElementById(elementId).style.display="block";
            }
        </script>

        <script type="text/javascript">
            function hide(elementId) { 
             document.getElementById("step").style.display="block";
             document.getElementById(elementId).style.display="none";
            }
        </script>

        <?php if ($this->session->flashdata('success')) : // Success message ?>
        <script>
            var x = document.getElementById("toast-success")
            x.className = "show";
            setTimeout(function(){ x.className = x.className.replace("show", ""); }, 5000);
        </script>
        <?php endif; ?>

        <script>
            $(document).ready(function() {
              $("#sidebarCollapse").on("click", function() {
                $("#sidebar").toggleClass("active");
                $(this).toggleClass("active");
              });
            });
        </script>

        <script>
            $(function () {
              $('[data-toggle="tooltip"]').tooltip()
            })
        </script>

        <script>
        $('#categories_sort').sortable({
            update: function (event, ui) {
                var data = $(this).sortable('serialize');

                 $.ajax({
                    data: data,
                    type: 'GET',
                    url: '<?php echo base_url('my/posts/update_sort_categories/'.$app->id.'');?>'
                });
            }
        });
        </script>

        <script>
        $('#form_elements_sort').sortable({
            update: function (event, ui) {
                var data = $(this).sortable('serialize');

                 $.ajax({
                    data: data,
                    type: 'GET',
                    url: '<?php echo base_url('my/forms/update_sort_elements/'.$app->id.'');?>'
                });
            }
        });
        </script>

        <script>
        $('#menu_sort').sortable({
            update: function (event, ui) {
                var data = $(this).sortable('serialize');

                 $.ajax({
                    data: data,
                    type: 'GET',
                    url: '<?php echo base_url('my/navigation/update_sort_menu/'.$app->id.'');?>'
                });
            }
        });
        </script>

        <!-- Multiupload images script -->
        <script>
            $('.inputfile').each(function() {
              var $input     = $(this),
                  $label     = $input.next('label'),
                  labelVal = $label.html();

              $input.on('change', function(e) {
                var fileName = '';

                if(this.files && this.files.length > 1)
                  fileName = (this.getAttribute('data-multiple-caption') || '').replace('{count}', this.files.length);
                else if(e.target.value)
                  fileName = e.target.value.split('\\').pop();

                if(fileName)
                  $label.find('span').html(fileName);
                else
                  $label.html(labelVal);
              });
            });

        </script>

        <script>
            $('a[href$="#start_preview"]').on( "click", function() {
                $.ajax({
                    type: 'GET',
                    url: "<?php echo base_url('my/apps/get_preview/'.$app->id.'');?>",  
                    success: function(start_preview) {

                        var previer_response = JSON.parse(start_preview);

                        if (previer_response.event == 'success') { // success request

                            successPreview = '';

                            previewLi = '';

                            previewLi += '<div class="phone">';
                            previewLi += '<div class="iframe-wrapper">';
                            previewLi += '<iframe id="mobile-preview-content" class="preview-frame" src="'+ previer_response.link +'"></iframe>';
                            previewLi += '</div>';
                            previewLi += '</div>';

                            successPreview += previewLi;

                            $("#print_preview").html(successPreview);

                        } else {

                            errorPreview = '';

                            previewerrorLi = '';

                            previewerrorLi += '<p class="text-danger">Failed to get preview link.</p>';

                            errorPreview += previewerrorLi;

                            $("#print_preview").html(errorPreview);

                        }

                    },
                    error: function(error_preview) {

                        errorPreview = '';

                        previewerrorLi = '';

                        previewerrorLi += '<p class="text-danger">Failed to get preview link.</p>';

                        errorPreview += previewerrorLi;

                        $("#print_preview").html(errorPreview);

                    }
                });
            });
        </script>

    </body>

</html>