 <script>
    $(document).ready(function() {
        $('#summernote').summernote({
            height: 500,
            toolbar: [
                // [groupName, [list of button]]
                ['style', ['bold', 'italic', 'underline', 'clear']],
                ['fontsize', ['fontsize']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['insert', ['picture', 'video', 'link']],
                ['misc', ['fullscreen', 'codeview']]
            ],
        });
    });
</script>

<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('post_22');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-all-tab" data-toggle="tab" href="#nav-all" role="tab" aria-controls="nav-all" aria-selected="true"><span class="ti-pencil-alt mr-2"></span><?php echo $this->lang->line('post_2');?></a>
                            <a class="nav-item nav-link" id="nav-settings-tab" data-toggle="tab" href="#nav-settings" role="tab" aria-controls="nav-settings" aria-selected="false"><span class="ti-settings mr-2"></span><?php echo $this->lang->line('post_3');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/posts/create_post')) ?>
    <div class="row">
        <div class="col-md-12">
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane show active" id="nav-all" role="tabpanel" aria-labelledby="nav-home-all">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('post_23');?></label>
                                <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('post_5');?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('post_6');?></label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="image" onchange="$('#upload-file-info').html(this.files[0].name)">
                                    <label class="custom-file-label" for="customFile"><span id="upload-file-info"></span></label>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('post_7');?></label>
                                <select class="form-control form-control-sm" name="status">
                                    <option value="1"><?php echo $this->lang->line('post_8');?></option>
                                    <option value="2"><?php echo $this->lang->line('post_9');?></option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('post_24');?></label>
                                <select class="form-control form-control-sm" name="category">
                                    <?php if ($categories) : ?>
                                    <?php foreach ($categories as $data_categories) : ?>
                                    <option value="<?php echo $data_categories->id; ?>"><?php echo $data_categories->name; ?></option>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('post_25');?></label>
                                <textarea class="form-control form-control-sm" name="info" rows="7"></textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('post_26');?></label>
                                <textarea id="summernote" name="content"></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 mb-4">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('post_27');?></label>
                                <input type="text" class="form-control form-control-sm" name="author" placeholder="Alstrapp team">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="nav-settings" role="tabpanel" aria-labelledby="nav-settings-tab">
                    <div>
                        <div class="form-group row">
                            <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo $this->lang->line('post_28');?></label>
                            <div class="col-sm-10">
                                <select class="form-control form-control-sm" name="gallery">
                                    <option value="0"><?php echo $this->lang->line('post_29');?></option>
                                    <?php if ($galleries) : ?>
                                    <?php foreach ($galleries as $data_galleries) : ?>
                                    <option value="<?php echo $data_galleries->id; ?>"><?php echo $data_galleries->name; ?></option>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo $this->lang->line('post_11');?></label>
                            <div class="col-sm-10">
                                <select class="form-control form-control-sm" name="rights">
                                    <option value="0"><?php echo $this->lang->line('post_12');?></option>
                                    <option value="1"><?php echo $this->lang->line('post_13');?></option>
                                    <option value="2"><?php echo $this->lang->line('post_14');?></option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo $this->lang->line('post_14');?></label>
                            <div class="col-sm-10">
                                <select class="form-control form-control-sm" name="group">
                                    <option value="0"><?php echo $this->lang->line('post_16');?></option>
                                    <?php if ($groups_list) : ?>
                                    <?php foreach ($groups_list as $data_group) : ?>
                                    <option value="<?php echo $data_group->id; ?>"><?php echo $data_group->name; ?></option>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo $this->lang->line('post_30');?></label>
                            <div class="col-sm-10">
                                <select class="form-control form-control-sm" name="comments">
                                    <option value="1"><?php echo $this->lang->line('post_31');?></option>
                                    <option value="2"><?php echo $this->lang->line('post_32');?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('post_21');?></button>
        </div>
    </div>
    <?php echo form_close(); ?> 
</div>