<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('post_42');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-all-tab" data-toggle="tab" href="#nav-all" role="tab" aria-controls="nav-all" aria-selected="true"><span class="ti-pin-alt mr-2"></span><?php echo $this->lang->line('post_64');?></a>
                            <a class="nav-item nav-link" id="nav-search-tab" data-toggle="tab" href="#nav-search" role="tab" aria-controls="nav-search" aria-selected="false"><span class="ti-search mr-2"></span><?php echo $this->lang->line('post_35');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane show active" id="nav-all" role="tabpanel" aria-labelledby="nav-home-all">
                    <div class="row mb-head">
                        <div class="col-md-7">
                            <?php if (!isset($_GET['search'])) : ?>
                                <?php if (!isset($_GET['category'])) : ?>
                                <h5><?php echo $this->lang->line('post_64');?> - <?php echo $total_records; ?></h5>
                                <?php else : ?>
                                <h5><?php echo $this->template->get_name_post_category($_GET['category']); ?> - <?php echo $total_records; ?></h5>
                                <?php endif; ?>
                            <?php else : ?>
                            <h5 class="mb-0"><?php echo $this->lang->line('post_38');?> - <?php echo $total_records; ?></h5>
                            <small class="text-muted"><?php echo $this->lang->line('post_39');?> "<?php echo $_GET['search'] ?>"</small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-5 text-right">
                            <?php echo form_open(site_url('my/apps/'.$app->id.'/posts/?'), array('method'=>'get')) ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <select class="form-control form-control-sm" name="category" onchange="this.form.submit()">
                                        <option><?php echo $this->lang->line('post_65');?></option>
                                        <?php if ($categories) : ?>
                                        <?php foreach ($categories as $data_category) : ?>
                                        <option value="<?php echo $data_category->id; ?>"><?php echo $data_category->name; ?></option>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <?php echo form_close(); ?> 
                                <div class="col-md-6">
                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/posts/add_post');?>" class="btn btn-success btn-block btn-sm"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('post_22');?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php if ($total_records) : ?>
                            <table class="table table-hover">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col"><?php echo $this->lang->line('post_23');?></th>
                                        <th scope="col"><?php echo $this->lang->line('post_27');?></th>
                                        <th scope="col"><?php echo $this->lang->line('post_66');?></th>
                                        <th class="text-center" scope="col"><?php echo $this->lang->line('post_30');?></th>
                                        <th class="text-center" scope="col"><?php echo $this->lang->line('post_67');?></th>
                                        <th scope="col"><?php echo $this->lang->line('post_43');?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($posts as $data) : ?>
                                    <tr>
                                        <td width="25%">
                                            <?php if ($data->status == 1) : ?><span class="ti-check text-success mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo $this->lang->line('post_8');?>"></span><?php else : ?><span class="ti-close text-danger mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo $this->lang->line('post_9');?>"></span><?php endif; ?><?php echo $data->name; ?></br>
                                            <small><a href="<?php echo base_url('my/apps/'.$app->id.'/posts/edit_post/'.$data->id.'');?>" class="text-muted mr-2"><span class="ti-pencil mr-1"></span><?php echo $this->lang->line('post_44');?></a><?php if ($data->status == 1) : ?><a href="<?php echo base_url('my/apps/'.$app->id.'/posts/unpublish_post/'.$data->id.'');?>" class="text-muted mr-2"><span class="ti-lock mr-1"></span><?php echo $this->lang->line('post_45');?></a><?php else : ?><a href="<?php echo base_url('my/apps/'.$app->id.'/posts/publish_post/'.$data->id.'');?>" class="text-success mr-2"><span class="ti-lock mr-1"></span><?php echo $this->lang->line('post_46');?></a><?php endif; ?><a href="#" data-toggle="modal" data-target="#del_post<?php echo $data->id; ?>" class="text-danger mr-2"><span class="ti-trash mr-1"></span><?php echo $this->lang->line('post_47');?></a></small>
                                        </td>
                                        <td><?php echo $data->author; ?></td>
                                        <td><?php echo $this->template->get_name_post_category($data->category); ?></td>
                                        <td class="text-center" width="10%"><a href="#">0</a></td>
                                        <td class="text-center" width="10%"><?php echo $data->views_count; ?></td>
                                        <td width="20%"><span class="ti-calendar mr-2"></span><?php echo $data->created; ?></td>
                                    </tr>
                                     <!-- Delete post -->
                                    <div class="modal" id="del_post<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content border-none">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="row">
                                                            <div class="col-md-10">
                                                                <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                            </div>
                                                            <div class="col-md-2 text-right">
                                                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                            </div>
                                                        </div>
                                                        <h5 class="mb-4"><?php echo $this->lang->line('post_68');?> "<?php echo $data->name; ?>"</h5>
                                                        <p><?php echo $this->lang->line('post_49');?></p>
                                                        <div class="text-right">
                                                            <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('post_50');?></button>
                                                            <a href="<?php echo base_url('my/apps/'.$app->id.'/posts/delete_post/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('post_51');?>!</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php if (!empty($links)) : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $links ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!isset($_GET['search'])) : ?>
                            <div class="row justify-content-center align-items-center mt-5">
                                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                                    <div class="text-center">
                                        <h1 class="text-primary"><span class="ti-write"></span></h1>
                                        <h5><?php echo $this->lang->line('post_69');?></h5>
                                        <p class="text-muted"><?php echo $this->lang->line('post_70');?></p>
                                        <a href="<?php echo base_url('my/apps/'.$app->id.'/posts/add_post');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('post_71');?></a>
                                    </div>
                                </div>
                            </div>
                            <?php else : ?>
                            <div class="row justify-content-center align-items-center mt-5">
                                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                                    <div class="text-center">
                                        <h1 class="text-danger"><span class="ti-face-sad"></span></h1>
                                        <h5><?php echo $this->lang->line('post_55');?></h5>
                                        <p class="text-muted"><?php echo $this->lang->line('post_56');?></p>
                                        <a href="<?php echo base_url('my/apps/'.$app->id.'/posts');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('post_72');?></a>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="nav-search" role="tabpanel" aria-labelledby="nav-search-tab">
                    <?php echo form_open(site_url('my/apps/'.$app->id.'/posts/?'), array('method'=>'get')) ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-search"></span></h1>
                                <h5><?php echo $this->lang->line('post_35');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('post_73');?></p>
                            </div>
                            <input type="text" name="search" class="form-control" <?php if (isset($_GET['search'])) : ?>value="<?php echo $_GET['search'] ?>" <?php endif; ?>placeholder="<?php echo $this->lang->line('post_59');?>?">
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>