<div class="row">
	<div class="col-md-4 mx-auto">
		
		<div class="card mt-5">
		  	<div class="card-body">
		  		<?php echo form_open(site_url("auth/sign_in")) ?>
		  		<div class="row">
		  		    <div class="col-md-12 text-center mb-3">
                        <img src="<?php echo base_url();?>themes/alstrapp/img/alstrapp_logo.png">
                    </div>
                    <div class="col-md-12 text-center mb-3">
            			<h4><?php echo $this->lang->line('auth_4');?></h4>
            		</div>
                </div>
		    	<div class="row">
		    		<div class="col-md-12">
		    			<div class="form-group">
						    <label class="fw-500"><?php echo $this->lang->line('auth_5');?></label>
						    <input type="email" class="form-control" name="email" placeholder="mail@example.com">
						</div>
		    		</div>
		    		<div class="col-md-12">
		    			<div class="form-group">
						    <label class="fw-500"><?php echo $this->lang->line('auth_6');?></label>
						    <input type="password" class="form-control" name="password" placeholder="**********">
						</div>
		    		</div>
		    		<div class="col-md-12 text-center">
		    			<button type="submit" class="btn btn-primary btn-block mb-3"><?php echo $this->lang->line('auth_7');?></button>
		    			<a href="<?php echo base_url('auth/reset_password');?>" class="text-muted"><?php echo $this->lang->line('auth_8');?></a>
		    		</div>
		    	</div>
		    	<?php echo form_close(); ?> 
		 	</div>
		</div>
	</div>
</div>