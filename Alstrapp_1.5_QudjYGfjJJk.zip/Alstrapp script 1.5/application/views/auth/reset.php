<div class="row">
	<div class="col-md-4 mx-auto">
		<div class="card mt-5">
		  	<div class="card-body">
		  		<?php echo form_open(site_url("auth/start_reset_password")) ?>
		    	<div class="row">
		  		    <div class="col-md-12 text-center mb-3">
                        <img src="<?php echo base_url();?>themes/alstrapp/img/alstrapp_logo.png">
                    </div>
                    <div class="col-md-12 text-center mb-3">
            			<h4><?php echo $this->lang->line('auth_1');?></h4>
            		</div>
		    		<div class="col-md-12">
		    			<div class="form-group">
						    <label class="fw-500"><?php echo $admin->reset_question; ?></label>
						    <input type="text" class="form-control" name="answer">
						</div>
		    		</div>
		    		<div class="col-md-12 text-center">
		    			<button type="submit" class="btn btn-primary btn-block mb-3"><?php echo $this->lang->line('auth_2');?></button>
		    			<a href="<?php echo base_url('auth');?>" class="text-muted"><?php echo $this->lang->line('auth_3');?></a>
		    		</div>
		    	</div>
		    	<?php echo form_close(); ?> 
		 	</div>
		</div>
	</div>
</div>