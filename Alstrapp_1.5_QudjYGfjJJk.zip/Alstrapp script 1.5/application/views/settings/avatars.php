<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-4">
                    <h4><?php echo $this->lang->line('settings_1');?></h4>
                </div>
                <div class="col-md-8">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings');?>"><span class="ti-mobile mr-2"></span><?php echo $this->lang->line('settings_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/push');?>"><span class="ti-signal mr-2"></span><?php echo $this->lang->line('settings_3');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/settings/icons');?>"><span class="ti-image mr-2"></span><?php echo $this->lang->line('settings_4');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/emails');?>"><span class="ti-email mr-2"></span><?php echo $this->lang->line('settings_5');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="row mb-head">
                <div class="col-md-9">
                    <h5 class="mb-0"><?php echo $this->lang->line('settings_6');?></h5>
                    <small class="text-muted"><?php echo $this->lang->line('settings_7');?></small>
                </div>
                <div class="col-md-3 text-right">
                    <select class="form-control form-control-sm" name="category" onchange="location = this.value;">
                        <option value="<?php echo base_url('my/apps/'.$app->id.'/settings/avatars');?>"><?php echo $this->lang->line('settings_6');?></option>
                        <option value="<?php echo base_url('my/apps/'.$app->id.'/settings/icons');?>">Android</option>
                        <option value="<?php echo base_url('my/apps/'.$app->id.'/settings/icons_ios');?>">iOS</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('settings_9');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_10');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_11');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_12');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('uploads/avatars/'.$icon->chat_avatar.'');?>" style="width:36px">
                                </td>
                                <td>256x256</td>
                                <td><?php echo $this->lang->line('settings_13');?></td>
                                <td><?php echo $icon->chat_avatar; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_avatar')) ?>
                                    <input type="hidden" name="type" value="1">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector" type="file" style="display:none" 
                                        onchange="$('#upload-file-info').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('uploads/avatars/'.$icon->comment_avatar.'');?>" style="width:36px">
                                </td>
                                <td>256x256</td>
                                <td><?php echo $this->lang->line('settings_15');?></td>
                                <td><?php echo $icon->comment_avatar; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_avatar')) ?>
                                    <input type="hidden" name="type" value="2">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector2">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector2" type="file" style="display:none" 
                                        onchange="$('#upload-file-info2').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>