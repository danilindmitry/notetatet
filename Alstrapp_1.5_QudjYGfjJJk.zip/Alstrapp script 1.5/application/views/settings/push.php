<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-4">
                    <h4><?php echo $this->lang->line('settings_1');?></h4>
                </div>
                <div class="col-md-8">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings');?>"><span class="ti-mobile mr-2"></span><?php echo $this->lang->line('settings_2');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/settings/push');?>"><span class="ti-signal mr-2"></span><?php echo $this->lang->line('settings_3');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/icons');?>"><span class="ti-image mr-2"></span><?php echo $this->lang->line('settings_4');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/emails');?>"><span class="ti-email mr-2"></span><?php echo $this->lang->line('settings_5');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <?php echo form_open(site_url('my/apps/'.$app->id.'/settings/update_push')) ?>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('settings_44');?></label>
                <input type="password" class="form-control form-control-sm" name="app_id" value="<?php echo $settings->onesignal_api_key; ?>">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('settings_45');?></label>
                <input type="password" class="form-control form-control-sm" name="rest_api_key" value="<?php echo $settings->onesignal_rest_api; ?>">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('settings_46');?></label>
                <input type="password" class="form-control form-control-sm" name="user_auth_key" value="<?php echo $settings->onesignal_auth_key; ?>">
            </div>
        </div>
        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('settings_25');?></button>
        </div>
    </div>
    <?php echo form_close(); ?>
</div>