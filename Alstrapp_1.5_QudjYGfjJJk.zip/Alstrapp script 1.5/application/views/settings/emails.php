<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-4">
                    <h4><?php echo $this->lang->line('settings_1');?></h4>
                </div>
                <div class="col-md-8">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings');?>"><span class="ti-mobile mr-2"></span><?php echo $this->lang->line('settings_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/push');?>"><span class="ti-signal mr-2"></span><?php echo $this->lang->line('settings_3');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/icons');?>"><span class="ti-image mr-2"></span><?php echo $this->lang->line('settings_4');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/settings/emails');?>"><span class="ti-email mr-2"></span><?php echo $this->lang->line('settings_5');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="row mb-head">
                <div class="col-md-12">
                    <h5 class="mb-0"><?php echo $this->lang->line('settings_16');?></h5>
                </div>
            </div>
            <?php echo form_open(site_url('my/apps/'.$app->id.'/settings/update_email_settings')) ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('settings_17');?></label>
                        <select class="form-control form-control-sm" name="method">
                            <option value="1" <?php if ($settings->mail_method == 1) : ?>selected<?php endif; ?>>Codeigniter Sendmail</option>
                            <option value="2" <?php if ($settings->mail_method == 2) : ?>selected<?php endif; ?>>SMTP</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('settings_18');?></label>
                        <input type="text" class="form-control form-control-sm" name="admin_email" placeholder="mail@alstrapp.com" value="<?php echo $settings->admin_email; ?>">
                    </div>
                </div>
            </div>
            <div class="row mb-head mt-3">
                <div class="col-md-12">
                    <h5 class="mb-0">Codeigniter Sendmail</h5>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('settings_19');?></label>
                        <input type="text" class="form-control form-control-sm" name="cs_sender" placeholder="Alstrapp" value="<?php echo $settings->cs_sender; ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('settings_20');?></label>
                        <input type="text" class="form-control form-control-sm" name="cs_email" placeholder="mail@alstrapp.com" value="<?php echo $settings->cs_email; ?>">
                    </div>
                </div>
            </div>
            <div class="row mb-head mt-3">
                <div class="col-md-12">
                    <h5 class="mb-0"><?php echo $this->lang->line('settings_21');?></h5>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('settings_19');?></label>
                        <input type="text" class="form-control form-control-sm" name="smtp_sender" placeholder="Alstrapp" value="<?php echo $settings->smtp_sender; ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('settings_22');?></label>
                        <input type="text" class="form-control form-control-sm" name="smtp_port" placeholder="25" value="<?php echo $settings->smtp_port; ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('settings_23');?></label>
                        <input type="text" class="form-control form-control-sm" name="smtp_host" placeholder="smtp.domain.ru" value="<?php echo $settings->smtp_host; ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('settings_20');?></label>
                        <input type="text" class="form-control form-control-sm" name="smtp_email" placeholder="mail@alstrapp.com" value="<?php echo $settings->smtp_email; ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('settings_24');?></label>
                        <input type="password" class="form-control form-control-sm" name="smtp_password" placeholder="********" value="<?php echo $settings->smtp_password; ?>">
                    </div>
                </div>
                <div class="col-md-12 text-right">
                    <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('settings_25');?></button>
                </div>
            </div>
        </div>
    </div>
    <?php echo form_close(); ?>
</div>