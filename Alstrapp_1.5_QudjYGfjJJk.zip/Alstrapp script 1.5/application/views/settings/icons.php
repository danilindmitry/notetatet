<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-4">
                    <h4><?php echo $this->lang->line('settings_1');?></h4>
                </div>
                <div class="col-md-8">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings');?>"><span class="ti-mobile mr-2"></span><?php echo $this->lang->line('settings_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/push');?>"><span class="ti-signal mr-2"></span><?php echo $this->lang->line('settings_3');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/settings/icons');?>"><span class="ti-image mr-2"></span><?php echo $this->lang->line('settings_4');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/emails');?>"><span class="ti-email mr-2"></span><?php echo $this->lang->line('settings_5');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="row mb-head">
                <div class="col-md-9">
                    <h5 class="mb-0"><?php echo $this->lang->line('settings_26');?></h5>
                    <small class="text-muted">Android</small>
                </div>
                <div class="col-md-3 text-right">
                    <select class="form-control form-control-sm" name="category" onchange="location = this.value;">
                        <option value="<?php echo base_url('my/apps/'.$app->id.'/settings/icons');?>">Android</option>
                        <option value="<?php echo base_url('my/apps/'.$app->id.'/settings/icons_ios');?>">iOS</option>
                        <option value="<?php echo base_url('my/apps/'.$app->id.'/settings/avatars');?>"><?php echo $this->lang->line('settings_6');?></option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('settings_9');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_10');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_11');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_12');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/android/'.$icon->android.'');?>" style="width:36px">
                                </td>
                                <td>512x512</td>
                                <td><?php echo $this->lang->line('settings_27');?></td>
                                <td><?php echo $icon->android; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="1">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector" type="file" style="display:none" 
                                        onchange="$('#upload-file-info').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/android/'.$icon->android_mdpi.'');?>" style="width:36px">
                                </td>
                                <td>48x48</td>
                                <td>MDPI</td>
                                <td><?php echo $icon->android_mdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="2">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector2">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector2" type="file" style="display:none" 
                                        onchange="$('#upload-file-info2').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/android/'.$icon->android_hdpi.'');?>" style="width:36px">
                                </td>
                                <td>72x72</td>
                                <td>HDPI</td>
                                <td><?php echo $icon->android_hdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="3">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector3">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector3" type="file" style="display:none" 
                                        onchange="$('#upload-file-info3').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/android/'.$icon->android_xhdpi.'');?>" style="width:36px">
                                </td>
                                <td>96x96</td>
                                <td>XHDPI</td>
                                <td><?php echo $icon->android_xhdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="4">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector4">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector4" type="file" style="display:none" 
                                        onchange="$('#upload-file-info4').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/android/'.$icon->android_xxhdpi.'');?>" style="width:36px">
                                </td>
                                <td>144x144</td>
                                <td>XXHDPI</td>
                                <td><?php echo $icon->android_xxhdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="5">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector5">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector5" type="file" style="display:none" 
                                        onchange="$('#upload-file-info5').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/android/'.$icon->android_xxxhdpi.'');?>" style="width:36px">
                                </td>
                                <td>192x192</td>
                                <td>XXXHDPI</td>
                                <td><?php echo $icon->android_xxxhdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="6">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector6">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector6" type="file" style="display:none" 
                                        onchange="$('#upload-file-info6').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row mb-head">
                <div class="col-md-12">
                    <h5 class="mb-0"><?php echo $this->lang->line('settings_28');?></h5>
                    <small class="text-muted">Android</small>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('settings_9');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_10');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_11');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_12');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/android/'.$icon->android_screen_ldpi.'');?>" style="height: 80px">
                                </td>
                                <td>200x320</td>
                                <td>LDPI</td>
                                <td><?php echo $icon->android_screen_ldpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="1">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector7">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector7" type="file" style="display:none" 
                                        onchange="$('#upload-file-info7').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/android/'.$icon->android_screen_mdpi.'');?>" style="height: 80px">
                                </td>
                                <td>320x480</td>
                                <td>MDPI</td>
                                <td><?php echo $icon->android_screen_mdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="2">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector8">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector8" type="file" style="display:none" 
                                        onchange="$('#upload-file-info8').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/android/'.$icon->android_screen_hdpi.'');?>" style="height: 80px">
                                </td>
                                <td>480x800</td>
                                <td>HDPI</td>
                                <td><?php echo $icon->android_screen_hdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="3">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector9">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector9" type="file" style="display:none" 
                                        onchange="$('#upload-file-info9').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/android/'.$icon->android_screen_xhdpi.'');?>" style="height: 80px">
                                </td>
                                <td>720x1280</td>
                                <td>XHDPI</td>
                                <td><?php echo $icon->android_screen_xhdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="4">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector10">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector10" type="file" style="display:none" 
                                        onchange="$('#upload-file-info10').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/android/'.$icon->android_screen_xxhdpi.'');?>" style="height: 80px">
                                </td>
                                <td>960x1600</td>
                                <td>XXHDPI</td>
                                <td><?php echo $icon->android_screen_xxhdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="5">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector11">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector11" type="file" style="display:none" 
                                        onchange="$('#upload-file-info11').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/android/'.$icon->android_screen_xxxhdpi.'');?>" style="height: 80px">
                                </td>
                                <td>1280x1920</td>
                                <td>XXXHDPI</td>
                                <td><?php echo $icon->android_screen_xxxhdpi; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="6">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector12">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector12" type="file" style="display:none" 
                                        onchange="$('#upload-file-info12').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row mb-head">
                <div class="col-md-12">
                    <h5 class="mb-0"><?php echo $this->lang->line('settings_29');?></h5>
                    <small class="text-muted">Android</small>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('settings_9');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_10');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_11');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_12');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('uploads/notify/'.$icon->notify_android.'');?>" style="width:36px">
                                </td>
                                <td>96x96</td>
                                <td>XXXHDPI</td>
                                <td><?php echo $icon->notify_android; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="25">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector13">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector13" type="file" style="display:none" 
                                        onchange="$('#upload-file-info13').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>