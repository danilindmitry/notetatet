<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-4">
                    <h4><?php echo $this->lang->line('settings_1');?></h4>
                </div>
                <div class="col-md-8">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings');?>"><span class="ti-mobile mr-2"></span><?php echo $this->lang->line('settings_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/push');?>"><span class="ti-signal mr-2"></span><?php echo $this->lang->line('settings_3');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/settings/icons');?>"><span class="ti-image mr-2"></span><?php echo $this->lang->line('settings_4');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/settings/emails');?>"><span class="ti-email mr-2"></span><?php echo $this->lang->line('settings_5');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="row mb-head">
                <div class="col-md-9">
                    <h5 class="mb-0"><?php echo $this->lang->line('settings_26');?></h5>
                    <small class="text-muted">iOS 7.0+</small>
                </div>
                <div class="col-md-3 text-right">
                    <select class="form-control form-control-sm" name="category" onchange="location = this.value;">
                        <option value="<?php echo base_url('my/apps/'.$app->id.'/settings/icons_ios');?>">iOS</option>
                        <option value="<?php echo base_url('my/apps/'.$app->id.'/settings/icons');?>">Android</option>
                        <option value="<?php echo base_url('my/apps/'.$app->id.'/settings/avatars');?>"><?php echo $this->lang->line('settings_6');?></option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('settings_9');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_10');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_11');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_12');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_60_3x.'');?>" style="width:36px">
                                </td>
                                <td>180x180</td>
                                <td>iPhone 6 / 6+ Retina</td>
                                <td><?php echo $icon->ios_icon_60_3x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="7">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector" type="file" style="display:none" 
                                        onchange="$('#upload-file-info').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_60.'');?>" style="width:36px">
                                </td>
                                <td>60x60</td>
                                <td>iPhone / iPod Touch</td>
                                <td><?php echo $icon->ios_icon_60; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="8">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector1">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector1" type="file" style="display:none" 
                                        onchange="$('#upload-file-info1').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_60_2x.'');?>" style="width:36px">
                                </td>
                                <td>120x120</td>
                                <td>iPhone / iPod Touch Retina</td>
                                <td><?php echo $icon->ios_icon_60_2x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="9">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector2">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector2" type="file" style="display:none" 
                                        onchange="$('#upload-file-info2').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_76.'');?>" style="width:36px">
                                </td>
                                <td>76x76</td>
                                <td>iPad</td>
                                <td><?php echo $icon->ios_icon_76; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="10">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector3">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector3" type="file" style="display:none" 
                                        onchange="$('#upload-file-info3').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_76_2x.'');?>" style="width:36px">
                                </td>
                                <td>152x152</td>
                                <td>iPad Retina</td>
                                <td><?php echo $icon->ios_icon_76_2x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="11">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector4">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector4" type="file" style="display:none" 
                                        onchange="$('#upload-file-info4').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_83_5_2x.'');?>" style="width:36px">
                                </td>
                                <td>167x167</td>
                                <td>iPad Retina</td>
                                <td><?php echo $icon->ios_icon_83_5_2x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="12">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector5">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector5" type="file" style="display:none" 
                                        onchange="$('#upload-file-info5').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_small.'');?>" style="width:36px">
                                </td>
                                <td>29x29</td>
                                <td><?php echo $this->lang->line('settings_8');?></td>
                                <td><?php echo $icon->ios_icon_small; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="13">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector6">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector6" type="file" style="display:none" 
                                        onchange="$('#upload-file-info6').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_small_2x.'');?>" style="width:36px">
                                </td>
                                <td>58x58</td>
                                <td><?php echo $this->lang->line('settings_30');?></td>
                                <td><?php echo $icon->ios_icon_small_2x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="14">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector7">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector7" type="file" style="display:none" 
                                        onchange="$('#upload-file-info7').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_small_3x.'');?>" style="width:36px">
                                </td>
                                <td>87x87</td>
                                <td><?php echo $this->lang->line('settings_30');?></td>
                                <td><?php echo $icon->ios_icon_small_3x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="15">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector8">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector8" type="file" style="display:none" 
                                        onchange="$('#upload-file-info8').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_40.'');?>" style="width:36px">
                                </td>
                                <td>40x40</td>
                                <td><?php echo $this->lang->line('settings_31');?></td>
                                <td><?php echo $icon->ios_icon_40; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="16">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector9">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector9" type="file" style="display:none" 
                                        onchange="$('#upload-file-info9').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_40_2x.'');?>" style="width:36px">
                                </td>
                                <td>80x80</td>
                                <td><?php echo $this->lang->line('settings_32');?></td>
                                <td><?php echo $icon->ios_icon_40_2x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="17">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector10">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector10" type="file" style="display:none" 
                                        onchange="$('#upload-file-info10').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_40_3x.'');?>" style="width:36px">
                                </td>
                                <td>120x120</td>
                                <td><?php echo $this->lang->line('settings_32');?></td>
                                <td><?php echo $icon->ios_icon_40_3x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="18">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector11">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector11" type="file" style="display:none" 
                                        onchange="$('#upload-file-info11').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row mb-head">
                <div class="col-md-12">
                    <h5 class="mb-0"><?php echo $this->lang->line('settings_26');?></h5>
                    <small class="text-muted">iOS 6.1</small>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('settings_9');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_10');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_11');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_12');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon.'');?>" style="width:36px">
                                </td>
                                <td>57x57</td>
                                <td>iPhone / iPod Touch</td>
                                <td><?php echo $icon->ios_icon; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="19">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector12">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector12" type="file" style="display:none" 
                                        onchange="$('#upload-file-info12').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_2x.'');?>" style="width:36px">
                                </td>
                                <td>114x114</td>
                                <td>iPhone / iPod Touch Retina</td>
                                <td><?php echo $icon->ios_icon_2x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="20">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector13">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector13" type="file" style="display:none" 
                                        onchange="$('#upload-file-info13').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_72.'');?>" style="width:36px">
                                </td>
                                <td>72x72</td>
                                <td>iPad</td>
                                <td><?php echo $icon->ios_icon_72; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="21">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector14">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector14" type="file" style="display:none" 
                                        onchange="$('#upload-file-info14').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_72_2x.'');?>" style="width:36px">
                                </td>
                                <td>144x144</td>
                                <td>iPad Retina</td>
                                <td><?php echo $icon->ios_icon_72_2x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="22">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector15">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector15" type="file" style="display:none" 
                                        onchange="$('#upload-file-info15').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_50.'');?>" style="width:36px">
                                </td>
                                <td>50x50</td>
                                <td><?php echo $this->lang->line('settings_33');?></td>
                                <td><?php echo $icon->ios_icon_50; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="23">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector16">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector16" type="file" style="display:none" 
                                        onchange="$('#upload-file-info16').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/icon/ios/'.$icon->ios_icon_50_2x.'');?>" style="width:36px">
                                </td>
                                <td>100x100</td>
                                <td><?php echo $this->lang->line('settings_33');?></td>
                                <td><?php echo $icon->ios_icon_50_2x; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_icon')) ?>
                                    <input type="hidden" name="type" value="24">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector17">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector17" type="file" style="display:none" 
                                        onchange="$('#upload-file-info17').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row mb-head">
                <div class="col-md-12">
                    <h5 class="mb-0"><?php echo $this->lang->line('settings_28');?></h5>
                    <small class="text-muted">iOS</small>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('settings_9');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_10');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_11');?></th>
                                <th scope="col"><?php echo $this->lang->line('settings_12');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/ios/'.$icon->ios_screen_default.'');?>" style="height: 80px">
                                </td>
                                <td>320x480</td>
                                <td>iPhone and iPod touch</td>
                                <td><?php echo $icon->ios_screen_default; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="7">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector18">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector18" type="file" style="display:none" 
                                        onchange="$('#upload-file-info18').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/ios/'.$icon->ios_screen_default_2.'');?>" style="height: 80px">
                                </td>
                                <td>640x960</td>
                                <td>iPhone and iPod touch Retina</td>
                                <td><?php echo $icon->ios_screen_default_2; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="8">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector19">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector19" type="file" style="display:none" 
                                        onchange="$('#upload-file-info19').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/ios/'.$icon->ios_screen_iphone_5.'');?>" style="height: 80px">
                                </td>
                                <td>640x1136</td>
                                <td>iPhone 5 / iPod Touch Retina</td>
                                <td><?php echo $icon->ios_screen_iphone_5; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="9">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector20">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector20" type="file" style="display:none" 
                                        onchange="$('#upload-file-info20').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/ios/'.$icon->ios_screen_667h.'');?>" style="height: 80px">
                                </td>
                                <td>750x1334</td>
                                <td><?php echo $this->lang->line('settings_34');?></td>
                                <td><?php echo $icon->ios_screen_667h; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="10">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector21">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector21" type="file" style="display:none" 
                                        onchange="$('#upload-file-info21').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/ios/'.$icon->ios_screen_736h.'');?>" style="height: 80px">
                                </td>
                                <td>1242x2208</td>
                                <td><?php echo $this->lang->line('settings_35');?></td>
                                <td><?php echo $icon->ios_screen_736h; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="11">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector22">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector22" type="file" style="display:none" 
                                        onchange="$('#upload-file-info22').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/ios/'.$icon->ios_screen_ipad.'');?>" style="height: 80px">
                                </td>
                                <td>768x1024</td>
                                <td>iPad</td>
                                <td><?php echo $icon->ios_screen_ipad; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="12">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector23">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector23" type="file" style="display:none" 
                                        onchange="$('#upload-file-info23').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <img src="<?php echo base_url('projects/'.$app->id.'/www/img/screen/ios/'.$icon->ios_screen_ipad_retina.'');?>" style="height: 80px">
                                </td>
                                <td>1536x2048</td>
                                <td>iPad Retina</td>
                                <td><?php echo $icon->ios_screen_ipad_retina; ?></td>
                                <td class="text-right">
                                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/settings/upload_splash')) ?>
                                    <input type="hidden" name="type" value="13">
                                    <label class="btn btn-primary btn-sm" for="my-file-selector24">
                                        <input onchange="this.form.submit()" name="image" id="my-file-selector24" type="file" style="display:none" 
                                        onchange="$('#upload-file-info24').html(this.files[0].name)">
                                        <span class="ti-upload mr-2"></span><?php echo $this->lang->line('settings_14');?>
                                    </label>
                                    <?php echo form_close(); ?> 
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>