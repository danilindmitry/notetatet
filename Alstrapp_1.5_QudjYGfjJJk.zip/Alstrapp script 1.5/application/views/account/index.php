<div class="row mb-2">
    <div class="col-md-12">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url('my/account');?>"><span class="ti-id-badge mr-1"></span><?php echo $this->lang->line('account_2');?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('account_3');?></li>
         </ol>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $this->lang->line('account_2');?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
	<?php echo form_open(site_url('my/account/update_account')) ?>
	<div class="row">
        <div class="col-md-12">
        	<div class="row mb-head">
                <div class="col-md-9">
                    <h5 class="mb-0"><?php echo $this->lang->line('account_3');?></h5>
                    <small class="text-muted">Last login <?php echo $admin->last_login; ?></small>
                </div>
                <div class="col-md-3">
                	<div class="form-group">
					    <select class="form-control form-control-sm" onchange="location = this.value;">
					    <option>Select language</option>
					    <?php $localizations_list = $this->template->get_localizations_list(); ?>
                        <?php if ($localizations_list) : ?>
                        <?php foreach ($localizations_list as $data_localizations) : ?>
                        <option value="<?php echo base_url('my/configuration/select_lang/'.$data_localizations->id.'');?>"><?php echo $data_localizations->name; ?></option>
                        <?php endforeach; ?>
                        <?php endif; ?>
					    </select>
					  </div>
                </div>
            </div>
            <div class="row">
            	<div class="col-md-12">
		            <div class="form-group">
		                <label><?php echo $this->lang->line('account_4');?></label>
		                <input type="text" class="form-control form-control-sm" name="email" value="<?php echo $admin->email; ?>">
		            </div>
		        </div>
		        <div class="col-md-6">
		            <div class="form-group">
		                <label><?php echo $this->lang->line('account_5');?></label>
		                <input type="password" class="form-control form-control-sm" name="password" placeholder="**********">
		                <small class="form-text text-muted"><?php echo $this->lang->line('account_6');?></small>
		            </div>
		        </div>
		        <div class="col-md-6">
		            <div class="form-group">
		                <label><?php echo $this->lang->line('account_7');?></label>
		                <input type="password" class="form-control form-control-sm" name="repassword" placeholder="**********">
		            </div>
		        </div>
		        <div class="col-md-6">
		            <div class="form-group">
		                <label><?php echo $this->lang->line('account_8');?></label>
		                <input type="text" class="form-control form-control-sm" name="question" value="<?php echo $admin->reset_question; ?>" placeholder="<?php echo $this->lang->line('account_9');?>">
		            </div>
		        </div>
		        <div class="col-md-6">
		            <div class="form-group">
		                <label><?php echo $this->lang->line('account_10');?></label>
		                <input type="password" class="form-control form-control-sm" name="answer" placeholder="Ella" value="<?php echo $admin->reset_answer; ?>">
		            </div>
		        </div>
		        <div class="col-md-12 text-right">
		            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('account_11');?></button>
		        </div>
            </div>
        </div>
    </div>
    <?php echo form_close(); ?> 
</div>