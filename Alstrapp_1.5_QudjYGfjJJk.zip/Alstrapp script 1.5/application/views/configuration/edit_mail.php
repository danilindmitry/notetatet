 <script>
    $(document).ready(function() {
        $('#summernote').summernote({
            height: 500,
            toolbar: [
                // [groupName, [list of button]]
                ['style', ['bold', 'italic', 'underline', 'clear']],
                ['fontsize', ['fontsize']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['insert', ['picture', 'video', 'link']],
                ['misc', ['fullscreen', 'codeview']]
            ],
        });
    });
</script>

<div class="row mb-2">
    <div class="col-md-12">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url('my/configuration');?>"><span class="ti-settings mr-1"></span><?php echo $this->lang->line('config_1');?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo base_url('my/configuration/email');?>"><?php echo $this->lang->line('config_4');?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('config_19');?></li>
         </ol>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-4">
                    <h4><?php echo $this->lang->line('config_1');?></h4>
                </div>
                <div class="col-md-8">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration');?>"><span class="ti-server mr-2"></span><?php echo $this->lang->line('config_3');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration/design');?>"><span class="ti-paint-roller mr-2"></span><?php echo $this->lang->line('config_2');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/configuration/email');?>"><span class="ti-email mr-2"></span><?php echo $this->lang->line('config_4');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration/localizations');?>"><span class="ti-world mr-2"></span><?php echo $this->lang->line('config_5');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <?php echo form_open(site_url('my/configuration/update_mail/'.$template->id.'')) ?>
    <div class="row mb-head">
        <div class="col-md-12">
            <h5 class="mb-0"><?php echo $this->lang->line('config_20');?> "<?php echo $template->title; ?>"</h5>
            <small class="text-muted"><?php echo $this->lang->line('config_21');?> <?php if ($template->type == 1) : ?>user<?php else : ?>admin<?php endif; ?></small>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <div class="form-group">
                <label><?php echo $this->lang->line('config_22');?></label>
                <input type="text" class="form-control form-control-sm" name="title" placeholder="Welcome" value="<?php echo $template->title; ?>">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label><?php echo $this->lang->line('config_23');?></label>
                <select class="form-control form-control-sm" name="status">
                    <option value="1" <?php if ($template->status == 1) : ?>selected<?php endif; ?>><?php echo $this->lang->line('config_24');?></option>
                    <option value="2" <?php if ($template->status == 2) : ?>selected<?php endif; ?>><?php echo $this->lang->line('config_25');?></option>
                </select>
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <label><?php echo $this->lang->line('config_26');?></label>
                <textarea id="summernote" name="message"><?php echo $template->message; ?></textarea>
            </div>
        </div>
        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('config_27');?></button>
        </div>
    </div>
    <?php echo form_close(); ?>
</div>