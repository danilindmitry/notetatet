<div class="row mb-2">
    <div class="col-md-12">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url('my/configuration');?>"><span class="ti-settings mr-1"></span><?php echo $this->lang->line('config_1');?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('config_4');?></li>
         </ol>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-4">
                    <h4><?php echo $this->lang->line('config_1');?></h4>
                </div>
                <div class="col-md-8">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration');?>"><span class="ti-server mr-2"></span><?php echo $this->lang->line('config_3');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration/design');?>"><span class="ti-paint-roller mr-2"></span><?php echo $this->lang->line('config_2');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/configuration/email');?>"><span class="ti-email mr-2"></span><?php echo $this->lang->line('config_4');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration/localizations');?>"><span class="ti-world mr-2"></span><?php echo $this->lang->line('config_5');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row mb-head">
        <div class="col-md-12">
            <h5><?php echo $this->lang->line('config_4');?></h5>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-hover">
                <thead class="thead-light">
                    <tr>
                        <th scope="col"><?php echo $this->lang->line('config_22');?></th>
                        <th scope="col"><?php echo $this->lang->line('config_28');?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($templates)) : ?>
                    <tr>
                        <td><?php echo $this->lang->line('config_9');?></td>
                    </tr>
                    <?php else : ?>
                    <?php foreach ($templates as $data) : ?>
                    <tr>
                        <td><?php if ($data->status == 1) : ?><span class="ti-check text-success mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo $this->lang->line('config_29');?>"></span><?php else : ?><span class="ti-close text-danger mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo $this->lang->line('config_30');?>"></span><?php endif; ?><?php echo $data->title; ?></td>
                        <td>
                            <?php if ($data->type == 1) : ?>
                            <span class="badge badge-dark"><?php echo $this->lang->line('config_31');?></span>
                            <?php else : ?>
                            <span class="badge badge-warning"><?php echo $this->lang->line('config_32');?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-right">
                            <a href="<?php echo base_url('/my/configuration/edit_mail/'.$data->id.'');?>" class="btn btn-primary btn-sm mr-3"><span class="ti-pencil mr-2"></span><?php echo $this->lang->line('config_33');?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>