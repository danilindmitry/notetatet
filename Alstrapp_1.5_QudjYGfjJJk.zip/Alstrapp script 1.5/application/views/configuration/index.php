<div class="row mb-2">
    <div class="col-md-12">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url('my/configuration');?>"><span class="ti-settings mr-1"></span><?php echo $this->lang->line('config_1');?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('config_3');?></li>
         </ol>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-4">
                    <h4><?php echo $this->lang->line('config_1');?></h4>
                </div>
                <div class="col-md-8">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/configuration');?>"><span class="ti-server mr-2"></span><?php echo $this->lang->line('config_3');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration/design');?>"><span class="ti-paint-roller mr-2"></span><?php echo $this->lang->line('config_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration/email');?>"><span class="ti-email mr-2"></span><?php echo $this->lang->line('config_4');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration/localizations');?>"><span class="ti-world mr-2"></span><?php echo $this->lang->line('config_5');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">

        <div class="col-md-12 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-1">
                            <div class="card card-circle">
                                <img src="<?php echo base_url();?>themes/alstrapp/img/phonegap.png" class="w-100">
                            </div>
                        </div>
                        <?php if (!$configuration->access_token) : ?>
                        <div class="col-md-11">
                            <h6><?php echo $this->lang->line('config_34');?></h6>
                            <p><?php echo $this->lang->line('config_35');?> <a href="http://build.phonegap.com/" target="_blank"><?php echo $this->lang->line('config_36');?></a>.<br>
                            <?php echo $this->lang->line('config_37');?> <a href="https://build.phonegap.com/people/edit" target="_blank"><?php echo $this->lang->line('config_38');?></a>. <?php echo $this->lang->line('config_39');?> <code><?php echo base_url('ipn/phonegap');?></code> <?php echo $this->lang->line('config_40');?>.
                            </p>
                        </div>
                        <div class="col-md-12 text-right">
                            <button type="button" data-toggle="modal" data-target="#phonegap" class="btn btn-primary btn-sm"><?php echo $this->lang->line('config_41');?></button>
                        </div>
                        <?php else : ?>
                        <div class="col-md-11">
                            <h6 class="text-success"><?php echo $this->lang->line('config_42');?> <?php echo $configuration->client_id; ?></h6>
                            <p><?php echo $this->lang->line('config_43');?></p>
                        </div>
                        <div class="col-md-12 text-right">
                            <a href="<?php echo base_url('my/configuration/reset_phonegap');?>" class="btn btn-danger btn-sm"><?php echo $this->lang->line('config_44');?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if (!$configuration->access_token) : ?>
            <!-- Connect Phonegap account -->
            <div class="modal fade" id="phonegap" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('config_45');?></h5>
                            <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                                <span class="ti-close"></span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo form_open(site_url('my/configuration/phonegap_connect')) ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('config_46');?></label>
                                        <input type="text" class="form-control form-control-sm" name="client_id">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('config_47');?></label>
                                        <input type="password" class="form-control form-control-sm" name="client_secret">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $this->lang->line('config_48');?></button>
                            <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('config_49');?></button>
                        </div>
                        <?php echo form_close(); ?> 
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-md-12 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-1">
                            <div class="card card-circle">
                                <img src="<?php echo base_url();?>themes/alstrapp/img/apple.png" class="w-100">
                            </div>
                        </div>
                        <?php if (!$configuration->sign_ios) : ?>
                        <div class="col-md-11">
                            <h6><?php echo $this->lang->line('config_50');?></h6>
                            <p><?php echo $this->lang->line('config_51');?> <a href="#" target="_blank"><?php echo $this->lang->line('config_52');?></a>.</p>
                        </div>
                        <div class="col-md-12 text-right">
                            <button type="button" data-toggle="modal" data-target="#ios" class="btn btn-primary btn-sm"><?php echo $this->lang->line('config_41');?></button>
                        </div>
                        <?php else : ?>
                        <div class="col-md-11">
                            <h6 class="text-success"><?php echo $this->lang->line('config_53');?> <?php echo $configuration->sign_ios; ?></h6>
                            <p><?php echo $this->lang->line('config_54');?></p>
                        </div>
                        <div class="col-md-12 text-right">
                            <a href="<?php echo base_url('my/configuration/reset_apple');?>" class="btn btn-danger btn-sm"><?php echo $this->lang->line('config_55');?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- Connect ios signature -->
            <div class="modal fade" id="ios" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('config_56');?></h5>
                            <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                                <span class="ti-close"></span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo form_open_multipart(site_url('my/configuration/apple_connect')) ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control form-control-sm" name="title">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('config_57');?></label>
                                        <input type="password" class="form-control form-control-sm" name="password">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('config_58');?></label>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" name="certificate" onchange="$('#upload-file-info').html(this.files[0].name)">
                                            <label class="custom-file-label" for="customFile"><span id="upload-file-info"></span></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('config_59');?></label>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" name="provisioning" onchange="$('#upload-file-info2').html(this.files[0].name)">
                                            <label class="custom-file-label" for="customFile"><span id="upload-file-info2"></span></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $this->lang->line('config_48');?></button>
                            <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('config_49');?></button>
                        </div>
                        <?php echo form_close(); ?> 
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 mb-3">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-1">
                            <div class="card card-circle">
                                <img src="<?php echo base_url();?>themes/alstrapp/img/android.png" class="w-100">
                            </div>
                        </div>
                        <?php if (!$configuration->sign_android) : ?>
                        <div class="col-md-11">
                            <h6><?php echo $this->lang->line('config_60');?></h6>
                            <p><?php echo $this->lang->line('config_61');?> <a href="#" target="_blank"><?php echo $this->lang->line('config_62');?></a>.</p>
                        </div>
                        <div class="col-md-12 text-right">
                            <button type="button" data-toggle="modal" data-target="#android" class="btn btn-primary btn-sm"><?php echo $this->lang->line('config_41');?></button>
                        </div>
                        <?php else : ?>
                        <div class="col-md-11">
                            <h6 class="text-success"><?php echo $this->lang->line('config_63');?> <?php echo $configuration->sign_android; ?></h6>
                            <p><?php echo $this->lang->line('config_64');?></p>
                        </div>
                        <div class="col-md-12 text-right">
                            <a href="<?php echo base_url('my/configuration/reset_android');?>" class="btn btn-danger btn-sm"><?php echo $this->lang->line('config_55');?></a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- Connect Android signature -->
            <div class="modal fade" id="android" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('config_56');?></h5>
                            <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                                <span class="ti-close"></span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <?php echo form_open_multipart(site_url('my/configuration/android_connect')) ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Title</label>
                                        <input type="text" class="form-control form-control-sm" name="title">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('config_65');?></label>
                                        <input type="text" class="form-control form-control-sm" name="alias">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('config_66');?></label>
                                        <input type="password" class="form-control form-control-sm" name="key_pw">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('config_67');?></label>
                                        <input type="password" class="form-control form-control-sm" name="keystore_pw">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('config_68');?></label>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" name="keystore" onchange="$('#upload-file-info3').html(this.files[0].name)">
                                            <label class="custom-file-label" for="customFile"><span id="upload-file-info3"></span></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo $this->lang->line('config_48');?></button>
                            <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('config_49');?></button>
                        </div>
                        <?php echo form_close(); ?> 
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>