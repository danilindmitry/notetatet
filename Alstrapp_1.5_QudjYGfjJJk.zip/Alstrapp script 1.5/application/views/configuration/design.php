<div class="row mb-2">
    <div class="col-md-12">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url('my/configuration');?>"><span class="ti-settings mr-1"></span><?php echo $this->lang->line('config_1');?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('config_2');?></li>
         </ol>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-4">
                    <h4><?php echo $this->lang->line('config_1');?></h4>
                </div>
                <div class="col-md-8">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration');?>"><span class="ti-server mr-2"></span><?php echo $this->lang->line('config_3');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/configuration/design');?>"><span class="ti-paint-roller mr-2"></span><?php echo $this->lang->line('config_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration/email');?>"><span class="ti-email mr-2"></span><?php echo $this->lang->line('config_4');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/configuration/localizations');?>"><span class="ti-world mr-2"></span><?php echo $this->lang->line('config_5');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row mb-head">
        <div class="col-md-9">
            <h5><?php echo $this->lang->line('config_2');?></h5>
        </div>
        <div class="col-md-3 text-right">
            <a href="#" data-toggle="modal" data-target="#add_item" class="btn btn-success btn-sm"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('config_6');?></a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-hover">
                <thead class="thead-light">
                    <tr>
                        <th scope="col"></th>
                        <th scope="col"><?php echo $this->lang->line('config_7');?></th>
                        <th scope="col"><?php echo $this->lang->line('config_8');?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($templates)) : ?>
                    <tr>
                        <td><?php echo $this->lang->line('config_9');?></td>
                    </tr>
                    <?php else : ?>
                    <?php foreach ($templates as $data) : ?>
                    <tr>
                        <td><img src="<?php echo base_url('templates/'.$data->path.'/icon.png');?>" style="width:30px"></td>
                        <td><?php echo $data->name; ?></td>
                        <td><span class="ti-home mr-2"></span>/templates/<?php echo $data->path; ?></td>
                        <td class="text-right">
                            <?php if ($data->id > 1) : ?>
                            <a href="#" data-toggle="modal" data-target="#del_template<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('config_10');?></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <!-- Delete template -->
                    <div class="modal" id="del_template<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content border-none">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-10">
                                                <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                            </div>
                                            <div class="col-md-2 text-right">
                                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                            </div>
                                        </div>
                                        <h5 class="mb-4"><?php echo $this->lang->line('config_11');?> "<?php echo $data->name; ?>"</h5>
                                        <p><?php echo $this->lang->line('config_12');?></p>
                                        <div class="text-right">
                                            <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('config_13');?></button>
                                            <a href="<?php echo base_url('my/configuration/delete_template/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('config_14');?>!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add template -->
<div class="modal fade" id="add_item" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('config_6');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open_multipart(site_url('my/configuration/upload_template')) ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('config_15');?></label>
                            <input type="text" class="form-control form-control-sm" name="name" placeholder="Posts">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('config_16');?></label>
                            <input type="text" class="form-control form-control-sm" name="path" placeholder="template">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('config_17');?></label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" name="zip_file" onchange="$('#upload-file-info2').html(this.files[0].name)">
                                <label class="custom-file-label" for="customFile"><span id="upload-file-info2"></span></label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('config_18');?></button>
            </div>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>