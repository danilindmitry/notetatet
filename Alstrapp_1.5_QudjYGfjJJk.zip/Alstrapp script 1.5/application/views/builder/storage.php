<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('builder_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/builder');?>"><span class="ti-cloud mr-2"></span><?php echo $this->lang->line('builder_2');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/builder/storage');?>"><span class="ti-server mr-2"></span><?php echo $this->lang->line('builder_3');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="row mb-head">
                <div class="col-md-12">
                    <h5 class="mb-0"><?php echo $this->lang->line('builder_4');?> - <?php echo $total_records; ?></h5>
                    <small class="text-muted"><?php echo $this->lang->line('builder_3');?></small>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php if ($total_records) : ?>
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('builder_9');?></th>
                                <th class="text-center"><?php echo $this->lang->line('builder_10');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($versions as $data) : ?>
                            <tr>
                                <td>
                                    <span class="ti-calendar mr-2"></span><?php echo $data->created; ?><br>
                                    <small class="text-muted"><?php echo $this->lang->line('builder_11');?>: <?php echo $data->phonegap_id; ?></small>
                                </td>
                                <td class="text-center">
                                    <?php if ($data->ios_path) : ?>
                                    <a href="<?php echo base_url('projects/'.$data->app_id.'/local/'.$data->ios_path.'');?>"><span class="ti-apple mr-2 text-black-50"></span></a>
                                    <?php endif; ?>
                                    <?php if ($data->android_path) : ?>
                                    <a href="<?php echo base_url('projects/'.$data->app_id.'/local/'.$data->android_path.'');?>"><span class="ti-android mr-3 text-success"></span></a>
                                    <?php endif; ?>
                                </td>
                                <td class="text-right">
                                    <a href="#" data-toggle="modal" data-target="#del_version<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('builder_14');?></a>
                                </td>
                            </tr>
                             <!-- Delete version -->
                            <div class="modal" id="del_version<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content border-none">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-10">
                                                        <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                    </div>
                                                    <div class="col-md-2 text-right">
                                                        <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                    </div>
                                                </div>
                                                <h5 class="mb-4"><?php echo $this->lang->line('builder_15');?> "<?php echo $data->created; ?>"</h5>
                                                <p><?php echo $this->lang->line('builder_42');?>.</p>
                                                <div class="text-right">
                                                    <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('builder_17');?></button>
                                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/builder/delete_local_version/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('builder_18');?>!</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else : ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-cloud-down"></span></h1>
                                <h5><?php echo $this->lang->line('builder_43');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('builder_44');?></p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>