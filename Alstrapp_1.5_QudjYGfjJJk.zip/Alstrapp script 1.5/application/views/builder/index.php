<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('builder_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/builder');?>"><span class="ti-cloud mr-2"></span><?php echo $this->lang->line('builder_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/builder/storage');?>"><span class="ti-server mr-2"></span><?php echo $this->lang->line('builder_3');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
	<div class="row">
		<div class="col-md-12">
            <div class="row mb-head">
                 <div class="col-md-9">
                     <h5 class="mb-0"><?php echo $this->lang->line('builder_4');?> - <?php echo $total_records; ?></h5>
                     <small class="text-muted"><?php echo $this->lang->line('builder_5');?></small>
                 </div>
                 <div class="col-md-3 text-right">
                    <a href="#" data-toggle="modal" data-target="#settings" class="btn btn-success btn-sm"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('builder_6');?></a>
                 </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php if ($total_records) : ?>
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('builder_7');?></th>
                                <th scope="col"><?php echo $this->lang->line('builder_8');?></th>
                                <th scope="col"><?php echo $this->lang->line('builder_9');?></th>
                                <th class="text-center"><?php echo $this->lang->line('builder_10');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($versions as $data) : ?>
                            <tr>
                                <td><?php echo $data->name; ?><br>
                                    <small class="text-muted"><?php echo $this->lang->line('builder_11');?>: <?php echo $data->phonegap_id; ?></small>
                                </td>
                                <td><?php echo $data->version; ?></td>
                                <td>
                                    <span class="ti-calendar mr-2"></span><?php echo $data->created; ?>
                                </td>
                                <td class="text-center">
                                    <?php if ($data->created > $load_time) : ?>
                                    <div class="progress" style="height: 10px;">
                                        <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%" data-toggle="tooltip" data-placement="top" title="<?php echo $this->lang->line('builder_12');?>"></div>
                                    </div>
                                    <?php else : ?>
                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/builder/download_ios/'.$data->phonegap_id.'');?>"><span class="ti-apple mr-2 text-black-50"></span></a>
                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/builder/download_android/'.$data->phonegap_id.'');?>"><span class="ti-android mr-3 text-success"></span></a>

                                    <?php endif; ?>
                                </td>
                                <td class="text-right">

                                    <?php if ($data->created > $load_time) : ?>
                                    <?php else : ?>
                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/builder/save_to_local/'.$data->phonegap_id.'');?>" class="btn btn-primary btn-sm mr-2" id="1" onClick="reply_click(this.id)"><span class="ti-save mr-2"></span><?php echo $this->lang->line('builder_13');?></a>
                                    <?php endif; ?>
                                    <a href="#" data-toggle="modal" data-target="#del_version<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('builder_14');?></a>
                                </td>
                            </tr>
                             <!-- Delete version -->
                            <div class="modal" id="del_version<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content border-none">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-10">
                                                        <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                    </div>
                                                    <div class="col-md-2 text-right">
                                                        <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                    </div>
                                                </div>
                                                <h5 class="mb-4"><?php echo $this->lang->line('builder_15');?> "<?php echo $data->created; ?>"</h5>
                                                <p><?php echo $this->lang->line('builder_16');?></p>
                                                <div class="text-right">
                                                    <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('builder_17');?></button>
                                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/builder/delete_version/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('builder_18');?>!</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if (!empty($links)) : ?>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $links ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php else : ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-wand"></span></h1>
                                <h5><?php echo $this->lang->line('builder_19');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('builder_20');?>.</p>
                                <a href="#" data-toggle="modal" data-target="#settings" class="btn btn-primary btn-sm"><?php echo $this->lang->line('builder_21');?></a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
	</div>
</div>

<!-- Setings -->
<div class="modal fade" id="settings" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('builder_22');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="navigation-page">
                <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"><?php echo $this->lang->line('builder_23');?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false"><?php echo $this->lang->line('builder_24');?></a>
                    </li>
                </ul>
            </div>
            <div class="modal-body">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('builder_25');?></label>
                                    <select class="form-control form-control-sm" id="sign_android" name="sign_android" onchange="yesnoCheck(this);">
                                        <option value="0"><?php echo $this->lang->line('builder_26');?></option>
                                        <?php if ($configuration->sign_android) : ?>
                                        <option value="1"><?php echo $this->lang->line('builder_27');?> <?php echo $configuration->sign_android; ?></option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div id="ifYes" style="display: none;">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('builder_28');?></label>
                                        <input type="password" class="form-control form-control-sm" id="key_pw" name="key_pw">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('builder_29');?></label>
                                        <input type="password" class="form-control form-control-sm" id="keystore_pw" name="keystore_pw">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('builder_25');?></label>
                                    <select class="form-control form-control-sm" id="sign_ios" name="sign_ios" onchange="iosCheck(this);">
                                        <option value="0"><?php echo $this->lang->line('builder_26');?></option>
                                        <?php if ($configuration->sign_ios) : ?>
                                        <option value="1"><?php echo $this->lang->line('builder_30');?> <?php echo $configuration->sign_ios; ?></option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div id="ifios" style="display: none;">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('builder_31');?></label>
                                        <input type="password" class="form-control form-control-sm" id="pass_ios" name="pass_ios">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal"><?php echo $this->lang->line('builder_32');?></button>
                <a href="#start" class="btn btn-primary btn-sm"><?php echo $this->lang->line('builder_21');?></a>
            </div>
        </div>
    </div>
</div>

<!-- Start upload -->
<div class="modal fade" id="start" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static">
  	<div class="modal-dialog modal-dialog-centered modal-sm" role="document">
    	<div class="modal-content">
      		<div class="modal-body text-center">
                <div id="print">
            		<div class="load-wrap-build">
                        <div class="loader"></div>
                    </div>
                    <h5><?php echo $this->lang->line('builder_33');?></h5>
                    <small class="text-muted"><?php echo $this->lang->line('builder_34');?></small>
                </div>
      		</div>
    	</div>
  	</div>
</div>

<!-- Start copy -->
<div class="modal fade" id="copy" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-body text-center">
                <div id="print">
                    <div class="load-wrap-build">
                        <div class="loader"></div>
                    </div>
                    <h5><?php echo $this->lang->line('builder_35');?></h5>
                    <small class="text-muted"><?php echo $this->lang->line('builder_34');?></small>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function reply_click(clicked_id)
    {
        $('#copy').modal('show');
    }
</script>

<script>
    function yesnoCheck(that) {
        if (that.value == "1") {
            document.getElementById("ifYes").style.display = "contents";
        } else {
            document.getElementById("ifYes").style.display = "none";
        }
    }
</script>
<script>
    function iosCheck(that) {
        if (that.value == "1") {
            document.getElementById("ifios").style.display = "contents";
        } else {
            document.getElementById("ifios").style.display = "none";
        }
    }
</script>

<script>
$('a[href$="#start"]').on( "click", function() {

    var sign_android = document.getElementById('sign_android').value;
    var sign_ios = document.getElementById('sign_ios').value;
    var key_pw = document.getElementById('key_pw').value;
    var keystore_pw = document.getElementById('keystore_pw').value;
    var pass_ios = document.getElementById('pass_ios').value;

    $('#settings').modal('hide')
    $('#start').modal('show');

    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
    
    $.ajax({
        type: 'POST',
        url: "<?php echo base_url('my/apps/'.$app->id.'/builder/start_build');?>",  
        data: 'sign_android='+ sign_android +'&key_pw='+ key_pw +'&keystore_pw='+ keystore_pw +'&sign_ios='+ sign_ios +'&pass_ios='+ pass_ios +'&' + csrfName + '=' + csrfHash,
        success: function(build) {

            var response = JSON.parse(build);

            if (response.event == 'success') { // success request

                successContent = '';

                successLi = '';

                successLi += '<div class="row">';
                successLi += '<div class="col-md-12">';
                successLi += '<h1 class="text-success"><span class="ti-check-box"></span></h1>';
                successLi += '<h5><?php echo $this->lang->line('builder_36');?></h5>';
                successLi += '<small class="text-muted"><?php echo $this->lang->line('builder_37');?></small>';
                successLi += '<a href="<?php echo base_url('my/apps/'.$app->id.'/builder');?>" class="btn btn-light btn-sm btn-block mt-3"><?php echo $this->lang->line('builder_38');?></a>';
                successLi += '</div>';
                successLi += '</div>';

                successContent += successLi;

                $("#print").html(successContent);

            } else {

                errorContent = '';

                errorLi = '';

                errorLi += '<div class="row">';
                errorLi += '<div class="col-md-12">';
                errorLi += '<h1 class="text-danger"><span class="ti-alert"></span></h1>';
                errorLi += '<h5><?php echo $this->lang->line('builder_39');?></h5>';
                errorLi += '<small class="text-muted">' + response.message + '</small>';
                errorLi += '<a href="<?php echo base_url('my/apps/'.$app->id.'/builder');?>" class="btn btn-light btn-sm btn-block mt-3"><span class="ti-reload mr-2"></span><?php echo $this->lang->line('builder_40');?></a>';
                errorLi += '</div>';
                errorLi += '</div>';

                errorContent += errorLi;

                $("#print").html(errorContent);

            }

        },
        error: function(error) {

            failContent = '';

            failLi = '';

            failLi += '<div class="row">';
            failLi += '<div class="col-md-12">';
            failLi += '<h1 class="text-danger"><span class="ti-alert"></span></h1>';
            failLi += '<h5><?php echo $this->lang->line('builder_39');?></h5>';
            failLi += '<small class="text-muted"><?php echo $this->lang->line('builder_41');?></small>';
            failLi += '<a href="<?php echo base_url('my/apps/'.$app->id.'/builder');?>" class="btn btn-light btn-sm btn-block mt-3"><span class="ti-reload mr-2"></span><?php echo $this->lang->line('builder_40');?></a>';
            failLi += '</div>';
            failLi += '</div>';

            failContent += failLi;

            $("#print").html(failContent);

        }
    });
    
});
</script>

<script>
/*
$('a[href$="#start"]').on( "click", function() {
//console.log("hey");
var sign_android = document.getElementById('sign_android').value;
console.log(sign_android);
var sign_windows = document.getElementById('sign_windows').value;
console.log(sign_windows);
$('#settings').modal('hide')
$('#start').modal('show');
});
*/
</script>