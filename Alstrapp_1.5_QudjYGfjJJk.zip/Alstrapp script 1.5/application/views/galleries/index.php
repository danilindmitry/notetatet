<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('gallery_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-all-tab" data-toggle="tab" href="#nav-all" role="tab" aria-controls="nav-all" aria-selected="true"><span class="ti-image mr-2"></span><?php echo $this->lang->line('gallery_2');?></a>
                            <a class="nav-item nav-link" id="nav-search-tab" data-toggle="tab" href="#nav-search" role="tab" aria-controls="nav-search" aria-selected="false"><span class="ti-search mr-2"></span><?php echo $this->lang->line('gallery_3');?></a>
                            <a class="nav-item nav-link" id="nav-add-tab" data-toggle="tab" href="#nav-add" role="tab" aria-controls="nav-add" aria-selected="false"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('gallery_4');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane show active" id="nav-all" role="tabpanel" aria-labelledby="nav-home-all">
                    <div class="row">
                        <div class="col-md-12">
                            <?php if ($total_records) : ?>
                            <table class="table table-hover">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col"><?php echo $this->lang->line('gallery_5');?></th>
                                        <th scope="col"><?php echo $this->lang->line('gallery_6');?></th>
                                        <th class="text-center" scope="col"><?php echo $this->lang->line('gallery_7');?></th>
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($galleries as $data) : ?>
                                    <tr>
                                        <td>
                                            <a href="#" data-toggle="modal" data-target="#edit_gallery<?php echo $data->id; ?>" class="text-warning mr-2"><span class="ti-pencil mr-1"></span></a><?php echo $data->name; ?>
                                        </td>
                                        <td><span class="ti-calendar mr-2"></span><?php echo $data->created; ?></td>
                                        <td class="text-center"><?php echo $this->template->get_count_images_for_gallery($data->id); ?></td>
                                        <td class="text-right">
                                            <a href="<?php echo base_url('my/apps/'.$app->id.'/galleries/upload/'.$data->id.'');?>" class="btn btn-primary btn-sm mr-3"><span class="ti-upload mr-2"></span><?php echo $this->lang->line('gallery_8');?></a>
                                            <a href="#" data-toggle="modal" data-target="#del_gallery<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('gallery_9');?></a>
                                        </td>
                                    </tr>
                                    <!-- Delete gallery -->
                                    <div class="modal" id="del_gallery<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content border-none">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="row">
                                                            <div class="col-md-10">
                                                                <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                            </div>
                                                            <div class="col-md-2 text-right">
                                                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                            </div>
                                                        </div>
                                                        <h5 class="mb-4"><?php echo $this->lang->line('gallery_10');?> "<?php echo $data->name; ?>"</h5>
                                                        <p><?php echo $this->lang->line('gallery_11');?></p>
                                                        <div class="text-right">
                                                            <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('gallery_12');?></button>
                                                            <a href="<?php echo base_url('my/apps/'.$app->id.'/galleries/delete_gallery/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('gallery_13');?>!</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Edit gallery -->
                                    <div class="modal" id="edit_gallery<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content border-none">
                                                <?php echo form_open(site_url('my/apps/'.$app->id.'/galleries/update_gallery/'.$data->id.'')) ?>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="row">
                                                            <div class="col-md-10">
                                                                <h1 class="text-warning"><span class="ti-pencil-alt"></span></h1>
                                                            </div>
                                                            <div class="col-md-2 text-right">
                                                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                            </div>
                                                        </div>
                                                        <h5 class="mb-4"><?php echo $this->lang->line('gallery_14');?> "<?php echo $data->name; ?>"</h5>
                                                        <div class="form-group">
                                                            <label><?php echo $this->lang->line('gallery_15');?></label>
                                                            <input type="text" class="form-control" name="name" value="<?php echo $data->name; ?>" placeholder="<?php echo $this->lang->line('gallery_16');?>">
                                                        </div>
                                                        <div class="text-right">
                                                            <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('gallery_17');?></button>
                                                            <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('gallery_18');?>!</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php echo form_close(); ?> 
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php if (!empty($links)) : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $links ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!isset($_GET['search'])) : ?>
                            <div class="row justify-content-center align-items-center mt-5">
                                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                                    <div class="text-center">
                                        <h1 class="text-primary"><span class="ti-image"></span></h1>
                                        <h5><?php echo $this->lang->line('gallery_19');?></h5>
                                        <p class="text-muted"><?php echo $this->lang->line('gallery_20');?></p>
                                        <a href="#" onclick="$('#nav-add-tab').trigger('click')" class="btn btn-primary btn-sm"><?php echo $this->lang->line('gallery_21');?></a>
                                    </div>
                                </div>
                            </div>
                            <?php else : ?>
                            <div class="row justify-content-center align-items-center mt-5">
                                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                                    <div class="text-center">
                                        <h1 class="text-danger"><span class="ti-face-sad"></span></h1>
                                        <h5><?php echo $this->lang->line('gallery_22');?></h5>
                                        <p class="text-muted"><?php echo $this->lang->line('gallery_23');?></p>
                                        <a href="<?php echo base_url('my/apps/'.$app->id.'/galleries');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('gallery_24');?></a>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="nav-search" role="tabpanel" aria-labelledby="nav-search-tab">
                    <?php echo form_open(site_url('my/apps/'.$app->id.'/galleries/?'), array('method'=>'get')) ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-search"></span></h1>
                                <h5><?php echo $this->lang->line('gallery_3');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('gallery_25');?></p>
                            </div>
                            <input type="text" name="search" class="form-control" <?php if (isset($_GET['search'])) : ?>value="<?php echo $_GET['search'] ?>" <?php endif; ?>placeholder="<?php echo $this->lang->line('gallery_26');?>?">
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
                <div class="tab-pane" id="nav-add" role="tabpanel" aria-labelledby="nav-add-tab">
                    <?php echo form_open(site_url('my/apps/'.$app->id.'/galleries/create_gallery/')) ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('gallery_27');?></label>
                                <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('gallery_16');?>">
                                <small class="form-text text-muted"><?php echo $this->lang->line('gallery_28');?></small>
                            </div>
                        </div>
                        <div class="col-md-12 text-right">
                            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('gallery_29');?></button>
                        </div>
                    </div>
                    <?php echo form_close(); ?> 
                </div>
            </div>
        </div>
    </div>
</div>