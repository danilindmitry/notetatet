<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('gallery_30');?> <?php echo $gallery->name; ?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-all-tab" data-toggle="tab" href="#nav-all" role="tab" aria-controls="nav-all" aria-selected="true"><span class="ti-layout-grid3 mr-2"></span><?php echo $this->lang->line('gallery_31');?></a>
                            <a class="nav-item nav-link" id="nav-add-tab" data-toggle="tab" href="#nav-add" role="tab" aria-controls="nav-add" aria-selected="false"><span class="ti-upload mr-2"></span><?php echo $this->lang->line('gallery_32');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane show active" id="nav-all" role="tabpanel" aria-labelledby="nav-home-all">
                    <?php if ($items) : ?>
                    <div class="row">
                        <?php foreach ($items as $data) : ?>
                        <div class="col-md-3 mb-3">
                            <a href="#" data-toggle="modal" data-target="#preview_<?php echo $data->id; ?>"><img src="<?php echo base_url('uploads/galleries/'.$data->path.'');?>" class="w-100"></a>
                        </div>

                        <!-- Preview modal -->
                        <div class="modal fade" id="preview_<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-preview modal-lg modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <img src="<?php echo base_url('uploads/galleries/'.$data->path.'');?>" class="w-100">
                                    <div class="text-center mt-3">
                                        <a href="<?php echo base_url('my/apps/'.$app->id.'/galleries/delete_image/'.$data->id.'');?>" class="text-white"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('gallery_33');?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else : ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-layout-grid3"></span></h1>
                                <h5><?php echo $this->lang->line('gallery_34');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('gallery_35');?></p>
                                <a href="#" onclick="$('#nav-add-tab').trigger('click')" class="btn btn-primary btn-sm"><?php echo $this->lang->line('gallery_36');?></a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="tab-pane" id="nav-add" role="tabpanel" aria-labelledby="nav-add-tab">
                    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/galleries/upload_images/'.$gallery->id.'')) ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-upload"></span></h1>
                                <h5><?php echo $this->lang->line('gallery_37');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('gallery_38');?></p>
                                <input class="inputfile" type="file" name="image_name[]" id="file" data-multiple-caption="{count} files selected" multiple="multiple" onchange="this.form.submit()"/>
                                <label for="file"><span><?php echo $this->lang->line('gallery_39');?></span></label>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>