<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('messages_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/messages');?>"><span class="ti-bolt mr-2"></span><?php echo $this->lang->line('messages_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/messages/all');?>"><span class="ti-comments mr-2"></span><?php echo $this->lang->line('messages_3');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/messages/search');?>"><span class="ti-search mr-2"></span><?php echo $this->lang->line('messages_4');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="row mb-head">
                <div class="col-md-7">
                    <h5><?php echo $this->lang->line('messages_16');?> - <span id="total">0</span></h5>
                </div>
                <div class="col-md-5 text-right">
                    <a href="<?php echo base_url('my/apps/'.$app->id.'/messages/create_dialogue');?>" class="btn btn-success btn-sm"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('messages_6');?></a>
                </div>
            </div>
            <div id="print">
                <div class="load-wrap">
                    <div class="loader"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

function show()  
{
    $.ajax({
        type: 'GET',
        url: "<?php echo base_url('my/apps/'.$app->id.'/messages/unread_dialogues');?>",  
        cache: false,
        success: function(chatlist) {

            var listChats = JSON.parse(chatlist);

            if (listChats.event == 'success') { // success request

                if (listChats.total_unread_message > 0) { // have unread messages

                    var totalDialogues = listChats.total_dialogues;

                    successContent = '<div class="row"><div class="col-md-12"><table class="table table-hover"><thead class="thead-light"><tr><th scope="col"><?php echo $this->lang->line('messages_7');?></th><th scope="col"><?php echo $this->lang->line('messages_8');?></th><th class="text-center" scope="col"><?php echo $this->lang->line('messages_9');?></th><tbody>';

                    successLi = '';
                    
                    for (i = 0; i <= totalDialogues; i++) {

                        if (listChats.data[i].count > 0) {

                            successLi += '<tr>';
                            successLi += '<td>' + listChats.data[i].user + '</td>';
                            successLi += '<td><span class="badge badge-success mr-3">' + listChats.data[i].count + '</span><a href="<?php echo base_url('my/apps/'.$app->id.'/messages/view/');?>' + listChats.data[i].dialogue + '">' + listChats.data[i].last_message + '</a></td>';
                            successLi += '<td class="text-center">' + listChats.data[i].total + '</td>';
                            successLi += '</tr>';

                        }

                    }

                    successContent += successLi;
                    successContent += '</tbody>'

                    $("#print").html(successContent);

                    $("#total").html(listChats.total_unread_message);

                } else {

                    emptyContent = '';

                    emptyLi = '';

                    emptyLi += '<div class="row justify-content-center align-items-center mt-5">';
                    emptyLi += '<div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">';
                    emptyLi += '<div class="text-center">';
                    emptyLi += '<h1 class="text-primary"><span class="ti-comments"></span></h1>';
                    emptyLi += '<h5><?php echo $this->lang->line('messages_17');?></h5>';
                    emptyLi += '<p class="text-muted"><?php echo $this->lang->line('messages_18');?></p>';
                    emptyLi += '<a href="<?php echo base_url('my/apps/'.$app->id.'/messages/create_dialogue');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('messages_12');?></a>';
                    emptyLi += '</div>';
                    emptyLi += '</div>';
                    emptyLi += '</div>';

                    emptyContent += emptyLi;

                    $("#print").html(emptyContent);

                }

            } else if (listChats.event == 'empty') { // emty request

                emptyContent = '';

                emptyLi = '';

                emptyLi += '<div class="row justify-content-center align-items-center mt-5">';
                emptyLi += '<div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">';
                emptyLi += '<div class="text-center">';
                emptyLi += '<h1 class="text-primary"><span class="ti-comments"></span></h1>';
                emptyLi += '<h5><?php echo $this->lang->line('messages_17');?></h5>';
                emptyLi += '<p class="text-muted"><?php echo $this->lang->line('messages_18');?></p>';
                emptyLi += '<a href="<?php echo base_url('my/apps/'.$app->id.'/messages/create_dialogue');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('messages_12');?></a>';
                emptyLi += '</div>';
                emptyLi += '</div>';
                emptyLi += '</div>';

                emptyContent += emptyLi;

                $("#print").html(emptyContent);

            } else if (listChats.event == 'fail') { // fail request

                failContent = '';

                failLi = '';

                failLi += '<div class="row justify-content-center align-items-center mt-5">';
                failLi += '<div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">';
                failLi += '<div class="text-center">';
                failLi += '<h1 class="text-danger"><span class="ti-alert"></span></h1>';
                failLi += '<h5><?php echo $this->lang->line('messages_20');?></h5>';
                failLi += '<p class="text-muted">' + listChats.message + '</p>';
                failLi += '<a href="<?php echo base_url('my/apps/'.$app->id.'/messages');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('messages_19');?></a>';
                failLi += '</div>';
                failLi += '</div>';
                failLi += '</div>';

                failContent += failLi;

                $("#print").html(failContent);
                
            }

        }
    });
}

$(document).ready(function(){  
  show();  
  setInterval('show()',3000);  
});
</script>