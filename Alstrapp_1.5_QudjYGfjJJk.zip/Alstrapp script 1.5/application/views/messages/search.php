<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('messages_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/messages');?>"><span class="ti-bolt mr-2"></span><?php echo $this->lang->line('messages_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/messages/all');?>"><span class="ti-comments mr-2"></span><?php echo $this->lang->line('messages_3');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/messages/search');?>"><span class="ti-search mr-2"></span><?php echo $this->lang->line('messages_4');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <?php if (!isset($_GET['search'])) : ?>
    <?php echo form_open(site_url('my/apps/'.$app->id.'/messages/search/?'), array('method'=>'get')) ?>
    <div class="row justify-content-center align-items-center mt-5">
        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
            <div class="text-center">
                <h1 class="text-primary"><span class="ti-search"></span></h1>
                <h5><?php echo $this->lang->line('messages_4');?></h5>
                <p class="text-muted"><?php echo $this->lang->line('messages_21');?></p>
            </div>
            <input type="text" name="search" class="form-control" <?php if (isset($_GET['search'])) : ?>value="<?php echo $_GET['search'] ?>" <?php endif; ?>placeholder="<?php echo $this->lang->line('messages_22');?>?">
        </div>
    </div>
    <?php echo form_close(); ?>
    <?php else : ?>
    <div class="row mb-head">
        <div class="col-md-7">
            <h5 class="mb-0"><?php echo $this->lang->line('messages_23');?> - <?php echo $total_records; ?></h5>
            <small class="text-muted"><?php echo $this->lang->line('messages_24');?> "<?php echo $_GET['search'] ?>"</small>
        </div>
        <div class="col-md-5 text-right">
            <a href="<?php echo base_url('my/apps/'.$app->id.'/messages/search');?>" class="btn btn-success btn-sm"><span class="ti-reload mr-2"></span><?php echo $this->lang->line('messages_25');?></a>
        </div>
    </div>
    <?php if ($total_records) : ?>
    <table class="table table-hover">
        <thead class="thead-light">
            <tr>
                <th scope="col"><?php echo $this->lang->line('messages_26');?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($messages as $data) : ?>
                <tr>
                    <td>
                        <small class="text-muted"><span class="ti-calendar mr-2"></span><?php echo $data->created; ?></small><br>
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/messages/view/'.$data->dialogue.'');?>" target="_blank"><?php echo $data->message; ?></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else : ?>
    <div class="row justify-content-center align-items-center mt-5">
        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
            <div class="text-center">
                <h1 class="text-danger"><span class="ti-face-sad"></span></h1>
                <h5><?php echo $this->lang->line('messages_27');?></h5>
                <p class="text-muted"><?php echo $this->lang->line('messages_28');?></p>
                <a href="<?php echo base_url('my/apps/'.$app->id.'/messages/search');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('messages_29');?></a>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>