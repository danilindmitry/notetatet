<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-8">
                    <h4><?php echo $this->lang->line('messages_30');?> <a href="<?php echo base_url('my/apps/'.$app->id.'/users/edit_user/'.$dialogue->user.'');?>" target="_blank"><?php echo $this->template->get_user_fullname_for_form($dialogue->user); ?></a></h4>
                </div>
                <div class="col-md-4 text-right">
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <?php if ($dialogue->ban == 1) : ?>
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/messages/user_ban/'.$dialogue->id.'');?>" class="btn btn-danger btn-sm"><span class="ti-na mr-2"></span><?php echo $this->lang->line('messages_31');?></a>
                        <?php endif; ?>
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/messages/clear_chat/'.$dialogue->id.'');?>" class="btn btn-danger btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('messages_32');?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="position-relative bg-transparent">
        <div class="row mb-5" id="js-chat-list">
            <?php if (!empty($messages)) : ?>
            <?php foreach ($messages as $data) : ?>

                <?php if ($data->type == 1) : ?>

                    <div class="col-md-12">
                        <div class="balon1 p-2 m-0 position-relative">
                            <a class="float-right"> <?php echo $data->message; ?>
                            <p class="mt-2 mb-0 text-white"><small>You - <?php echo $data->created; ?></small></p></a></a>
                        </div>
                    </div>

                <?php else : ?>

                    <div class="col-md-12">
                        <div class="balon2 p-2 m-0 position-relative">
                            <a class="float-left sohbet2"> <?php echo $data->message; ?>
                            <p class="mt-2 mb-0"><small><?php echo $this->lang->line('messages_7');?> - <?php echo $data->created; ?></small></p></a>
                        </div>
                    </div>

                <?php endif; ?>

            <?php endforeach; ?>

            <?php if ($dialogue->ban == 2) : ?>
            <div class="col-md-12">
                <div class="alert alert-warning" role="alert">
                    <div class="row">
                        <div class="col-md-10">
                            <?php echo $this->lang->line('messages_33');?>!
                        </div>
                        <div class="col-md-2">
                            <a href="<?php echo base_url('my/apps/'.$app->id.'/messages/user_unban/'.$dialogue->id.'');?>" class="btn btn-success btn-sm btn-block"><?php echo $this->lang->line('messages_34');?></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
            <?php endif; ?>
          
    </div>

    <form action="" id="js-chat-form" autocomplete="off">
        <div class="row fixed-bottom-chat p-2 mt-3">
            <div class="col-md-10">
                <input type="text" class="form-control" id="js-chat-input" placeholder="<?php echo $this->lang->line('messages_35');?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary btn-block"><?php echo $this->lang->line('messages_36');?></button>
            </div>
        </div>
    </form>
</div>

<script>
$(function () {
    $('html, body').scrollTop(1E10);
});
</script>

<script>
var chatForm = $('#js-chat-form'),
    chatList = $('#js-chat-list'),
    chatInput = $('#js-chat-input');

function generateTemplate(message) {
    template = '';
  
    template += '<div class="col-md-12">';
    template += '<div class="balon1 p-2 m-0 position-relative">';
    template += '<a class="float-right"> ' + message + '';
    template += '<p class="mt-2 mb-0 text-white"><small><?php echo $this->lang->line('messages_37');?> - 2018-11-15 21:21:22</small></p></a></a>';
    template += '</div>';
    template += '</div>';
  
    return template;
}

chatForm.on('submit', function(e) {
    e.preventDefault();
    $this = $(this);

    var message = chatInput.val();
    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
        csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

    $.ajax({
        type: 'POST',
        url: "<?php echo base_url('my/apps/'.$app->id.'/messages/create_message/'.$dialogue->id.'');?>",
        data: 'message=' + message + '&' + csrfName + '=' + csrfHash,
        success: function(success_data) {

            var response = JSON.parse(success_data);

            if (response.event == 'success') {

                templateMessage = '';
  
                templateMessage += '<div class="col-md-12">';
                templateMessage += '<div class="balon1 p-2 m-0 position-relative">';
                templateMessage += '<a class="float-right"> ' + response.message + '';
                templateMessage += '<p class="mt-2 mb-0 text-white"><small><?php echo $this->lang->line('messages_37');?> - ' + response.created + '</small></p></a></a>';
                templateMessage += '</div>';
                templateMessage += '</div>';

                if(message.trim() !== '') {
                    chatList.append(templateMessage);
                    chatInput.val('');
                };

                $(function () {
                    $('html, body').scrollTop(1E10);
                });

            } else {

                swal({
                    title: '<?php echo $this->lang->line('messages_38');?>!',
                    type: 'error',
                    html: response.message,
                    confirmButtonText: 'Ok'
                })

            }

        },
        error: function(error_data) {

            swal({
                title: '<?php echo $this->lang->line('messages_38');?>!',
                type: 'error',
                html:'<?php echo $this->lang->line('messages_39');?>',
                confirmButtonText: 'Ok'
            })

        }
    });
    
});
</script>

<script>
function show()  
{
    var chatList = $('#js-chat-list');

    $.ajax({
        type: 'GET',
        url: "<?php echo base_url('my/apps/'.$app->id.'/messages/check_new_messages/'.$dialogue->id.'');?>",  
        cache: false,
        success: function(messages) {

            var chat = JSON.parse(messages);

            if (chat.event == 'success') {

                successLi = '';

                for (i = 0; i <= chat.count; i++) {

                    successLi += '<div class="col-md-12">';
                    successLi += '<div class="balon2 p-2 m-0 position-relative">';
                    successLi += '<a class="float-left sohbet2"> ' + chat.data[i].message + '';
                    successLi += '<p class="mt-2 mb-0"><small>User - ' + chat.data[i].created + '</small></p></a></a>';
                    successLi += '</div>';
                    successLi += '</div>';

                }

                chatList.append(successLi);

                $(function () {
                    $('html, body').scrollTop(1E10);
                });

            }

        },
        error: function(error) {

            swal({
                title: '<?php echo $this->lang->line('messages_38');?>!',
                type: 'error',
                html:'<?php echo $this->lang->line('messages_39');?>',
                confirmButtonText: 'Ok'
            })

        }
    });
}

$(document).ready(function(){  
  show();  
  setInterval('show()',3000);  
});
</script>