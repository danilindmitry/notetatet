<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('messages_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/messages');?>"><span class="ti-bolt mr-2"></span><?php echo $this->lang->line('messages_2');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/messages/all');?>"><span class="ti-comments mr-2"></span><?php echo $this->lang->line('messages_3');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/messages/search');?>"><span class="ti-search mr-2"></span><?php echo $this->lang->line('messages_4');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="row mb-head">
                <div class="col-md-7">
                    <h5><?php echo $this->lang->line('messages_5');?> - <?php echo $total_records; ?></h5>
                </div>
                <div class="col-md-5 text-right">
                    <a href="<?php echo base_url('my/apps/'.$app->id.'/messages/create_dialogue');?>" class="btn btn-success btn-sm"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('messages_6');?></a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php if ($total_records) : ?>
            <table class="table table-hover">
                <thead class="thead-light">
                    <tr>
                        <th scope="col"><?php echo $this->lang->line('messages_7');?></th>
                        <th scope="col"><?php echo $this->lang->line('messages_8');?></th>
                        <th class="text-center" scope="col"><?php echo $this->lang->line('messages_9');?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($dialogues as $data) : ?>
                        <tr>
                            <td><a href="<?php echo base_url('my/apps/'.$app->id.'/users/edit_user/'.$data->user.'');?>" target="_blank"><?php echo $this->template->get_user_fullname_for_form($data->user); ?></a></td>
                            <td><?php echo $this->template->get_last_messages_count($app->id, $data->id); ?></td>
                            <td class="text-center"><?php echo $this->template->get_count_total_messages_for_dialogue($app->id, $data->id); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if (!empty($links)) : ?>
            <div class="row">
                <div class="col-md-12">
                    <?php echo $links ?>
                </div>
            </div>
            <?php endif; ?>
            <?php else : ?>
            <div class="row justify-content-center align-items-center mt-5">
                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                    <div class="text-center">
                        <h1 class="text-primary"><span class="ti-comments"></span></h1>
                        <h5><?php echo $this->lang->line('messages_10');?></h5>
                        <p class="text-muted"><?php echo $this->lang->line('messages_11');?></p>
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/messages/create_dialogue');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('messages_12');?></a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>