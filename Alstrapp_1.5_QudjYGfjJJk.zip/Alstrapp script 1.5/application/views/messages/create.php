<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('messages_12');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/messages');?>"><span class="ti-bolt mr-2"></span><?php echo $this->lang->line('messages_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/messages/all');?>"><span class="ti-comments mr-2"></span><?php echo $this->lang->line('messages_3');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/messages/search');?>"><span class="ti-search mr-2"></span><?php echo $this->lang->line('messages_4');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <?php echo form_open(site_url('my/apps/'.$app->id.'/messages/add_dialogue')) ?>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label><?php echo $this->lang->line('messages_13');?></label>
                <input type="text" class="form-control form-control-sm" name="username" placeholder="alstrapp">
                <small class="form-text text-muted"><?php echo $this->lang->line('messages_14');?>.</small>
            </div>
        </div>
        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('messages_15');?></button>
        </div>
    </div>
    <?php echo form_close(); ?> 
</div>