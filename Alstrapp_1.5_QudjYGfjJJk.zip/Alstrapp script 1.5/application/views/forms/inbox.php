<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <?php if (!isset($_GET['search'])) : ?>
                    <h4><?php echo $this->lang->line('forms_36');?> - <?php echo $form->name; ?></h4>
                    <?php else : ?>
                    <h4 class="mb-0"><?php echo $this->lang->line('forms_36');?> - <?php echo $form->name; ?> / <?php echo $this->lang->line('forms_37');?> - <?php echo $total_records; ?></h4>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/forms/inbox/'.$form->id.'');?>"><span class="ti-archive mr-2"></span><?php echo $this->lang->line('forms_38');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/forms/inbox/'.$form->id.'?sort=unread');?>"><span class="ti-bolt mr-2"></span><?php echo $this->lang->line('forms_39');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/forms/inbox/'.$form->id.'?sort=search');?>"><span class="ti-search mr-2"></span><?php echo $this->lang->line('forms_40');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <?php if ($total_records) : ?>
            <table class="table table-hover">
                <thead class="thead-light">
                    <tr>
                        <th scope="col"><?php echo $this->lang->line('forms_41');?></th>
                        <th scope="col"><?php echo $this->lang->line('forms_42');?></th>
                        <th scope="col"><?php echo $this->lang->line('forms_43');?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($forms_received as $data) : ?>
                        <tr <?php if ($data->status == 2) : ?>class="table-warning"<?php endif; ?>>
                            <td><?php echo $data->id; ?></td>
                            <td><span class="ti-calendar mr-2"></span><?php echo $data->created; ?></td>
                            <td>
                                <a href="<?php echo base_url('my/apps/'.$app->id.'/users/edit_user/'.$data->user.'');?>" target="_blank">
                                    <?php echo $this->template->get_user_fullname_for_form($data->user); ?>
                                </a>
                            </td>
                            <td class="text-right">
                                <a href="<?php echo base_url('my/apps/'.$app->id.'/forms/detail_inbox/'.$data->id.'');?>" class="btn btn-primary btn-sm mr-3"><span class="ti-eye mr-2"></span><?php echo $this->lang->line('forms_44');?></a>
                                <a href="#" data-toggle="modal" data-target="#del_result<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('forms_4');?></a>
                            </td>
                        </tr>
                        <!-- Delete result -->
                        <div class="modal" id="del_result<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content border-none">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-10">
                                                    <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                </div>
                                                <div class="col-md-2 text-right">
                                                    <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                </div>
                                            </div>
                                            <h5 class="mb-4"><?php echo $this->lang->line('forms_45');?> <?php echo $data->id; ?></h5>
                                            <p><?php echo $this->lang->line('forms_6');?></p>
                                            <div class="text-right">
                                                <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('forms_7');?></button>
                                                <a href="<?php echo base_url('my/apps/'.$app->id.'/forms/delete_form_result/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('forms_8');?>!</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if (!empty($links)) : ?>
            <div class="row">
                <div class="col-md-12">
                    <?php echo $links ?>
                </div>
            </div>
            <?php endif; ?>
            <?php else : ?>
            <?php if (!isset($_GET['search'])) : ?>
            <div class="row justify-content-center align-items-center mt-5">
                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                    <div class="text-center">
                        <h1 class="text-primary"><span class="ti-archive"></span></h1>
                        <h5><?php echo $this->lang->line('forms_46');?></h5>
                        <p class="text-muted"><?php echo $this->lang->line('forms_47');?></p>
                    </div>
                </div>
            </div>
            <?php else : ?>
            <div class="row justify-content-center align-items-center mt-5">
                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                    <div class="text-center">
                        <h1 class="text-danger"><span class="ti-face-sad"></span></h1>
                        <h5><?php echo $this->lang->line('forms_48');?></h5>
                        <p class="text-muted"><?php echo $this->lang->line('forms_49');?></p>
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/forms/inbox/'.$form->id.'');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('forms_50');?></a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
