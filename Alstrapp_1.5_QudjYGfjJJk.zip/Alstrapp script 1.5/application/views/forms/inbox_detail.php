<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $this->lang->line('forms_51');?> <?php echo $detail->id; ?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <?php if (!empty($detail->result)) : ?>
                <table class="table table-bordered">
                    <tbody>
                    <?php foreach ($form_elements as $datas) : ?>
                        <tr>
                            <td><strong><?php echo $datas->name; ?></strong></td>
                            <?php if ($datas->type == 7 or $datas->type == 9) : ?>
                                <?php if (!empty($json_array[$datas->prefix])) : ?>
                                    <?php if (!$json_array[$datas->prefix]) : ?>
                                    <td></td> 
                                    <?php else : ?>
                                    <td><?php echo $json_array[$datas->prefix][0]; ?></td>
                                    <?php endif; ?>
                                <?php else : ?>
                                <td></td>
                                <?php endif; ?>
                            <?php else : ?>
                                <?php if (!empty($json_array[$datas->prefix])) : ?>
                                <td><?php echo $json_array[$datas->prefix]; ?></td>
                                <?php else : ?>
                                <td></td>
                                <?php endif; ?>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <div class="row justify-content-center align-items-center mt-5">
                    <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                        <div class="text-center">
                            <h1 class="text-danger"><span class="ti-alert"></span></h1>
                            <h5><?php echo $this->lang->line('forms_52');?></h5>
                            <p class="text-muted"><?php echo $this->lang->line('forms_53');?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>