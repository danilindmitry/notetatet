<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $form->name; ?> - <?php echo $this->lang->line('forms_1');?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-8">
                     <div class="card card-dropzone">
                        <div class="card-body">
                            <?php if ($form_elements) : ?>
                            <ul class="list-group" id="form_elements_sort">
                                <?php foreach ($form_elements as $data) : ?>
                                <li href="#" class="list-group-item flex-column align-items-start cursor-move" id="item-<?php echo $data->id; ?>">
                                    <div class="d-flex w-100 justify-content-between">
                                        <p class="mb-1"><strong><?php echo $data->name; ?></strong></p>
                                        <?php if ($data->type == 1) : ?>
                                        <small class="text-muted"><span class="ti-uppercase" data-toggle="tooltip" data-placement="left" title="Text input"></span></small>
                                        <?php endif; ?>
                                        <?php if ($data->type == 2) : ?>
                                        <small class="text-muted"><span class="ti-email" data-toggle="tooltip" data-placement="left" title="Numeric input"></span></small>
                                        <?php endif; ?>
                                        <?php if ($data->type == 3) : ?>
                                        <small class="text-muted"><span class="ti-quote-right" data-toggle="tooltip" data-placement="left" title="Numeric input"></span></small>
                                        <?php endif; ?>
                                        <?php if ($data->type == 4) : ?>
                                        <small class="text-muted"><span class="ti-calendar" data-toggle="tooltip" data-placement="left" title="Data input"></span></small>
                                        <?php endif; ?>
                                        <?php if ($data->type == 5) : ?>
                                        <small class="text-muted"><span class="ti-layout-width-full" data-toggle="tooltip" data-placement="left" title="Textarea"></span></small>
                                        <?php endif; ?>
                                        <?php if ($data->type == 6) : ?>
                                        <small class="text-muted"><span class="ti-layout-list-thumb-alt" data-toggle="tooltip" data-placement="left" title="Select list"></span></small>
                                        <?php endif; ?>
                                        <?php if ($data->type == 7) : ?>
                                        <small class="text-muted"><span class="ti-check-box" data-toggle="tooltip" data-placement="left" title="Checkbox"></span></small>
                                        <?php endif; ?>
                                        <?php if ($data->type == 8) : ?>
                                        <small class="text-muted"><i class="fa fa-dot-circle-o" aria-hidden="true" data-toggle="tooltip" data-placement="left" title="Radio group"></i></span></small>
                                        <?php endif; ?>
                                        <?php if ($data->type == 9) : ?>
                                        <small class="text-muted"><i class="fa fa-toggle-off" aria-hidden="true" data-toggle="tooltip" data-placement="left" title="Toogle"></i></span></small>
                                        <?php endif; ?>
                                        <?php if ($data->type == 10) : ?>
                                        <small class="text-muted"><i class="fa fa-arrows-h" aria-hidden="true" data-toggle="tooltip" data-placement="left" title="Range"></i></span></small>
                                        <?php endif; ?>
                                    </div>
                                   <small><a href="#"  data-toggle="modal" data-target="#source_<?php echo $data->id; ?>" class="text-muted mr-2"><span class="ti-paint-roller mr-1"></span><?php echo $this->lang->line('forms_3');?></a><a href="#" data-toggle="modal" data-target="#del_element<?php echo $data->id; ?>" class="text-danger mr-2"><span class="ti-trash mr-1"></span><?php echo $this->lang->line('forms_4');?></a></small>
                                </li>
                                <!-- Delete elemnt -->
                                <div class="modal" id="del_element<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content border-none">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-10">
                                                            <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                        </div>
                                                        <div class="col-md-2 text-right">
                                                            <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                        </div>
                                                    </div>
                                                    <h5 class="mb-4"><?php echo $this->lang->line('forms_5');?> "<?php echo $data->name; ?>"</h5>
                                                    <p><?php echo $this->lang->line('forms_6');?></p>
                                                    <div class="text-right">
                                                        <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('forms_7');?></button>
                                                        <a href="<?php echo base_url('my/apps/'.$app->id.'/forms/delete_form_elements/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('forms_8');?>!</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </ul>
                            <?php else : ?>
                            <div class="row justify-content-center align-items-center mt-5">
                                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                                    <div class="text-center">
                                        <h1 class="text-success"><span class="ti-arrow-right"></span></h1>
                                        <p class="text-muted"><?php echo $this->lang->line('forms_9');?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="list-group sticky-top">
                        <a href="#" data-toggle="modal" data-target="#element_input" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Input
                            <span class="badge-pill"><span class="ti-uppercase"></span></span>
                        </a>
                        <a href="#" data-toggle="modal" data-target="#element_textarea" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Textarea
                            <span class="badge-pill"><span class="ti-layout-width-full"></span></span>
                        </a>
                        <a href="#" data-toggle="modal" data-target="#element_range" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Range
                            <span class="badge-pill"><i class="fa fa-arrows-h" aria-hidden="true"></i></span>
                        </a>
                        <a href="#" data-toggle="modal" data-target="#element_toogle" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Toogle
                            <span class="badge-pill"><i class="fa fa-toggle-off" aria-hidden="true"></i></span>
                        </a>
                        <a href="#" data-toggle="modal" data-target="#element_checkbox" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Checkbox
                            <span class="badge-pill"><span class="ti-check-box"></span></span>
                        </a>
                        <a href="#" data-toggle="modal" data-target="#element_select" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Select list
                            <span class="badge-pill"><span class="ti-layout-list-thumb-alt"></span></span></span>
                        </a>
                        <a href="#" data-toggle="modal" data-target="#element_radio" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Radio group
                            <span class="badge-pill"><i class="fa fa-dot-circle-o" aria-hidden="true"></i></span>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Input -->
<div class="modal fade" id="element_input" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('forms_10');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/create_element/'.$form->id.'')) ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_11');?></label>
                            <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('forms_11');?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_12');?></label>
                            <select class="form-control form-control-sm" name="type">
                                <option value="1"><?php echo $this->lang->line('forms_13');?></option>
                                <option value="2"><?php echo $this->lang->line('forms_14');?></option>
                                <option value="3"><?php echo $this->lang->line('forms_15');?></option>
                                <option value="4"><?php echo $this->lang->line('forms_16');?></option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_17');?></label>
                            <input type="text" class="form-control form-control-sm" name="prefix" placeholder="name">
                            <small class="form-text text-muted"><?php echo $this->lang->line('forms_18');?></small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_19');?>?</label>
                            <select class="form-control form-control-sm" name="required">
                                <option value="1"><?php echo $this->lang->line('forms_20');?></option>
                                <option value="2"><?php echo $this->lang->line('forms_21');?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('forms_22');?></button>
            </div>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>

<!-- Textarea -->
<div class="modal fade" id="element_textarea" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('forms_23');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/create_element/'.$form->id.'')) ?>
                <input type="hidden" name="type" value="5">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_11');?></label>
                            <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('forms_11');?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_17');?></label>
                            <input type="text" class="form-control form-control-sm" name="prefix" placeholder="name">
                            <small class="form-text text-muted"><?php echo $this->lang->line('forms_18');?></small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_19');?>?</label>
                            <select class="form-control form-control-sm" name="required">
                                <option value="1"><?php echo $this->lang->line('forms_20');?></option>
                                <option value="2"><?php echo $this->lang->line('forms_21');?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('forms_22');?></button>
            </div>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>

<!-- Select -->
<div class="modal fade" id="element_select" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('forms_24');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/create_element/'.$form->id.'')) ?>
                <input type="hidden" name="type" value="6">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_11');?></label>
                            <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('forms_11');?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_17');?></label>
                            <input type="text" class="form-control form-control-sm" name="prefix" placeholder="name">
                            <small class="form-text text-muted"><?php echo $this->lang->line('forms_18');?></small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_19');?>?</label>
                            <select class="form-control form-control-sm" name="required">
                                <option value="1"><?php echo $this->lang->line('forms_20');?></option>
                                <option value="2"><?php echo $this->lang->line('forms_21');?></option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div id="Type10" class="desc hide">
                            <div class="row">
                                <div class="col-md-12">
                                    <div id="menu_links">
                                        <div class="form-group">
                                            <label class="mb-1 fw-500">Option #1</label>
                                            <input type="text" name="option_item_1" class="form-control form-control-sm">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 text-right">
                                    <input type="hidden" name="menu_link_count" id="menu_link_count" value="1">
                                    <input type="button" onclick="add_option_link()" value="Add option" class="btn btn-success btn-sm">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('forms_25');?></button>
            </div>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>

<!-- Checkbox -->
<div class="modal fade" id="element_checkbox" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('forms_26');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/create_element/'.$form->id.'')) ?>
                <input type="hidden" name="type" value="7">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_11');?></label>
                            <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('forms_11');?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_17');?></label>
                            <input type="text" class="form-control form-control-sm" name="prefix" placeholder="name">
                            <small class="form-text text-muted"><?php echo $this->lang->line('forms_18');?></small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_19');?>?</label>
                            <select class="form-control form-control-sm" name="required">
                                <option value="1"><?php echo $this->lang->line('forms_20');?></option>
                                <option value="2"><?php echo $this->lang->line('forms_21');?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('forms_22');?></button>
            </div>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>

<!-- Radio group -->
<div class="modal fade" id="element_radio" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('forms_27');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/create_element/'.$form->id.'')) ?>
                <input type="hidden" name="type" value="8">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_11');?></label>
                            <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('forms_11');?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_17');?></label>
                            <input type="text" class="form-control form-control-sm" name="prefix" placeholder="name">
                            <small class="form-text text-muted"><?php echo $this->lang->line('forms_18');?></small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_19');?>?</label>
                            <select class="form-control form-control-sm" name="required">
                                <option value="1"><?php echo $this->lang->line('forms_20');?></option>
                                <option value="2"><?php echo $this->lang->line('forms_21');?></option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div id="Type11" class="desc hide">
                            <div class="row">
                                <div class="col-md-12">
                                    <div id="checkboxes">
                                        <div class="form-group">
                                            <label class="mb-1 fw-500">Radio #1</label>
                                            <input type="text" name="checkbox_item_1" class="form-control form-control-sm">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 text-right">
                                  <input type="hidden" name="checkbox_count" id="checkbox_count" value="1">
                                  <input type="button" onclick="add_radio()" value="<?php echo $this->lang->line('forms_28');?>" class="btn btn-success btn-sm">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('forms_22');?></button>
            </div>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>

<!-- Toogle -->
<div class="modal fade" id="element_toogle" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('forms_29');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/create_element/'.$form->id.'')) ?>
                <input type="hidden" name="type" value="9">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_11');?></label>
                            <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('forms_11');?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_17');?></label>
                            <input type="text" class="form-control form-control-sm" name="prefix" placeholder="name">
                            <small class="form-text text-muted"><?php echo $this->lang->line('forms_18');?></small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_19');?>?</label>
                            <select class="form-control form-control-sm" name="required">
                                <option value="1"><?php echo $this->lang->line('forms_20');?></option>
                                <option value="2"><?php echo $this->lang->line('forms_21');?></option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('forms_22');?></button>
            </div>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>

<!-- Range -->
<div class="modal fade" id="element_range" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('forms_30');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/create_element/'.$form->id.'')) ?>
                <input type="hidden" name="type" value="10">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_11');?></label>
                            <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('forms_11');?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_17');?></label>
                            <input type="text" class="form-control form-control-sm" name="prefix" placeholder="name">
                            <small class="form-text text-muted"><?php echo $this->lang->line('forms_18');?></small>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_19');?>?</label>
                            <select class="form-control form-control-sm" name="required">
                                <option value="1"><?php echo $this->lang->line('forms_20');?></option>
                                <option value="2"><?php echo $this->lang->line('forms_21');?></option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_31');?></label>
                            <input type="text" class="form-control form-control-sm" name="value" placeholder="0">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_32');?></label>
                            <input type="text" class="form-control form-control-sm" name="step" placeholder="1">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_33');?></label>
                            <input type="text" class="form-control form-control-sm" name="min" placeholder="1">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('forms_34');?></label>
                            <input type="text" class="form-control form-control-sm" name="max" placeholder="10">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('forms_22');?></button>
            </div>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>

<?php if ($form_elements) : ?>
    <?php foreach ($form_elements as $datas) : ?>
    <!-- Source code -->
    <div class="modal fade" id="source_<?php echo $datas->id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('forms_35');?> <?php echo $datas->name; ?></h5>
                    <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                        <span class="ti-close"></span>
                    </button>
                </div>
                <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/update_code/'.$datas->id.'')) ?>
                <div class="modal-body p-0">
                    <textarea rows="4" cols="50" class="code" name="code"><?php echo $datas->code; ?></textarea>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('forms_22');?></button>
                </div>
                <?php echo form_close(); ?> 
            </div>
        </div>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<script>
function qsa(sel) {
    return Array.apply(null, document.querySelectorAll(sel));
}
qsa(".code").forEach(function (editorEl) {
    CodeMirror.fromTextArea(editorEl, {
        mode: "text/html",
        theme: "material",
        lineNumbers: true,
        lineWrapping: true,
        autoRefresh: true
    });
});
</script>

<script>
    function add_option_link() 
    {
        var count = $('#menu_link_count').val();
        count++;
        $('#menu_link_count').val(count);
        var html =  '<div class="form-group">'+
                    '<label class="">Option #'+count+'</label>'+
                    '<input type="text" class="form-control form-control-sm" name="option_item_'+count+'" value="">'+
                    '</div>';
        $('#menu_links').append(html);
    }
</script>

<script>
    function add_radio() 
    {
        var count = $('#checkbox_count').val();
        count++;
        $('#checkbox_count').val(count);
        var html =  '<div class="form-group">'+
                    '<label>Radio #'+count+'</label>'+
                    '<input type="text" class="form-control form-control-sm" name="checkbox_item_'+count+'" value="">'+
                    '</div>';
        $('#checkboxes').append(html);
    }
</script>