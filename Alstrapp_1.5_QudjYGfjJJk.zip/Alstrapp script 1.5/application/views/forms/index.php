<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('forms_56');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-all-tab" data-toggle="tab" href="#nav-all" role="tab" aria-controls="nav-all" aria-selected="true"><span class="ti-widget-alt mr-2"></span><?php echo $this->lang->line('forms_57');?></a>
                            <a class="nav-item nav-link" id="nav-search-tab" data-toggle="tab" href="#nav-search" role="tab" aria-controls="nav-search" aria-selected="false"><span class="ti-search mr-2"></span><?php echo $this->lang->line('forms_40');?></a>
                            <a class="nav-item nav-link" id="nav-add-tab" data-toggle="tab" href="#nav-add" role="tab" aria-controls="nav-add" aria-selected="false"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('forms_58');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane show active" id="nav-all" role="tabpanel" aria-labelledby="nav-home-all">
                    <?php if ($total_records) : ?>
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('forms_11');?></th>
                                <th scope="col"><?php echo $this->lang->line('forms_42');?></th>
                                <th class="text-center" scope="col"><?php echo $this->lang->line('forms_59');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($forms as $data) : ?>
                                <tr>
                                    <td>
                                        <a href="#" data-toggle="modal" data-target="#edit_form<?php echo $data->id; ?>" class="text-warning mr-2"><span class="ti-pencil mr-1"></span></a><?php echo $data->name; ?>
                                    </td>
                                    <td><span class="ti-calendar mr-2"></span><?php echo $data->created; ?></td>
                                    <td class="text-center"><a href="<?php echo base_url('my/apps/'.$app->id.'/forms/inbox/'.$data->id.'?sort=unread');?>" class="text-success" data-toggle="tooltip" data-placement="bottom" title="<?php echo $this->lang->line('forms_39');?>"><?php echo $this->template->get_count_unread_form_result($data->id); ?></a> / <a href="<?php echo base_url('my/apps/'.$app->id.'/forms/inbox/'.$data->id.'');?>" data-toggle="tooltip" data-placement="bottom" title="Total"><?php echo $this->template->get_count_all_form_result($data->id); ?></a></td>
                                    <td class="text-right">
                                        <a href="<?php echo base_url('my/apps/'.$app->id.'/forms/builder/'.$data->id.'');?>" class="btn btn-primary btn-sm mr-3"><span class="ti-wand mr-2"></span><?php echo $this->lang->line('forms_60');?></a>
                                        <a href="#" data-toggle="modal" data-target="#del_form<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('forms_4');?></a>
                                    </td>
                                </tr>
                                <!-- Delete form -->
                                    <div class="modal" id="del_form<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content border-none">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="row">
                                                            <div class="col-md-10">
                                                                <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                            </div>
                                                            <div class="col-md-2 text-right">
                                                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                            </div>
                                                        </div>
                                                        <h5 class="mb-4"><?php echo $this->lang->line('forms_61');?> "<?php echo $data->name; ?>"</h5>
                                                        <p><?php echo $this->lang->line('forms_62');?></p>
                                                        <div class="text-right">
                                                            <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('forms_7');?></button>
                                                            <a href="<?php echo base_url('my/apps/'.$app->id.'/forms/delete_form/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('forms_8');?>!</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <!-- Edit form -->
                                <div class="modal" id="edit_form<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content border-none">
                                            <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/update_form/'.$data->id.'')) ?>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="row">
                                                        <div class="col-md-10">
                                                            <h1 class="text-warning"><span class="ti-pencil-alt"></span></h1>
                                                        </div>
                                                        <div class="col-md-2 text-right">
                                                            <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                        </div>
                                                    </div>
                                                    <h5 class="mb-4"><?php echo $this->lang->line('forms_63');?> "<?php echo $data->name; ?>"</h5>
                                                    <div class="form-group">
                                                        <label><?php echo $this->lang->line('forms_64');?></label>
                                                        <input type="text" class="form-control" name="name" value="<?php echo $data->name; ?>" placeholder="<?php echo $this->lang->line('forms_65');?>">
                                                    </div>
                                                    <div class="text-right">
                                                        <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('forms_66');?></button>
                                                        <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('forms_67');?>!</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php echo form_close(); ?> 
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if (!empty($links)) : ?>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $links ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php else : ?>
                    <?php if (!isset($_GET['search'])) : ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-widget-alt"></span></h1>
                                <h5><?php echo $this->lang->line('forms_68');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('forms_69');?></p>
                                <a href="#" onclick="$('#nav-add-tab').trigger('click')" class="btn btn-primary btn-sm"><?php echo $this->lang->line('forms_70');?></a>
                            </div>
                        </div>
                    </div>
                    <?php else : ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-danger"><span class="ti-face-sad"></span></h1>
                                <h5><?php echo $this->lang->line('forms_48');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('forms_49');?></p>
                                <a href="<?php echo base_url('my/apps/'.$app->id.'/forms');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('forms_71');?></a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="tab-pane" id="nav-search" role="tabpanel" aria-labelledby="nav-search-tab">
                    <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/?'), array('method'=>'get')) ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-search"></span></h1>
                                <h5><?php echo $this->lang->line('forms_40');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('forms_72');?></p>
                            </div>
                            <input type="text" name="search" class="form-control" <?php if (isset($_GET['search'])) : ?>value="<?php echo $_GET['search'] ?>" <?php endif; ?>placeholder="<?php echo $this->lang->line('forms_55');?>?">
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
                <div class="tab-pane" id="nav-add" role="tabpanel" aria-labelledby="nav-add-tab">
                    <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/create_form')) ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('forms_64');?></label>
                                <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('forms_65');?>">
                                <small class="form-text text-muted"><?php echo $this->lang->line('forms_73');?></small>
                            </div>
                        </div>
                        <div class="col-md-12 text-right">
                            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('forms_74');?></button>
                        </div>
                    </div>
                    <?php echo form_close(); ?> 
                </div>
            </div>
        </div>
    </div>
</div>
