<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('forms_36');?> - <?php echo $form->name; ?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/forms/inbox/'.$form->id.'');?>"><span class="ti-archive mr-2"></span><?php echo $this->lang->line('forms_38');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/forms/inbox/'.$form->id.'?sort=unread');?>"><span class="ti-bolt mr-2"></span><?php echo $this->lang->line('forms_39');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/forms/inbox/'.$form->id.'?sort=search');?>"><span class="ti-search mr-2"></span><?php echo $this->lang->line('forms_40');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <?php echo form_open(site_url('my/apps/'.$app->id.'/forms/inbox/'.$form->id.'/?'), array('method'=>'get')) ?>
            <div class="row justify-content-center align-items-center mt-5">
                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                    <div class="text-center">
                        <h1 class="text-primary"><span class="ti-search"></span></h1>
                        <h5><?php echo $this->lang->line('forms_40');?></h5>
                        <p class="text-muted"><?php echo $this->lang->line('forms_54');?></p>
                    </div>
                    <input type="text" name="search" class="form-control" <?php if (isset($_GET['search'])) : ?>value="<?php echo $_GET['search'] ?>" <?php endif; ?>placeholder="<?php echo $this->lang->line('forms_55');?>?">
                </div>
            </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>
