<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('statistic_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/statistics');?>"><span class="ti-calendar mr-2"></span><?php echo $this->lang->line('statistic_2');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/statistics/annual');?>"><span class="ti-clipboard mr-2"></span><?php echo $this->lang->line('statistic_3');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
	<div class="row">
		<div class="col-md-12">
			<div class="row mb-head">
                 <div class="col-md-9">
                     <h5 class="mb-0"><?php echo $this->lang->line('statistic_4');?> <?php echo $month;?>, <?php echo $year;?></h5>
                 </div>
                 <div class="col-md-3 text-right">
                    <div class="btn-group" role="group" aria-label="Basic example">
                    	<?php if ($left_code) : ?>
					  	<a href="<?php echo base_url('my/apps/'.$app->id.'/statistics/?month='.$left_code.'');?>" class="btn btn-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="<?php echo $left;?>"><span class="ti-angle-left"></span></a>
					  	<?php else : ?>
					  	<a href="#" class="btn btn-secondary btn-sm disabled"><span class="ti-angle-left"></span></a>
					  	<?php endif; ?>
					  	<?php if ($right_code) : ?>
					  	<a href="<?php echo base_url('my/apps/'.$app->id.'/statistics/?month='.$right_code.'');?>" class="btn btn-secondary btn-sm" data-toggle="tooltip" data-placement="top" title="<?php echo $right;?>"><span class="ti-angle-right"></span></a>
					  	<?php else : ?>
					  	<a href="#" class="btn btn-secondary btn-sm disabled"><span class="ti-angle-right"></span></a>
					  	<?php endif; ?>
					</div>
                 </div>
            </div>
            <?php if ($total_records) : ?>
            <div class="row">
            	<div class="col-md-12">
            		<div class="card">
					  	<div class="card-body">
					    	<div class="row">
					    		<div class="col-md-8">
					    			<canvas id="statistics" height="150"></canvas>
					    		</div>
					    		<div class="col-md-4">
					    			<canvas id="chart" height="300"></canvas>
					    		</div>
					    	</div>
					    	<div class="row mt-4 text-center">
		                        <div class="col-md-4">
		                            <h6 class="text-uppercase"><?php echo $this->lang->line('statistic_5');?></h6>
		                            <p class="text-primary"><?php echo $total_records;?></p>
		                        </div>
		                        <div class="col-md-4">
		                            <h6 class="text-uppercase">iOS</h6>
		                            <p class="text-primary"><?php echo $ios_total;?></p>
		                        </div>
		                        <div class="col-md-4">
		                            <h6 class="text-uppercase">Android</h6>
		                            <p class="text-primary"><?php echo $android_total;?></p>
		                        </div>
		                    </div>
					  	</div>
					</div>
            	</div>
            </div>
			<div class="row mt-4">
                <div class="col-md-12">
                	<table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('statistic_6');?></th>
                                <th scope="col"><?php echo $this->lang->line('statistic_7');?></th>
                                <th class="text-center" scope="col"><?php echo $this->lang->line('statistic_8');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        	<?php foreach ($statistics as $dataq) : ?>
                        	<tr>
                        		<td width="25%"><span class="ti-calendar mr-2"></span><?php echo $dataq->date; ?></td>
	                        	<td>
	                                <a href="<?php echo base_url('my/apps/'.$app->id.'/users/edit_user/'.$dataq->user.'');?>" target="_blank">
	                                    <?php echo $this->template->get_user_fullname_for_form($dataq->user); ?>
	                                </a>
	                            </td>
	                            <td class="text-center">
	                            	<?php if ($dataq->device == 1) : ?>
	                            	<span class="ti-apple mr-2 text-black-50"></span>iOS
	                            	<?php endif; ?>
	                            	<?php if ($dataq->device == 2) : ?>
	                            	<span class="ti-android mr-2 text-success"></span>Android
	                            	<?php endif; ?>
	                            </td>
	                            <td class="text-right">
                                    <a href="#" data-toggle="modal" data-target="#del_item<?php echo $dataq->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('statistic_9');?></a>
                                </td>
                        	</tr>
                        	<!-- Delete item -->
                            <div class="modal" id="del_item<?php echo $dataq->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content border-none">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-10">
                                                        <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                    </div>
                                                    <div class="col-md-2 text-right">
                                                        <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                    </div>
                                                </div>
                                                <h5 class="mb-4"><?php echo $this->lang->line('statistic_10');?> "<?php echo $dataq->date; ?>"?</h5>
                                                <p><?php echo $this->lang->line('statistic_1');?></p>
                                                <div class="text-right">
                                                    <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('statistic_12');?></button>
                                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/statistics/delete_item/'.$dataq->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('statistic_13');?>!</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        	<?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if (!empty($links)) : ?>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $links ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php else : ?>
            <div class="row justify-content-center align-items-center mt-5">
                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                    <div class="text-center">
                        <h1 class="text-primary"><span class="ti-pie-chart"></span></h1>
                        <h5><?php echo $this->lang->line('statistic_14');?></h5>
                        <p class="text-muted"><?php echo $this->lang->line('statistic_15');?>.</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
		</div>
	</div>
</div>
<?php if ($total_records) : ?>
<script>
    var ctx = document.getElementById("statistics").getContext('2d');
    var parners = new Chart(ctx, {
        type: 'line',
        	data: {
                labels: [<?php foreach ($dates as $data) : ?>
        			"<?php echo $data; ?>",
        		<?php endforeach; ?>
        		],
                datasets: [{
                    label: 'iOS',
                    data: [<?php foreach ($dates as $data) : ?>
            		<?php echo $this->template->get_total_statistics_for_day($app->id, 1, $data, $current_m, date("Y")); ?>,
            	   	<?php endforeach; ?>],
                    backgroundColor: 'rgba(243, 92, 92, 0.13)',
                    borderColor: '#f35c5c',
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#f35c5c',
                    pointRadius: 5,
                    pointBorderWidth: 1,
                    borderWidth: 3
                },{
		        	label: 'Android',
		        	data: [<?php foreach ($dates as $data) : ?>
            		<?php echo $this->template->get_total_statistics_for_day($app->id, 2, $data, $current_m, date("Y")); ?>,
            	   	<?php endforeach; ?>],
		            backgroundColor: 'rgba(104, 197, 125, 0.13)',
		            borderColor: '#68c57d',
		            pointBackgroundColor: '#fff',
		            pointBorderColor: '#68c57d',
		            pointRadius: 5,
		            pointBorderWidth: 1,
		            borderWidth: 3
		        }]
            },
            options: {
                responsive: true,
                tooltips: {
                    mode: 'index',
                    intersect: false,
                },

                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true
                        }
                    }]
                }
            }
    });
</script>

<script>
	var data = {
	labels: [
	    "iOS",
	    "Android"
	],
	datasets: [{
	    data: [<?php echo $ios_total;?>, <?php echo $android_total;?>],
	    backgroundColor: [
	      "#f35c5c",
	      "#68c57d"
	    ],
	    hoverBackgroundColor: [
	      "#f46c6c",
	      "#77ca8a"
	    ]
	  }]
	};
	var ctx = $("#chart");
	var myChart = new Chart(ctx, {
	  	type: 'doughnut',
	  	options: {
	        legend: {
	            display: false,
	        },
	    },
	 	data: data
	});
</script>
<?php endif; ?>