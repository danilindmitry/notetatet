<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('navigation_32');?> - <?php echo $item->name;?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-all-tab" data-toggle="tab" href="#nav-all" role="tab" aria-controls="nav-all" aria-selected="true"><span class="ti-pencil-alt mr-2"></span><?php echo $this->lang->line('navigation_33');?></a>
                            <a class="nav-item nav-link" id="nav-settings-tab" data-toggle="tab" href="#nav-settings" role="tab" aria-controls="nav-settings" aria-selected="false"><span class="ti-settings mr-2"></span><?php echo $this->lang->line('navigation_34');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <?php echo form_open(site_url('my/apps/'.$app->id.'/navigation/update_item/'.$item->id.'')) ?>
    <div class="row">
        <div class="col-md-12">
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane show active" id="nav-all" role="tabpanel" aria-labelledby="nav-home-all">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('navigation_18');?></label>
                                        <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('navigation_19');?>" value="<?php echo $item->name; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('navigation_27');?></label>
                                        <select class="form-control form-control-sm" name="icon_library">
                                            <option value="1" <?php if ($item->icon_library == 1) : ?>selected<?php endif; ?>>Material</option>
                                            <option value="2" <?php if ($item->icon_library == 2) : ?>selected<?php endif; ?>>Framework7</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo $this->lang->line('navigation_28');?></label>
                                        <input type="text" class="form-control form-control-sm" name="icon" placeholder="home" value="<?php echo $item->icon; ?>">
                                    </div>
                                </div>
                            </div>
                            <?php if ($item->type == 1) : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Link</label>
                                        <input type="text" class="form-control form-control-sm" name="path" placeholder="https://alstrapp.ru/" value="<?php echo $item->path; ?>">
                                    </div>
                                </div>
                            </div>
                            <?php elseif ($item->type == 2) : ?>
                            <?php if (empty($result)) : ?>
                             <div class="row">
                                <div class="col-md-12">
                                    <h6 class="mt-2 text-danger"><?php echo $this->lang->line('navigation_35');?></h6>
                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/posts/add_category');?>"><?php echo $this->lang->line('navigation_36');?>!</a>
                                </div>
                            </div>
                            <?php else : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <h6 class="mt-2 mb-3"><?php echo $this->lang->line('navigation_37');?></h6>
                                    <table class="table table-hover">
                                        <thead class="thead-light">
                                            <tr>
                                                <th scope="col"></th>
                                                <th scope="col"><?php echo $this->lang->line('navigation_9');?></th>
                                                <th scope="col"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($result as $data) : ?>
                                            <tr>
                                                <td width="5%">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" id="<?php echo $data->id; ?>" name="id" class="custom-control-input" value="<?php echo $data->id; ?>" <?php if (!empty($item->path)) : ?><?php if ($this->template->get_id_for_menu_item($item->path) == $data->id) : ?>checked<?php endif; ?><?php endif; ?>>
                                                        <label class="custom-control-label" for="<?php echo $data->id; ?>"></label>
                                                    </div>
                                                </td>
                                                <td><?php echo $data->name; ?></td>
                                                <td class="text-right"><a href="<?php echo base_url('my/apps/'.$app->id.'/posts/edit_category/'.$data->id.'');?>" target="_blank" class="btn btn-light btn-sm"><span class="ti-eye mr-2"></span><?php echo $this->lang->line('navigation_38');?></a></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php elseif ($item->type == 3) : ?>
                            <?php if (empty($result)) : ?>
                             <div class="row">
                                <div class="col-md-12">
                                    <h6 class="mt-2 text-danger"><?php echo $this->lang->line('navigation_39');?></h6>
                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/posts/add_post');?>"><?php echo $this->lang->line('navigation_36');?>!</a>
                                </div>
                            </div>
                            <?php else : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <h6 class="mt-2 mb-3"><?php echo $this->lang->line('navigation_40');?></h6>
                                    <table class="table table-hover">
                                        <thead class="thead-light">
                                            <tr>
                                                <th scope="col"></th>
                                                <th scope="col"><?php echo $this->lang->line('navigation_9');?></th>
                                                <th scope="col"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($result as $data) : ?>
                                            <tr>
                                                <td width="5%">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" id="<?php echo $data->id; ?>" name="id" class="custom-control-input" value="<?php echo $data->id; ?>" <?php if (!empty($item->path)) : ?><?php if ($this->template->get_id_for_menu_item($item->path) == $data->id) : ?>checked<?php endif; ?><?php endif; ?>>
                                                        <label class="custom-control-label" for="<?php echo $data->id; ?>"></label>
                                                    </div>
                                                </td>
                                                <td><?php echo $data->name; ?></td>
                                                <td class="text-right"><a href="<?php echo base_url('my/apps/'.$app->id.'/posts/edit_post/'.$data->id.'');?>" target="_blank" class="btn btn-light btn-sm"><span class="ti-eye mr-2"></span><?php echo $this->lang->line('navigation_38');?></a></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php if (!empty($links)) : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $links ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php elseif ($item->type == 4) : ?>
                            <?php if (empty($result)) : ?>
                             <div class="row">
                                <div class="col-md-12">
                                    <h6 class="mt-2 text-danger"><?php echo $this->lang->line('navigation_41');?></h6>
                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/galleries');?>"><?php echo $this->lang->line('navigation_36');?>!</a>
                                </div>
                            </div>
                            <?php else : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <h6 class="mt-2 mb-3"><?php echo $this->lang->line('navigation_42');?></h6>
                                    <table class="table table-hover">
                                        <thead class="thead-light">
                                            <tr>
                                                <th scope="col"></th>
                                                <th scope="col"><?php echo $this->lang->line('navigation_9');?></th>
                                                <th scope="col"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($result as $data) : ?>
                                            <tr>
                                                <td width="5%">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" id="<?php echo $data->id; ?>" name="id" class="custom-control-input" value="<?php echo $data->id; ?>" <?php if (!empty($item->path)) : ?><?php if ($this->template->get_id_for_menu_item($item->path) == $data->id) : ?>checked<?php endif; ?><?php endif; ?>>
                                                        <label class="custom-control-label" for="<?php echo $data->id; ?>"></label>
                                                    </div>
                                                </td>
                                                <td><?php echo $data->name; ?></td>
                                                <td class="text-right"><a href="<?php echo base_url('my/apps/'.$app->id.'/galleries/upload/'.$data->id.'');?>" target="_blank" class="btn btn-light btn-sm"><span class="ti-eye mr-2"></span><?php echo $this->lang->line('navigation_38');?></a></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php if (!empty($links)) : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $links ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php elseif ($item->type == 5) : ?>
                            <?php if (empty($result)) : ?>
                             <div class="row">
                                <div class="col-md-12">
                                    <h6 class="mt-2 text-danger"><?php echo $this->lang->line('navigation_43');?></h6>
                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/forms');?>"><?php echo $this->lang->line('navigation_36');?>!</a>
                                </div>
                            </div>
                            <?php else : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <h6 class="mt-2 mb-3"><?php echo $this->lang->line('navigation_44');?></h6>
                                    <table class="table table-hover">
                                        <thead class="thead-light">
                                            <tr>
                                                <th scope="col"></th>
                                                <th scope="col"><?php echo $this->lang->line('navigation_9');?></th>
                                                <th scope="col"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($result as $data) : ?>
                                            <tr>
                                                <td width="5%">
                                                    <div class="custom-control custom-radio">
                                                        <input type="radio" id="<?php echo $data->id; ?>" name="id" class="custom-control-input" value="<?php echo $data->id; ?>" <?php if (!empty($item->path)) : ?><?php if ($this->template->get_id_for_menu_item($item->path) == $data->id) : ?>checked<?php endif; ?><?php endif; ?>>
                                                        <label class="custom-control-label" for="<?php echo $data->id; ?>"></label>
                                                    </div>
                                                </td>
                                                <td><?php echo $data->name; ?></td>
                                                <td class="text-right"><a href="<?php echo base_url('my/apps/'.$app->id.'/galleries/upload/'.$data->id.'');?>" target="_blank" class="btn btn-light btn-sm"><span class="ti-eye mr-2"></span><?php echo $this->lang->line('navigation_38');?></a></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="nav-settings" role="tabpanel" aria-labelledby="nav-settings-tab">
                    <div class="form-group row">
                        <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo $this->lang->line('navigation_45');?></label>
                        <div class="col-sm-10">
                            <select class="form-control form-control-sm" name="rights">
                                <option value="0" <?php if (!$item->rights) : ?>selected<?php endif; ?>><?php echo $this->lang->line('navigation_46');?></option>
                                <option value="1" <?php if ($item->rights == 1) : ?>selected<?php endif; ?>><?php echo $this->lang->line('navigation_47');?></option>
                                <option value="2" <?php if ($item->rights == 2) : ?>selected<?php endif; ?>><?php echo $this->lang->line('navigation_48');?></option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword" class="col-sm-2 col-form-label"><?php echo $this->lang->line('navigation_49');?></label>
                        <div class="col-sm-10">
                            <select class="form-control form-control-sm" name="group">
                                <option value="0" <?php if (!$item->user_group) : ?>selected<?php endif; ?>><?php echo $this->lang->line('navigation_50');?></option>
                                <?php if ($groups_list) : ?>
                                <?php foreach ($groups_list as $data_group) : ?>
                                <option value="<?php echo $data_group->id; ?>" <?php if ($item->user_group == $data_group->id) : ?>selected<?php endif; ?>><?php echo $data_group->name; ?></option>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('navigation_51');?></button>
        </div>
    </div>
    <?php echo form_close(); ?> 
</div>