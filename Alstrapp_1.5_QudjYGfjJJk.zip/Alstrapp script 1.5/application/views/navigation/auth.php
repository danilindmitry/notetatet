<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('navigation_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/navigation');?>"><span class="ti-view-list-alt mr-2"></span><?php echo $this->lang->line('navigation_2');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/navigation/auth');?>"><span class="ti-location-arrow mr-2"></span><?php echo $this->lang->line('navigation_3');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/navigation/user');?>"><span class="ti-user mr-2"></span><?php echo $this->lang->line('navigation_4');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row mb-head">
        <div class="col-md-9">
            <h5><?php echo $this->lang->line('navigation_2');?></h5>
        </div>
        <div class="col-md-3 text-right">
            <a href="#" data-toggle="modal" data-target="#add_item" class="btn btn-success btn-sm"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('navigation_5');?></a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php if (empty($main_items)) : ?>
            <div class="row justify-content-center align-items-center mt-5">
                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                    <div class="text-center">
                        <h1 class="text-primary"><span class="ti-view-list-alt"></span></h1>
                        <h5><?php echo $this->lang->line('navigation_6');?></h5>
                        <p class="text-muted"><?php echo $this->lang->line('navigation_7');?></p>
                        <a href="#" data-toggle="modal" data-target="#add_item" class="btn btn-primary btn-sm"><?php echo $this->lang->line('navigation_8');?></a>
                    </div>
                </div>
            </div>
            <?php else : ?>
            <table class="table table-hover">
                <thead class="thead-light">
                    <tr>
                        <th scope="col"></th>
                        <th scope="col"><?php echo $this->lang->line('navigation_9');?></th>
                        <th scope="col"><?php echo $this->lang->line('navigation_10');?></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody id="menu_sort">
                    <?php foreach ($main_items as $data) : ?>
                        <tr id="item-<?php echo $data->id; ?>">
                            <td class="move" width="5%"><span class="ti-move"></span></td>
                            <td><?php echo $data->name; ?></td>
                            <td><?php echo $this->template->get_link_for_menu_item($data->id); ?></td>
                            <td class="text-right">
                                <a href="<?php echo base_url('my/apps/'.$app->id.'/navigation/build/'.$data->id.'');?>" class="btn btn-primary btn-sm mr-3"><span class="ti-wand mr-2"></span><?php echo $this->lang->line('navigation_11');?></a>
                                <a href="#" data-toggle="modal" data-target="#del_item<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('navigation_12');?></a>
                            </td>
                        </tr>
                        <!-- Delete item -->
                        <div class="modal" id="del_item<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content border-none">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-10">
                                                    <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                </div>
                                                <div class="col-md-2 text-right">
                                                    <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                </div>
                                            </div>
                                            <h5 class="mb-4"><?php echo $this->lang->line('navigation_13');?> "<?php echo $data->name; ?>"</h5>
                                            <p><?php echo $this->lang->line('navigation_14');?></p>
                                            <div class="text-right">
                                                <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('navigation_15');?></button>
                                                <a href="<?php echo base_url('my/apps/'.$app->id.'/navigation/delete_item/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('navigation_16');?>!</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Add menu item -->
<div class="modal fade" id="add_item" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo $this->lang->line('navigation_17');?></h5>
                <button type="button" class="close btn-sm" data-dismiss="modal" aria-label="Close">
                    <span class="ti-close"></span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open(site_url('my/apps/'.$app->id.'/navigation/create_item')) ?>
                <input type="hidden" name="view" value="2">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('navigation_18');?></label>
                            <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('navigation_19');?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('navigation_20');?></label>
                            <select class="form-control form-control-sm" name="type">
                                <option value="1"><?php echo $this->lang->line('navigation_21');?></option>
                                <option value="2"><?php echo $this->lang->line('navigation_22');?></option>
                                <option value="3"><?php echo $this->lang->line('navigation_23');?></option>
                                <option value="4"><?php echo $this->lang->line('navigation_24');?></option>
                                <option value="5"><?php echo $this->lang->line('navigation_25');?></option>
                                <option value="6"><?php echo $this->lang->line('navigation_26');?></option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('navigation_27');?></label>
                            <select class="form-control form-control-sm" name="icon_library">
                                <option value="1">Material</option>
                                <option value="2">Framework7</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label><?php echo $this->lang->line('navigation_28');?></label>
                            <input type="text" class="form-control form-control-sm" name="icon" placeholder="home">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="alert alert-info" role="alert">
                            <?php echo $this->lang->line('navigation_29');?> <a class="alert-link" href="https://framework7.io/icons/" target="_blank">framework7.io</a> <?php echo $this->lang->line('navigation_30');?> <a class="alert-link" href="https://material.io/tools/icons/" target="_blank">material.io</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('navigation_31');?></button>
            </div>
            <?php echo form_close(); ?> 
        </div>
    </div>
</div>