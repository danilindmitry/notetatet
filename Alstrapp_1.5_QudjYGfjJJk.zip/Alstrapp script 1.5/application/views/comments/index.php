<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('comments_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-all-tab" data-toggle="tab" href="#nav-all" role="tab" aria-controls="nav-all" aria-selected="true"><span class="ti-comment-alt mr-2"></span><?php echo $this->lang->line('comments_2');?></a>
                            <a class="nav-item nav-link" id="nav-search-tab" data-toggle="tab" href="#nav-search" role="tab" aria-controls="nav-search" aria-selected="false"><span class="ti-search mr-2"></span><?php echo $this->lang->line('comments_3');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane show active" id="nav-all" role="tabpanel" aria-labelledby="nav-home-all">
                    <div class="row mb-head">
                        <div class="col-md-9">
                            <?php if (!isset($_GET['search'])) : ?>
                                <?php if (!isset($_GET['status'])) : ?>
                                <h5><?php echo $this->lang->line('comments_2');?> - <?php echo $total_records; ?></h5>
                                <?php else : ?>
                                    <?php if ($_GET['status'] == 1) : ?>
                                    <h5><?php echo $this->lang->line('comments_4');?> - <?php echo $total_records; ?></h5>
                                    <?php else : ?>
                                    <h5><?php echo $this->lang->line('comments_5');?> - <?php echo $total_records; ?></h5>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php else : ?>
                            <h5 class="mb-0"><?php echo $this->lang->line('comments_6');?> - <?php echo $total_records; ?></h5>
                            <small class="text-muted"><?php echo $this->lang->line('comments_7');?> "<?php echo $_GET['search'] ?>"</small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-3 text-right">
                            <?php echo form_open(site_url('my/apps/'.$app->id.'/comments/?'), array('method'=>'get')) ?>
                            <select class="form-control form-control-sm" name="status" onchange="this.form.submit()">
                                <option><?php echo $this->lang->line('comments_8');?></option>
                                <option value="1"><?php echo $this->lang->line('comments_9');?></option>
                                <option value="2"><?php echo $this->lang->line('comments_10');?></option>
                            </select>
                            <?php echo form_close(); ?> 
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php if ($total_records) : ?>
                            <table class="table table-hover">
                                <thead class="thead-light">
                                    <tr>
                                        <th class="text-center" scope="col"><?php echo $this->lang->line('comments_11');?></th>
                                        <th scope="col"><?php echo $this->lang->line('comments_12');?></th>
                                        <th scope="col"><?php echo $this->lang->line('comments_13');?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($comments as $data) : ?>
                                        <tr <?php if ($data->status == 2) : ?>class="table-warning"<?php endif; ?>>
                                            <td class="text-center" width="5%">
                                                <a href="<?php echo base_url('my/apps/'.$app->id.'/users/edit_user/'.$data->user.'');?>" target="_blank">
                                                    <img class="avatar" src="<?php echo $this->template->get_user_avatar($data->user); ?>" data-toggle="tooltip" data-placement="right" title="<?php echo $this->template->get_user_fullname($data->user); ?>">
                                                </a>
                                            </td>
                                            <td>
                                                <small><a href="<?php echo base_url('my/apps/'.$app->id.'/posts/edit_post/'.$data->post_id.'');?>" target="_blank"><?php echo $this->template->get_name_post($data->post_id); ?></a></small><br>
                                                <?php echo $data->comment; ?><br>

                                                <small><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/view/'.$data->post_id.'');?>" class="text-muted mr-2"><span class="ti-eye mr-1"></span><?php echo $this->lang->line('comments_14');?></a><?php if ($data->status == 1) : ?><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/unpublish/'.$data->id.'');?>" class="text-muted mr-2"><span class="ti-lock mr-1"></span><?php echo $this->lang->line('comments_15');?></a><?php else : ?><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/publish/'.$data->id.'');?>" class="text-success mr-2"><span class="ti-lock mr-1"></span><?php echo $this->lang->line('comments_16');?></a><?php endif; ?><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/delete_comment/'.$data->id.'');?>" class="text-danger mr-2"><span class="ti-trash mr-1"></span><?php echo $this->lang->line('comments_17');?></a></small>
                                            </td>
                                            <td width="20%"><span class="ti-calendar mr-2"></span><?php echo $data->created; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php if (!empty($links)) : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $links ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!isset($_GET['search'])) : ?>
                            <div class="row justify-content-center align-items-center mt-5">
                                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                                    <div class="text-center">
                                        <h1 class="text-primary"><span class="ti-comment-alt"></span></h1>
                                        <h5><?php echo $this->lang->line('comments_18');?></h5>
                                        <p class="text-muted"><?php echo $this->lang->line('comments_19');?></p>
                                    </div>
                                </div>
                            </div>
                            <?php else : ?>
                            <div class="row justify-content-center align-items-center mt-5">
                                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                                    <div class="text-center">
                                        <h1 class="text-danger"><span class="ti-face-sad"></span></h1>
                                        <h5><?php echo $this->lang->line('comments_20');?></h5>
                                        <p class="text-muted"><?php echo $this->lang->line('comments_21');?></p>
                                        <a href="<?php echo base_url('my/apps/'.$app->id.'/comments');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('comments_22');?></a>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="nav-search" role="tabpanel" aria-labelledby="nav-search-tab">
                    <?php echo form_open(site_url('my/apps/'.$app->id.'/comments/?'), array('method'=>'get')) ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-search"></span></h1>
                                <h5><?php echo $this->lang->line('comments_3');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('comments_23');?></p>
                            </div>
                            <input type="text" name="search" class="form-control" <?php if (isset($_GET['search'])) : ?>value="<?php echo $_GET['search'] ?>" <?php endif; ?>placeholder="<?php echo $this->lang->line('comments_24');?>?">
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>