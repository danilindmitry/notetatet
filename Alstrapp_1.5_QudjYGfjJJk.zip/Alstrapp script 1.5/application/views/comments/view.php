<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $this->lang->line('comments_1');?> - <?php echo $post->name; ?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <?php if ($comments) : ?>
            <?php foreach ($comments as $data) : ?>
            <div class="row mb-3">
                <div class="col-md-1">
                    <a href="<?php echo base_url('my/apps/'.$app->id.'/users/edit_user/'.$data->user.'');?>" target="_blank">
                        <img class="avatar mt-2" src="<?php echo $this->template->get_user_avatar($data->user); ?>" data-toggle="tooltip" data-placement="right" title="<?php echo $this->template->get_user_fullname($data->user); ?>">
                    </a>
                </div>
                <div class="col-md-11">
                    <div class="card">
                        <div class="card-body comment">
                            <small class="text-muted"><span class="ti-calendar mr-2"></span><?php echo $data->created; ?></small>
                            <p class="mb-1"><?php echo $data->comment; ?></p>
                            <div class="text-right">
                                <small class="mr-2"><a data-toggle="collapse" href="#collapse<?php echo $data->id; ?>" role="button" aria-expanded="false" aria-controls="collapse<?php echo $data->id; ?>"><span class="ti-pencil mr-1"></span><?php echo $this->lang->line('comments_25');?></a></small><small class="mr-2"><?php if ($data->status == 1) : ?><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/unpublish/'.$data->id.'');?>" class="text-muted mr-2"><span class="ti-lock mr-1"></span><?php echo $this->lang->line('comments_15');?></a><?php else : ?><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/publish/'.$data->id.'');?>" class="text-success mr-2"><span class="ti-lock mr-1"></span><?php echo $this->lang->line('comments_16');?></a><?php endif; ?></small><small><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/delete_comment/'.$data->id.'');?>" class="text-danger"><span class="ti-trash mr-1"></span><?php echo $this->lang->line('comments_17');?></a></small>
                            </div>
                            <div class="collapse" id="collapse<?php echo $data->id; ?>">
                                <?php echo form_open(site_url('my/apps/'.$app->id.'/comments/create_comment/'.$data->post_id.'')) ?>
                                <input type="hidden" name="comment_id" value="<?php echo $data->id; ?>">
                                <div class="form-group">
                                    <label><?php echo $this->lang->line('comments_26');?></label>
                                    <textarea class="form-control form-control-sm" name="comment" rows="5"></textarea>
                                </div>
                                <div class="text-right">
                                    <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('comments_27');?></button>
                                </div>
                                <?php echo form_close(); ?> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php if ($this->template->get_replyes($app->id, $post->id, $data->id)) : ?>

                <?php foreach ($this->template->get_replyes($app->id, $post->id, $data->id) as $datas) : ?>
                <div class="row mb-3">
                    <div class="col-md-1">
                        
                    </div>
                    <div class="col-md-1">
                        <a href="<?php echo base_url('my/apps/'.$app->id.'/users/edit_user/'.$datas->user.'');?>" target="_blank">
                            <img class="avatar mt-2" src="<?php echo $this->template->get_user_avatar($datas->user); ?>" data-toggle="tooltip" data-placement="right" title="<?php echo $this->template->get_user_fullname($datas->user); ?>">
                        </a>
                    </div>
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-body comment">
                                <small class="text-muted"><span class="ti-calendar mr-2"></span><?php echo $datas->created; ?></small>
                                <p class="mb-1"><?php echo $datas->comment; ?></p>
                                <div class="text-right">
                                    <small class="mr-2"><?php if ($data->status == 1) : ?><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/unpublish/'.$data->id.'');?>" class="text-muted mr-2"><span class="ti-lock mr-1"></span><?php echo $this->lang->line('comments_15');?></a><?php else : ?><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/publish/'.$data->id.'');?>" class="text-success mr-2"><span class="ti-lock mr-1"></span><?php echo $this->lang->line('comments_16');?></a><?php endif; ?></small><small><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/delete_comment/'.$datas->id.'');?>" class="text-danger"><span class="ti-trash mr-1"></span><?php echo $this->lang->line('comments_17');?></a></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>

            <?php endif; ?>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>