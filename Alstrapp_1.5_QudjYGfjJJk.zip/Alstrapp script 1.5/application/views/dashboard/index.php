<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $this->lang->line('dash_1');?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
	<?php if (!$app->type) : ?>
	<div class="row">
		<div class="col-md-3">
			<div class="card card-widget">
			  	<div class="card-body">
			    	<h3 class="text-widget"><span class="ti-user mr-3"></span><?php echo $total_users; ?></h3>
			    	<h5><a href="<?php echo base_url('my/apps/'.$app->id.'/users');?>" class="text-white"><?php echo $this->lang->line('dash_2');?></a></h5>
			  	</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card card-widget">
			  	<div class="card-body">
			    	<h3 class="text-widget"><span class="ti-comment-alt mr-3"></span><?php echo $total_comments; ?></h3>
			    	<h5><a href="<?php echo base_url('my/apps/'.$app->id.'/comments');?>" class="text-white"><?php echo $this->lang->line('dash_3');?></a></h5>
			  	</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card card-widget">
			  	<div class="card-body">
			    	<h3 class="text-widget"><span class="ti-comments mr-3"></span><?php echo $total_messages; ?></h3>
			    	<h5><a href="<?php echo base_url('my/apps/'.$app->id.'/messages');?>" class="text-white"><?php echo $this->lang->line('dash_4');?></a></h5>
			  	</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card card-widget">
			  	<div class="card-body">
			    	<h3 class="text-widget"><span class="ti-check-box mr-3"></span><?php echo $total_forms; ?></h3>
			    	<h5><a href="<?php echo base_url('my/apps/'.$app->id.'/forms');?>" class="text-white"><?php echo $this->lang->line('dash_5');?></a></h5>
			  	</div>
			</div>
		</div>
	</div>
	<?php endif; ?>

	<?php if ($app->type && $app->status == 1) : ?>
	<div class="alert alert-secondary mb-4" role="alert">
	  	<div class="row">
	  		<div class="col-md-12">
	  			<h6><?php echo $this->lang->line('dash_12');?></h6>
	  			<p><?php echo $this->lang->line('dash_13');?></p>
	  			<a href="<?php echo base_url('my/apps/'.$app->id.'/builder');?>" class="btn btn-success btn-sm"><?php echo $this->lang->line('dash_14');?></a>
	  		</div>
	  	</div>
	</div>
	<?php endif; ?>

	<div class="row mt-4">
		<div class="col-md-12">
			<h5 class="mb-0"><span class="ti-bar-chart-alt h6 mr-2"></span><?php echo $this->lang->line('dash_6');?> <?php echo $month; ?>, <?php echo $year;?></h5>
			<small><a href="<?php echo base_url('my/apps/'.$app->id.'/statistics');?>"><?php echo $this->lang->line('dash_7');?></a></small>
		</div>
		<div class="col-md-12 mt-2">
			<canvas id="statistics" height="100"></canvas>
		</div>
	</div>

	<?php if (!$app->type) : ?>
	<div class="row mt-4">
		<div class="col-md-12">
			<h5 class="mb-0"><span class="ti-comment-alt h6 mr-2"></span><?php echo $this->lang->line('dash_8');?></h5>
			<small><a href="<?php echo base_url('my/apps/'.$app->id.'/comments');?>"><?php echo $this->lang->line('dash_9');?></a></small>
			<div class="card mt-3">
			  	<div class="card-body p-0">
			    	<?php if (!empty($last_comments)) : ?>
			  			<?php if ($last_comments) : ?>
			  			<table class="table table-hover">
			  				<tbody>
			  					<?php foreach ($last_comments as $datas) : ?>
			  					<tr>
			  						<td class="text-center" width="5%">
                                        <a href="<?php echo base_url('my/apps/'.$app->id.'/users/edit_user/'.$datas->user.'');?>" target="_blank">
                                            <img class="avatar" src="<?php echo $this->template->get_user_avatar($datas->user); ?>" data-toggle="tooltip" data-placement="right" title="<?php echo $this->template->get_user_fullname($datas->user); ?>">
                                        </a>
                                    </td>
                                    <td>
                                    	<small><a href="<?php echo base_url('my/apps/'.$app->id.'/posts/edit_post/'.$datas->post_id.'');?>" target="_blank"><?php echo $this->template->get_name_post($datas->post_id); ?></a></small><br>
                                        <?php echo $datas->comment; ?><br>
                                        <small><a href="<?php echo base_url('my/apps/'.$app->id.'/comments/view/'.$datas->post_id.'');?>" class="text-muted mr-2"><span class="ti-eye mr-1"></span><?php echo $this->lang->line('dash_10');?></a></small>
                                    </td>
			  					</tr>
			  					<?php endforeach; ?>
			  				</tbody>
			  			</table>
			  			<?php endif; ?>
			  		<?php else : ?>
			    	<div class="row justify-content-center align-items-center mt-5 mb-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-secondary"><span class="ti-thumb-up"></span></h1>
                                <h5 class="text-secondary"><?php echo $this->lang->line('dash_11');?></h5>
                            </div>
                        </div>
                    </div>
			    	<?php endif; ?>
			  	</div>
			</div>
		</div>
	</div>
	<?php endif; ?>
</div>

<script>
    var ctx = document.getElementById("statistics").getContext('2d');
    var parners = new Chart(ctx, {
        type: 'line',
        	data: {
                labels: [<?php foreach ($dates as $data) : ?>
        			"<?php echo $data; ?>",
        		<?php endforeach; ?>
        		],
                datasets: [{
                    label: 'iOS',
                    data: [<?php foreach ($dates as $data) : ?>
            		<?php echo $this->template->get_total_statistics_for_day($app->id, 1, $data, $current_m, date("Y")); ?>,
            	   	<?php endforeach; ?>],
                    backgroundColor: 'rgba(243, 92, 92, 0.13)',
                    borderColor: '#f35c5c',
                    pointBackgroundColor: '#fff',
                    pointBorderColor: '#f35c5c',
                    pointRadius: 5,
                    pointBorderWidth: 1,
                    borderWidth: 3
                },{
		        	label: 'Android',
		        	data: [<?php foreach ($dates as $data) : ?>
            		<?php echo $this->template->get_total_statistics_for_day($app->id, 2, $data, $current_m, date("Y")); ?>,
            	   	<?php endforeach; ?>],
		            backgroundColor: 'rgba(104, 197, 125, 0.13)',
		            borderColor: '#68c57d',
		            pointBackgroundColor: '#fff',
		            pointBorderColor: '#68c57d',
		            pointRadius: 5,
		            pointBorderWidth: 1,
		            borderWidth: 3
		        }]
            },
            options: {
                responsive: true,
                tooltips: {
                    mode: 'index',
                    intersect: false,
                },

                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true
                        }
                    }]
                }
            }
    });
</script>