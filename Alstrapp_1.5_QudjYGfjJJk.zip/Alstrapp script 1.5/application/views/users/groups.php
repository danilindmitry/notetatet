<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('users_25');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-all-tab" data-toggle="tab" href="#nav-all" role="tab" aria-controls="nav-all" aria-selected="true"><span class="ti-harddrives mr-2"></span><?php echo $this->lang->line('users_2');?></a>
                            <a class="nav-item nav-link" id="nav-add-tab" data-toggle="tab" href="#nav-add" role="tab" aria-controls="nav-add" aria-selected="false"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('users_3');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane show active" id="nav-all" role="tabpanel" aria-labelledby="nav-home-all">
                    <div class="row">
                        <div class="col-md-12">
                            <?php if ($total_records) : ?>
                            <table class="table table-hover">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col"><?php echo $this->lang->line('users_26');?></th>
                                        <th scope="col"><?php echo $this->lang->line('users_27');?></th>
                                        <th class="text-center" scope="col"><?php echo $this->lang->line('users_28');?></th>
                                        <th scope="col"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($groups as $data) : ?>
                                    <tr>
                                        <td>
                                            <a href="#" data-toggle="modal" data-target="#edit_group<?php echo $data->id; ?>" class="text-warning mr-2"><span class="ti-pencil mr-1"></span></a><?php echo $data->name; ?>
                                        </td>
                                        <td><span class="ti-calendar mr-2"></span><?php echo $data->created; ?></td>
                                        <td class="text-center"><a href="<?php echo base_url('my/apps/'.$app->id.'/users/?group='.$data->id.'');?>" target="_blank"><?php echo $this->template->get_count_user_for_group($data->id); ?></a></td>
                                        <td class="text-right">
                                            <a href="#" data-toggle="modal" data-target="#del_group<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('users_29');?></a>
                                        </td>
                                    </tr>
                                    <!-- Delete group -->
                                    <div class="modal" id="del_group<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content border-none">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="row">
                                                            <div class="col-md-10">
                                                                <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                            </div>
                                                            <div class="col-md-2 text-right">
                                                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                            </div>
                                                        </div>
                                                        <h5 class="mb-4"><?php echo $this->lang->line('users_30');?> "<?php echo $data->name; ?>"</h5>
                                                        <p><?php echo $this->lang->line('users_31');?></p>
                                                        <div class="text-right">
                                                            <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('users_32');?></button>
                                                            <a href="<?php echo base_url('my/users/delete_group/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('users_33');?>!</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Edit group -->
                                    <div class="modal" id="edit_group<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content border-none">
                                                <?php echo form_open(site_url('my/users/update_group/'.$data->id.'')) ?>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="row">
                                                            <div class="col-md-10">
                                                                <h1 class="text-warning"><span class="ti-pencil-alt"></span></h1>
                                                            </div>
                                                            <div class="col-md-2 text-right">
                                                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                            </div>
                                                        </div>
                                                        <h5 class="mb-4"><?php echo $this->lang->line('users_34');?> "<?php echo $data->name; ?>"</h5>
                                                        <div class="form-group">
                                                            <label><?php echo $this->lang->line('users_35');?></label>
                                                            <input type="text" class="form-control" name="name" value="<?php echo $data->name; ?>" placeholder="<?php echo $this->lang->line('users_5');?>">
                                                        </div>
                                                        <div class="text-right">
                                                            <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('users_36');?></button>
                                                            <button type="submit" class="btn btn-primary"><?php echo $this->lang->line('users_37');?>!</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php echo form_close(); ?> 
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php if (!empty($links)) : ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <?php echo $links ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php else : ?>
                            <div class="row justify-content-center align-items-center mt-5">
                                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                                    <div class="text-center">
                                        <h1 class="text-primary"><span class="ti-harddrive"></span></h1>
                                        <h5><?php echo $this->lang->line('users_38');?></h5>
                                        <p class="text-muted"><?php echo $this->lang->line('users_39');?></p>
                                        <a href="#" onclick="$('#nav-add-tab').trigger('click')" class="btn btn-primary btn-sm"><?php echo $this->lang->line('users_40');?></a>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="nav-add" role="tabpanel" aria-labelledby="nav-add-tab">
                    <?php echo form_open(site_url('my/users/create_group/'.$app->id.'')) ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label><?php echo $this->lang->line('users_4');?></label>
                                <input type="text" class="form-control form-control-sm" name="name" placeholder="Default">
                                <small class="form-text text-muted"><?php echo $this->lang->line('users_6');?></small>
                            </div>
                        </div>
                        <div class="col-md-12 text-right">
                            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('users_7');?></button>
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
