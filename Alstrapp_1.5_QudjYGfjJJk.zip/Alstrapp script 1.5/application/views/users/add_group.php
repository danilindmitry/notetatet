<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('users_1');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/users/groups');?>"><span class="ti-harddrives mr-2"></span><?php echo $this->lang->line('users_2');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/users/add_group');?>"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('users_3');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <?php echo form_open(site_url('my/users/create_group/'.$app->id.'')) ?>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label><?php echo $this->lang->line('users_4');?></label>
                <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('users_5');?>">
                <small class="form-text text-muted"><?php echo $this->lang->line('users_6');?></small>
            </div>
        </div>
        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('users_7');?></button>
        </div>
    </div>
    <?php echo form_close(); ?> 
</div>