<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $this->lang->line('users_8');?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <?php echo form_open(site_url('my/users/create_user/'.$app->id.'')) ?>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label><?php echo $this->lang->line('users_9');?></label>
                <input type="text" class="form-control form-control-sm" name="username" placeholder="alstrapp">
                <small class="form-text text-muted"><?php echo $this->lang->line('users_10');?></small>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('users_11');?></label>
                <input type="email" class="form-control form-control-sm" name="email" placeholder="mail@example.com">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('users_12');?></label>
                <select class="form-control form-control-sm" name="group">
                    <option value="0"><?php echo $this->lang->line('users_13');?></option>
                    <?php if ($groups_list) : ?>
                        <?php foreach ($groups_list as $data_group) : ?>
                        <option value="<?php echo $data_group->id; ?>"><?php echo $data_group->name; ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('users_14');?></label>
                <input type="text" class="form-control form-control-sm" name="first_name" placeholder="John">
                <small class="form-text text-muted"><?php echo $this->lang->line('users_10');?></small>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('users_15');?></label>
                <input type="text" class="form-control form-control-sm" name="last_name" placeholder="Doe">
                <small class="form-text text-muted"><?php echo $this->lang->line('users_16');?></small>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('users_17');?></label>
                <input type="password" class="form-control form-control-sm" name="password" placeholder="**********">
                <small class="form-text text-muted"><?php echo $this->lang->line('users_18');?></small>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('users_19');?></label>
                <input type="password" class="form-control form-control-sm" name="repassword" placeholder="**********">
            </div>
        </div>
        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('users_7');?></button>
        </div>
    </div>
    <?php echo form_close(); ?> 
</div>