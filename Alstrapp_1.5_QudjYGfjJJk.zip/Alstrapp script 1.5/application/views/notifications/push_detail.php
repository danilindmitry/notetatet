<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $this->lang->line('notify_45');?> <?php echo $response['id']; ?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
	<div class="row">
		<?php if (!empty($response['platform_delivery_stats']['android'])) : ?>
		<div class="col-md-12">
			<div class="row mb-head">
                <div class="col-md-12">
                    <h5 class="mb-0"><?php echo $this->lang->line('notify_46');?>: <?php echo $response['converted']; ?></h5>
                </div>
            </div>
			<div class="card">
			  	<div class="card-body">
			  		<div class="row">
			  			<div class="col-md-1">
				    		<span class="ti-android text-success h1"></span>
				    	</div>
				    	<div class="col-md-11">
				    		<div class="row">
				    			<div class="col-md-4 text-center">
				    				<h5 class="mb-0 text-success"><?php echo $response['platform_delivery_stats']['android']['successful']; ?></h5>
				    				<p class="mb-0"><?php echo $this->lang->line('notify_47');?></p>
					    		</div>
					    		<div class="col-md-4 text-center">
					    			<h5 class="mb-0 text-danger"><?php echo $response['platform_delivery_stats']['android']['failed']; ?></h5>
				    				<p class="mb-0"><?php echo $this->lang->line('notify_48');?></p>
					    		</div>
					    		<div class="col-md-4 text-center">
					    			<h5 class="mb-0 text-danger"><?php echo $response['platform_delivery_stats']['android']['errored']; ?></h5>
				    				<p class="mb-0"><?php echo $this->lang->line('notify_49');?></p>
					    		</div>
				    		</div>
				    	</div>
			  		</div>
			  	</div>
			</div>
		</div>
		<?php endif; ?>
		<?php if (!empty($response['platform_delivery_stats']['ios'])) : ?>
		<div class="col-md-12 mt-3">
			<div class="card">
			  	<div class="card-body">
			  		<div class="row">
			  			<div class="col-md-1">
				    		<span class="ti-apple text-secondary h1"></span>
				    	</div>
				    	<div class="col-md-11">
				    		<div class="row">
				    			<div class="col-md-4 text-center">
				    				<h5 class="mb-0 text-success"><?php echo $response['platform_delivery_stats']['ios']['successful']; ?></h5>
				    				<p class="mb-0"><?php echo $this->lang->line('notify_47');?></p>
					    		</div>
					    		<div class="col-md-4 text-center">
					    			<h5 class="mb-0 text-danger"><?php echo $response['platform_delivery_stats']['ios']['failed']; ?></h5>
				    				<p class="mb-0"><?php echo $this->lang->line('notify_48');?></p>
					    		</div>
					    		<div class="col-md-4 text-center">
					    			<h5 class="mb-0 text-danger"><?php echo $response['platform_delivery_stats']['ios']['errored']; ?></h5>
				    				<p class="mb-0"><?php echo $this->lang->line('notify_49');?></p>
					    		</div>
				    		</div>
				    	</div>
			  		</div>
			  	</div>
			</div>
		</div>
		<?php endif; ?>
	</div>
	<div class="row">
		<div class="col-md-12 mt-3">
			<div class="row mb-head">
                <div class="col-md-12">
                    <h5 class="mb-0"><?php echo $this->lang->line('notify_50');?></h5>
                </div>
            </div>
			<table class="table table-bordered">
				<tbody>
					<tr>
						<td width="30%"><strong><?php echo $this->lang->line('notify_42');?>:</strong></td>
						<td><?php echo $response['headings']['en']; ?></td>
					</tr>
					<tr>
						<td width="30%"><strong><?php echo $this->lang->line('notify_51');?>:</strong></td>
						<td><?php echo $response['contents']['en']; ?></td>
					</tr>
					<?php if (!empty($response['big_picture'])) : ?>
					<tr>
						<td width="30%"><strong><?php echo $this->lang->line('notify_20');?>:</strong></td>
						<td><img src="<?php echo $response['big_picture']; ?>" class="w-100"></td>
					</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>