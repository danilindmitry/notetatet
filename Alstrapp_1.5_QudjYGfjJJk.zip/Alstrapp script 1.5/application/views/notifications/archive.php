<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('notify_23');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/notifications/');?>"><span class="ti-signal mr-2"></span><?php echo $this->lang->line('notify_24');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/'.$app->id.'/notifications/planned');?>"><span class="ti-timer mr-2"></span><?php echo $this->lang->line('notify_25');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/'.$app->id.'/notifications/archive');?>"><span class="ti-archive mr-2"></span><?php echo $this->lang->line('notify_26');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <div class="row mb-head">
                 <div class="col-md-9">
                     <h5 class="mb-0"><?php echo $this->lang->line('notify_27');?> - <?php echo $total_records; ?></h5>
                 </div>
                 <div class="col-md-3 text-right">
                    <a href="<?php echo base_url('my/apps/'.$app->id.'/notifications/add_notice');?>" class="btn btn-success btn-sm"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('notify_28');?></a>
                 </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <?php if ($total_records) : ?>
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo $this->lang->line('notify_2');?></th>
                                <th scope="col"><?php echo $this->lang->line('notify_5');?></th>
                                <th scope="col"><?php echo $this->lang->line('notify_6');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($notifications as $data) : ?>
                            <tr>
                                <td><a href="<?php echo base_url('my/apps/'.$app->id.'/notifications/edit_notice/'.$data->id.'');?>" class="text-warning mr-2"><span class="ti-pencil mr-1"></span></a><?php echo $data->name; ?></td>
                                <td><span class="ti-calendar mr-2"></span><?php echo $data->start_date; ?></td>
                                <td class="text-danger"><span class="ti-calendar mr-2"></span><?php echo $data->end_date; ?></td>
                                <td class="text-right">
                                    <a href="#" data-toggle="modal" data-target="#del_notice<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('notify_29');?></a>
                                </td>
                            </tr>
                            <!-- Delete user -->
                            <div class="modal" id="del_notice<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content border-none">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="col-md-10">
                                                        <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                                    </div>
                                                    <div class="col-md-2 text-right">
                                                        <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                                    </div>
                                                </div>
                                                <h5 class="mb-4"><?php echo $this->lang->line('notify_30');?> "<?php echo $data->name; ?>"?</h5>
                                                <p><?php echo $this->lang->line('notify_31');?></p>
                                                <div class="text-right">
                                                    <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('notify_32');?></button>
                                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/notifications/delete_notice/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('notify_33');?>!</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if (!empty($links)) : ?>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $links ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php else : ?>
                    <div class="row justify-content-center align-items-center mt-5">
                        <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                            <div class="text-center">
                                <h1 class="text-primary"><span class="ti-timer"></span></h1>
                                <h5><?php echo $this->lang->line('notify_34');?></h5>
                                <p class="text-muted"><?php echo $this->lang->line('notify_35');?></p>
                                <a href="<?php echo base_url('my/apps/'.$app->id.'/notifications/add_notice');?>" class="btn btn-primary btn-sm"><?php echo $this->lang->line('notify_28');?></a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>