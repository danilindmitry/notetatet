<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $this->lang->line('notify_16');?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <?php echo form_open_multipart(site_url('my/apps/'.$app->id.'/notifications/send_push')) ?>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('notify_17');?></label>
                        <input type="text" class="form-control form-control-sm" name="title">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('notify_7');?></label>
                        <textarea class="form-control form-control-sm" rows="4" name="message"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('notify_18');?> <span class="ti-info-alt ml-1 text-primary" data-toggle="tooltip" data-placement="top" title="<?php echo $this->lang->line('notify_19');?>"></span></label>
                        <input type="text" class="form-control form-control-sm" name="android_led_color">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><?php echo $this->lang->line('notify_20');?> <span class="ti-info-alt ml-1 text-primary" data-toggle="tooltip" data-placement="top" title="<?php echo $this->lang->line('notify_21');?>."></span></label>
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" name="android_big_picture" onchange="$('#upload-file-info').html(this.files[0].name)">
                            <label class="custom-file-label" for="customFile"><span id="upload-file-info"></span></label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('notify_22');?></button>
        </div>
    </div>
    <?php echo form_close(); ?> 
</div>