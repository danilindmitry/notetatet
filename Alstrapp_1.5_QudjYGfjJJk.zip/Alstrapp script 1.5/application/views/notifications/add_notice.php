<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $this->lang->line('notify_1');?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
	<?php echo form_open(site_url('my/apps/'.$app->id.'/notifications/create_notice')) ?>
	<div class="row">
		<div class="col-md-12">
            <div class="form-group">
                <label><?php echo $this->lang->line('notify_2');?></label>
                <input type="text" class="form-control form-control-sm" name="name" placeholder="<?php echo $this->lang->line('notify_3');?>">
                <small class="form-text text-muted"><?php echo $this->lang->line('notify_4');?></small>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('notify_5');?></label>
                <input type="text" class="form-control form-control-sm datepicker-here" data-timepicker="true" data-position="bottom left" autocomplete="off" name="start_date">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('notify_6');?></label>
                <input type="text" class="form-control form-control-sm datepicker-here" data-timepicker="true" data-position="bottom left" autocomplete="off" name="end_date">
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                <label><?php echo $this->lang->line('notify_7');?></label>
                <textarea class="form-control form-control-sm" name="message" rows="5"></textarea>
                <small class="form-text text-muted"><?php echo $this->lang->line('notify_8');?></small>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('notify_9');?></label>
                <select class="form-control form-control-sm" name="group">
                    <option value="0"><?php echo $this->lang->line('notify_10');?></option>
                    <?php if ($groups_list) : ?>
                        <?php foreach ($groups_list as $data_group) : ?>
                        <option value="<?php echo $data_group->id; ?>"><?php echo $data_group->name; ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label><?php echo $this->lang->line('notify_11');?></label>
                <select class="form-control form-control-sm" name="rights">
                    <option value="0"><?php echo $this->lang->line('notify_12');?></option>
                    <option value="1"><?php echo $this->lang->line('notify_13');?></option>
                    <option value="2"><?php echo $this->lang->line('notify_14');?></option>
                </select>
            </div>
        </div>
        <div class="col-md-12 text-right">
            <button type="submit" class="btn btn-primary btn-sm"><?php echo $this->lang->line('notify_15');?></button>
        </div>
	</div>
	<?php echo form_close(); ?> 
</div>