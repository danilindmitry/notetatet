<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo $this->lang->line('notify_37');?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
    	<div class="col-md-12">
    		<div class="row mb-head">
                <div class="col-md-9">
                    <h5 class="mb-0"><?php echo $this->lang->line('notify_38');?> - <?php echo $total_records; ?></h5>
                    <small class="text-muted"><?php echo $this->lang->line('notify_39');?>: <span class="text-success"><?php echo $response['messageable_players']; ?></span> (total users <?php echo $response['players']; ?>)</small>
                </div>
                <div class="col-md-3 text-right">
                    <a href="<?php echo base_url('my/apps/'.$app->id.'/notifications/add_push');?>" class="btn btn-success btn-sm"><span class="ti-plus mr-2"></span><?php echo $this->lang->line('notify_40');?></a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                	<?php if ($total_records) : ?>
                	<table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                            	<th width="20%"><?php echo $this->lang->line('notify_41');?></th>
                                <th scope="col"><?php echo $this->lang->line('notify_42');?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        	<?php foreach ($notifications as $data) : ?>
                        	<tr>
                        		<td><span class="ti-timer mr-2"></span><?php echo gmdate("Y-m-d H:i:s", $data['queued_at']); ?></td>
                        		<td>
                        			<?php echo $data['headings']['en']; ?><br>
                        			<small class="text-muted">ID: <?php echo $data['id']; ?><br></small>
                        		</td>
                        		<td class="text-right">
                                    <a href="<?php echo base_url('my/apps/'.$app->id.'/notifications/push_detail/'.$data['id'].'');?>" class="btn btn-primary btn-sm"><span class="ti-eye mr-2"></span><?php echo $this->lang->line('notify_43');?></a>
                                </td>
                        	</tr>
                        	<?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php if (!empty($links)) : ?>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $links ?>
                        </div>
                    </div>
                    <?php endif; ?>
                	<?php else : ?>

                	<?php endif; ?>
                </div>
            </div>
    	</div>
    </div>
</div>