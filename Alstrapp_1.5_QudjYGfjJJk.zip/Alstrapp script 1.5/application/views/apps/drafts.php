<div class="row mb-2">
    <div class="col-md-12">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url('my/apps');?>"><span class="ti-layout-grid2 mr-1"></span><?php echo $this->lang->line('app_2');?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $this->lang->line('app_7');?></li>
         </ol>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="navigation-page">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo $this->lang->line('app_4');?></h4>
                </div>
                <div class="col-md-6">
                    <nav>
                        <div class="nav nav-tabs justify-content-end" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps');?>"><span class="ti-layout-grid2 mr-2"></span><?php echo $this->lang->line('app_5');?></a>
                            <a class="nav-item nav-link" href="<?php echo base_url('my/apps/?sort=2');?>"><span class="ti-mobile mr-2"></span><?php echo $this->lang->line('app_6');?></a>
                            <a class="nav-item nav-link active" href="<?php echo base_url('my/apps/?sort=1');?>"><span class="ti-ruler-pencil mr-2"></span><?php echo $this->lang->line('app_7');?></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main">
    <div class="row">
        <div class="col-md-12">
            <?php if ($total_records) : ?>
            <table class="table table-app">
                <tbody>
                    <?php foreach ($apps as $data) : ?>
                    <tr>
                        <td class="text-left" width="5%"><img src="<?php echo $this->template->get_icon_app($data->id); ?>" class="app-logo-draft"></td>
                        <td>
                            <?php echo $data->name; ?><br>
                            <small class="text-muted">ID: <?php echo $data->id; ?> | Created <?php echo $data->created; ?></small>
                        </td>
                        <td class="text-right">
                            <a href="<?php echo base_url('my/apps/'.$data->id.'/dashboard');?>" class="btn btn-primary btn-sm mr-3"><span class="ti-eye mr-2"></span><?php echo $this->lang->line('app_13');?></a>
                            <a href="#" data-toggle="modal" data-target="#del_app<?php echo $data->id; ?>" class="btn btn-light btn-sm"><span class="ti-trash mr-2"></span><?php echo $this->lang->line('app_14');?></a>
                        </td>
                    </tr>
                    <!-- Delete app -->
                    <div class="modal" id="del_app<?php echo $data->id; ?>" tabindex="-1" role="dialog" aria-labelledby="del_app" aria-hidden="true" data-backdrop="static">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content border-none">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-10">
                                                <h1 class="text-danger"><span class="ti-trash"></span></h1>
                                            </div>
                                            <div class="col-md-2 text-right">
                                                <a href="#" class="text-muted h4" data-dismiss="modal"><span class="ti-close"></span></a>
                                            </div>
                                        </div>
                                        <h5 class="mb-4"><?php echo $this->lang->line('app_15');?> "<?php echo $data->name; ?>"</h5>
                                        <p><?php echo $this->lang->line('app_16');?></p>
                                        <div class="text-right">
                                            <button type="button" class="btn btn-light mr-2" data-dismiss="modal"><?php echo $this->lang->line('app_17');?></button>
                                            <a href="<?php echo base_url('my/apps/delete_app/'.$data->id.'');?>" class="btn btn-danger"><?php echo $this->lang->line('app_18');?>!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if (!empty($links)) : ?>
            <div class="row">
                <div class="col-md-12">
                    <?php echo $links ?>
                </div>
            </div>
            <?php endif; ?>
            <?php else : ?>
            <div class="row justify-content-center align-items-center mt-5">
                <div class="col col-sm-12 col-md-6 col-lg-4 col-xl-6">
                    <div class="text-center">
                        <h1 class="text-primary"><span class="ti-package"></span></h1>
                        <h5><?php echo $this->lang->line('app_22');?></h5>
                        <p class="text-muted"><?php echo $this->lang->line('app_20');?></p>
                        <a href="#" data-toggle="modal" data-target="#add_app" class="btn btn-primary btn-sm"><?php echo $this->lang->line('app_21');?></a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>