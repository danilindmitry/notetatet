<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if (! function_exists('active_link'))
{
    function activate_menu($controller)
    {
        $CI = get_instance();

        $class = $CI->router->fetch_class();

        return ($class == $controller) ? 'active' : '';
    }

    function activate_treeview($controller)
    {
        $CI = get_instance();

        $class = $CI->router->fetch_class();
        
        return ($class == $controller) ? 'true' : '';
    }

    function activate_ul_menu($controller)
    {
        $CI = get_instance();

        $class = $CI->router->fetch_class();
        
        return ($class == $controller) ? 'collapse show' : '';
    }
}