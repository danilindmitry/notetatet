<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Builder extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('configuration_model');
    	$this->load->model('builder_model');

		// ** Load libraries ** //
		$this->load->library('pagination');
		$this->load->library('writer');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('builder', $user_lang);
    	$this->lang->load('layout', $user_lang);
    	$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * Index page
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$load_time = date("Y-m-d H:i:s", strtotime("-5 minutes"));

		$configuration = $this->configuration_model->get_configuration();

		// init params
        $params = array();
        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        $total_records = $this->builder_model->get_total_versions($app->id);

        // load config file
	    $this->config->load('pagination', TRUE);
	    $settings_pagination = $this->config->item('pagination');
	    $settings_pagination['total_rows'] = $this->builder_model->get_total_versions($app->id);
	    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/builder/index';

	    if ($total_records > 0)
		{
			// get current page records
			$params["versions"] = $this->builder_model->get_versions($settings_pagination['per_page'], $start_index, $app->id);
			             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
			             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

		$params["total_records"] = $total_records;
		$params["app"] = $app;
		$params["configuration"] = $configuration;
		$params["load_time"] = $load_time;

    	$this->template->set('title', $this->lang->line('seo_3'));
		$this->template->load('cms', 'contents' , 'builder/index', $params);
	}

	/*
	 * Local storage page
	 */
	public function storage()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$load_time = date("Y-m-d H:i:s", strtotime("-5 minutes"));

		$configuration = $this->configuration_model->get_configuration();

		// init params
        $params = array();
        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        $total_records = $this->builder_model->get_total_local_versions($app->id);

        // load config file
	    $this->config->load('pagination', TRUE);
	    $settings_pagination = $this->config->item('pagination');
	    $settings_pagination['total_rows'] = $this->builder_model->get_total_local_versions($app->id);
	    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/builder/index';

	    if ($total_records > 0)
		{
			// get current page records
			$params["versions"] = $this->builder_model->get_local_versions($settings_pagination['per_page'], $start_index, $app->id);
			             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
			             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

		$params["total_records"] = $total_records;
		$params["app"] = $app;
		$params["configuration"] = $configuration;
		$params["load_time"] = $load_time;

    	$this->template->set('title', $this->lang->line('seo_3'));
		$this->template->load('cms', 'contents' , 'builder/storage', $params);
	}

	/*
	 * Start build app
	 */
	public function start_build()
	{
		header('Access-Control-Allow-Origin: *');

		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('sign_android', "Android signature", 'trim|required|in_list[0,1]');
		$this->form_validation->set_rules('sign_ios', "iOS signature", 'trim|required|in_list[0,1]');
		$this->form_validation->set_rules('key_pw', "Android key password", 'trim');
		$this->form_validation->set_rules('keystore_pw', "Android keystore password", 'trim');
		$this->form_validation->set_rules('pass_ios', "iOS password", 'trim');

		if ($this->form_validation->run() == false) {

			$response = array ('event' => 'fail', 'message' => validation_errors());
			echo json_encode($response);

		} else {

			$date = date('Y-m-d H:i:s');

			// set variable for input data
	        $sign_android = $this->input->post("sign_android", true);
	        $sign_ios = $this->input->post("sign_ios", true);
	        $key_pw = $this->input->post("key_pw", true);
	        $keystore_pw = $this->input->post("keystore_pw", true);
	        $pass_ios = $this->input->post("pass_ios", true);

			$configuration = $this->configuration_model->get_configuration();

			if ($sign_android) {

				$key_android = $configuration->sign_android;

			} else {

				$key_android = 0;

			}

			if ($sign_ios) {

				$key_ios = $configuration->sign_ios;

			} else {

				$key_ios = 0;

			}

			$configapp = $this->writer->create_config_app($app->id);

			if ($configapp['event'] == 'success') {

				$indexjs = $this->writer->create_index_js($app->id);

				if ($indexjs['event'] == 'success') {

					// create zip file
					$link_zip = $this->writer->preparation_zip($app->id);

					if ($link_zip) {

						$info_app = array(
							"title"  		=> "Alstrapp",
							"create_method" => "file",
							"keys" 			=> array("android" => array("id" => $key_android, "key_pw" => $key_pw, "keystore_pw" => $keystore_pw), "ios" => array("id" => $key_ios, "password" => $pass_ios))
						);

		                if (!$info_app['keys']['android']['id']) {

		                    unset($info_app['keys']['android']);

		                }

		                if (!$info_app['keys']['ios']['id']) {

		                    unset($info_app['keys']['ios']);

		                }

		                if (!$info_app['keys']) {

		                    unset($info_app['keys']);

		                }

		                $data_app = json_encode($info_app);

						// upload files to Phonegap
						$data = array(
						    "file" => new CURLFile($link_zip),
						    "data" => $data_app
						);
						$handle = curl_init();
						curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/apps?access_token='.$configuration->access_token.'');
						curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "POST");
						curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($handle, CURLOPT_HTTPHEADER, array(
						  'Content-type: multipart/form-data;',
						));
						curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
						$final = curl_exec($handle);
						$response = json_decode($final, true);
						curl_close ($handle);

						if (empty($response["id"])) {

							$response = array ('event' => 'fail', 'message' => $response["error"]);
							echo json_encode($response);

						} else {

							// add app in versions
					        $this->builder_model->add_version(array(
						        "app_id"		=> $app->id,
						        "name"			=> $app->name,
						        "version"		=> $app->version,
						        "created"		=> $date,
						        "type"			=> 1,
						        "phonegap_id"	=> $response['id'],
						        "zip" 			=> $link_zip
						        )
						    );

						    if ($app->status == 1) {

						    	$this->apps_model->update_app($app->id, array(
					                "status"    =>  2
					                )
					            );

						    }

							$response = array ('event' => 'success');
							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => "Failed to create application zip archive. Check projects folder permissions");
						echo json_encode($response);

					}

 				} else {

 					$response = array ('event' => 'fail', 'message' => $configapp['message']);
					echo json_encode($response);

 				}

			} else {

				$response = array ('event' => 'fail', 'message' => $configapp['message']);
				echo json_encode($response);

			}

		}

	}

	/*
	 * Delete version
	 * @param int $version_id
	 */
	public function delete_version($version_id)
	{

		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($version_id) OR ! is_numeric($version_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_5'));
            redirect(site_url('my/apps/'.$app->id.'/builder'));

	    }

	    $configuration = $this->configuration_model->get_configuration();

	    $version = $this->builder_model->get_version($version_id);

	    if ($version) {

	    	// del request
			$handle = curl_init();
			curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/apps/'.$version->phonegap_id.'/?access_token='.$configuration->access_token.'');
			curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "DELETE");
			curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
			$response = curl_exec($handle);
			$httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
			$response = json_decode($response, true);
			curl_close ($handle);

			if ($httpCode == 202) {

				// del in database
				$this->builder_model->del_app($version->id);

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/apps/'.$app->id.'/builder'));

			} else {

				$this->session->set_flashdata('error', $this->lang->line('alert_6'));
            	redirect(site_url('my/apps/'.$app->id.'/builder'));

			}

	    }

	}

	/*
	 * Download android app
	 * @param int $phonegap_id
	 */
	public function download_android($phonegap_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$configuration = $this->configuration_model->get_configuration();

		if ($configuration->access_token) {

			// get download link
			$handle = curl_init();
			curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/apps/'.$phonegap_id.'/android?access_token='.$configuration->access_token.'');
			curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "GET");
			curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($handle, CURLOPT_HTTPHEADER, array(
				'Content-type: multipart/form-data;',
			));
			//curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
			$final = curl_exec($handle);
			$response = json_decode($final, true);
			curl_close ($handle);

			if (empty($response["location"])) {

				// get detail app for status and detail error
				$handle2 = curl_init();
				curl_setopt($handle2, CURLOPT_URL, 'https://build.phonegap.com/api/v1/apps/'.$phonegap_id.'/?access_token='.$configuration->access_token.'');
				curl_setopt($handle2, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($handle2, CURLOPT_CUSTOMREQUEST, "GET");
				curl_setopt($handle2, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($handle2, CURLOPT_HTTPHEADER, array(
					'Content-type: multipart/form-data;',
				));
				//curl_setopt($handle2, CURLOPT_POSTFIELDS, $data);
				$final2 = curl_exec($handle2);
				$response2 = json_decode($final2, true);
				curl_close ($handle2);

				$this->session->set_flashdata('error', ''.$this->lang->line('alert_7').' '.$response["error"].'.'.$this->lang->line('alert_8').' '.$response2["status"]["android"].'.'.$this->lang->line('alert_9').' '.$response2["error"]["android"].'');
            	redirect(site_url('my/apps/'.$app->id.'/builder'));

			} else {

				redirect($response["location"]);

			}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_11'));
            redirect(site_url('my/apps/'.$app->id.'/builder'));

		}
	}

	/*
	 * Download ios app
	 * @param int $phonegap_id
	 */
	public function download_ios($phonegap_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$configuration = $this->configuration_model->get_configuration();

		if ($configuration->access_token) {

			// get download link
			$handle = curl_init();
			curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/apps/'.$phonegap_id.'/ios?access_token='.$configuration->access_token.'');
			curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "GET");
			curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($handle, CURLOPT_HTTPHEADER, array(
				'Content-type: multipart/form-data;',
			));
			//curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
			$final = curl_exec($handle);
			$response = json_decode($final, true);
			curl_close ($handle);

			if (empty($response["location"])) {

				// get detail app for status and detail error
				$handle2 = curl_init();
				curl_setopt($handle2, CURLOPT_URL, 'https://build.phonegap.com/api/v1/apps/'.$phonegap_id.'/?access_token='.$configuration->access_token.'');
				curl_setopt($handle2, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($handle2, CURLOPT_CUSTOMREQUEST, "GET");
				curl_setopt($handle2, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($handle2, CURLOPT_HTTPHEADER, array(
					'Content-type: multipart/form-data;',
				));
				//curl_setopt($handle2, CURLOPT_POSTFIELDS, $data);
				$final2 = curl_exec($handle2);
				$response2 = json_decode($final2, true);
				curl_close ($handle2);

				$this->session->set_flashdata('error', ''.$this->lang->line('alert_7').' '.$response["error"].'.'.$this->lang->line('alert_10').' '.$response2["status"]["ios"].'.'.$this->lang->line('alert_9').' '.$response2["error"]["ios"].'');
            	redirect(site_url('my/apps/'.$app->id.'/builder'));

			} else {

				redirect($response["location"]);

			}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_11'));
            redirect(site_url('my/apps/'.$app->id.'/builder'));

		}
	}

	/*
	 * Save app to local storage
	 * @param int $phonegap_id
	 */
	public function save_to_local($phonegap_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($phonegap_id) OR ! is_numeric($phonegap_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_12'));
            redirect(site_url('my/apps/'.$app->id.'/builder'));

	    }

		$configuration = $this->configuration_model->get_configuration();

		$date = date('Y-m-d H:i:s');

		// Create hash
		$value_1 = rand(0000000000, 5555555555);
		$value_2 = rand(6666666666, 9999999999);
		$hash_ios = hash('sha256', $date."-".$value_1);
		$hash_android = hash('sha256', $date."-".$value_2);

		$version = $this->builder_model->get_version_phonegap($phonegap_id);

		if ($version) {

			if ($configuration->access_token) {

				// get download link ios
				$handle = curl_init();
				curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/apps/'.$phonegap_id.'/ios?access_token='.$configuration->access_token.'');
				curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "GET");
				curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($handle, CURLOPT_HTTPHEADER, array(
					'Content-type: multipart/form-data;',
				));
				//curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
				$final = curl_exec($handle);
				$response = json_decode($final, true);
				curl_close ($handle);

				if (!empty($response["location"])) {

					$ios_path = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/local/'.$hash_ios.'.ipa';

					$ios_copy = copy($response["location"], $ios_path);

				}

				// get download link android
				$handle2 = curl_init();
				curl_setopt($handle2, CURLOPT_URL, 'https://build.phonegap.com/api/v1/apps/'.$phonegap_id.'/android?access_token='.$configuration->access_token.'');
				curl_setopt($handle2, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($handle2, CURLOPT_CUSTOMREQUEST, "GET");
				curl_setopt($handle2, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($handle2, CURLOPT_HTTPHEADER, array(
					'Content-type: multipart/form-data;',
				));
				//curl_setopt($handle2, CURLOPT_POSTFIELDS, $data);
				$final2 = curl_exec($handle2);
				$response2 = json_decode($final2, true);
				curl_close ($handle2);

				if (!empty($response2["location"])) {

					$android_path = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/local/'.$hash_android.'.apk';

					$android_copy = copy($response2["location"], $android_path);

				}

				if (!empty($ios_copy)) {

					$result_ios = 'Success';

					// add local version
					$local_version = $this->builder_model->add_version(array(
				        "app_id"		=> $app->id,
				        "created"		=> $date,
				        "type"			=> 2,
				        "phonegap_id"	=> $phonegap_id,
				        "ios_path"		=> ''.$hash_ios.'.ipa'
				        )
				    );

				} else {

					$result_ios = 'Fail';

				}

				if (!empty($android_copy)) {

					$result_android = 'Success';

					if (!empty($local_version)) {

						// update local version
						$this->builder_model->update_version($local_version, array(
					        "android_path"	=> ''.$hash_android.'.apk'
					        )
					    );

					} else {

						// add local version
						$local_version = $this->builder_model->add_version(array(
					        "app_id"		=> $app->id,
					        "created"		=> $date,
					        "type"			=> 2,
					        "phonegap_id"	=> $phonegap_id,
					        "android_path"	=> ''.$hash_android.'.apk'
					        )
					    );

					}

				} else {

					$result_android = 'Fail';

				}

				if (!empty($local_version)) {

					// update phonegap version
					$this->builder_model->update_version($version->id, array(
					    "local_id"	=> $local_version
					    )
					);

				}

				$this->session->set_flashdata('success', ''.$this->lang->line('alert_14').' '.$result_ios.' / '.$this->lang->line('alert_15').' '.$result_android.'');
	            redirect(site_url('my/apps/'.$app->id.'/builder/storage'));

			} else {

				$this->session->set_flashdata('error', $this->lang->line('alert_11'));
	            redirect(site_url('my/apps/'.$app->id.'/builder'));

			}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_13'));
            redirect(site_url('my/apps/'.$app->id.'/builder'));

		}

	}

	/*
	 * Delete local storage
	 * @param int $id
	 */
	public function delete_local_version($id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', 'App not found!');
            redirect(site_url('my/apps'));

		}

		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_12'));
            redirect(site_url('my/apps/'.$app->id.'/builder/storage'));

	    }

	    $version = $this->builder_model->get_version($id);

	    if ($version) {

	    	if ($version->type == 2) {

	    		if ($version->ios_path) {

	    			$ios_path = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/local/'.$version->ios_path.'';

	    			unlink($ios_path);

	    		}

	    		if ($version->android_path) {

	    			$android_path = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/local/'.$version->android_path.'';

	    			unlink($android_path);

	    		}

	    		// del in database
				$this->builder_model->del_app($version->id);

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/apps/'.$app->id.'/builder/storage'));

	    	} else {

	    		$this->session->set_flashdata('error', $this->lang->line('alert_16'));
            	redirect(site_url('my/apps/'.$app->id.'/builder/storage'));

	    	}

	    } else {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_13'));
            redirect(site_url('my/apps/'.$app->id.'/builder/storage'));

	    }


	}

}