<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('statistics_model');
    	$this->load->model('users_model');
    	$this->load->model('comments_model');
    	$this->load->model('messages_model');
    	$this->load->model('forms_model');

		// ** Load libraries ** //
		$this->load->library('pagination');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('dashboard', $user_lang);
    $this->lang->load('layout', $user_lang);
    $this->lang->load('alert', $user_lang);
    $this->lang->load('seo', $user_lang);

	}

	/*
	 * Index page
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$year = date("Y");

		$current_m = date("m");

		$num_of_days = cal_days_in_month(CAL_GREGORIAN, $current_m, date("Y"));
	    for ($i=1; $i<= $num_of_days; $i++) $dates[]= str_pad($i,2,'0', STR_PAD_LEFT);

		if ($current_m == 1) {

            $month = "January";

        } elseif ($current_m == 2) {

            $month = "February";

        } elseif ($current_m == 3) {

            $month = "March";

        } elseif ($current_m == 4) {

            $month = "April";

        } elseif ($current_m == 5) {

            $month = "May";

        } elseif ($current_m == 6) {

            $month = "June";

        } elseif ($current_m == 7) {

            $month = "July";

        } elseif ($current_m == 8) {

            $month = "August";

        } elseif ($current_m == 9) {

            $month = "September";

        } elseif ($current_m == 10) {

            $month = "October";

        } elseif ($current_m == 11) {

            $month = "November";

        } elseif ($current_m == 12) {

            $month = "December";

        }

        $total_users = $this->users_model->get_total_users($app->id, 0);
        $total_comments = $this->comments_model->get_total($app->id, 0);
        $total_messages = $this->messages_model->get_total_dialogues($app->id);
        $total_forms = $this->forms_model->get_total_received_forms($app->id);

        $last_comments = $this->comments_model->get_last_comments($app->id);

		$data = array(
			"app"				=>  $app,
			"month"				=>  $month,
			"current_m"			=>  $current_m,
			"year"				=>  $year,
			"dates"				=>  $dates,
			"total_users"		=>  $total_users,
			"total_comments"	=>  $total_comments,
			"total_messages"	=>  $total_messages,
			"total_forms"		=>  $total_forms,
			"last_comments"		=>  $last_comments
		);

    	$this->template->set('title', $this->lang->line('seo_6'));
		$this->template->load('cms', 'contents' , 'dashboard/index', $data);
	}

}