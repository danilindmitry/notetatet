<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('posts_model');
    	$this->load->model('users_model');
    	$this->load->model('galleries_model');

		// ** Load libraries ** //
		$this->load->library('pagination');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check type app
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if ($app->type) {

			redirect(site_url('my/apps'));

		}
    
    	// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('posts', $user_lang);
    	$this->lang->load('layout', $user_lang);
    	$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * All posts
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$categories = $this->posts_model->get_categories_for_select($app->id);

		// Check search value
		if (!isset($_GET['search'])) {
		          
		    $search = null;
		          
		} else {
		          
		    $search = $this->security->xss_clean($_GET['search']);
		          
		}

		if (!isset($_GET['category'])) { // all posts

			// init params
	        $params = array();
	        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	        $total_records = $this->posts_model->get_total_posts($app->id, $search);

	        // load config file
	        $this->config->load('pagination', TRUE);
	        $settings_pagination = $this->config->item('pagination');
	        $settings_pagination['total_rows'] = $this->posts_model->get_total_posts($app->id, $search);
	        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/posts/index';

	        if ($total_records > 0)
			{
			    // get current page records
			    $params["posts"] = $this->posts_model->get_posts($settings_pagination['per_page'], $start_index, $app->id, $search);
			             
			    // use the settings to initialize the library
			    $this->pagination->initialize($settings_pagination);
			             
			    // build paging links
			    $params["links"] = $this->pagination->create_links();
			}

			$params["total_records"] = $total_records;
			$params["app"] = $app;
			$params["categories"] = $categories;

			$this->template->set('title', $this->lang->line('seo_17'));
			$this->template->load('cms', 'contents' , 'posts/index', $params);

		} else {

			// sort by category
			if (is_null($_GET['category']) OR ! is_numeric($_GET['category'])) {

		    	$this->session->set_flashdata('error', $this->lang->line('alert_68'));
	            redirect(site_url('my/apps/'.$app->id.'/posts'));

		    }

		    $category = $this->posts_model->get_category($_GET['category']);

		    if ($category) {

		    	// init params
	        	$params = array();
	        	$start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	        	$total_records = $this->posts_model->get_total_posts_for_category($app->id, $category->id);

	        	// load config file
	        	$this->config->load('pagination', TRUE);
	        	$settings_pagination = $this->config->item('pagination');
	        	$settings_pagination['total_rows'] = $this->posts_model->get_total_posts_for_category($app->id, $category->id);
	        	$settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/posts/index';

	        	if ($total_records > 0)
				{
				    // get current page records
				    $params["posts"] = $this->posts_model->get_posts_for_category($settings_pagination['per_page'], $start_index, $app->id, $category->id);
				             
				    // use the settings to initialize the library
				    $this->pagination->initialize($settings_pagination);
				             
				    // build paging links
				    $params["links"] = $this->pagination->create_links();
				}

				$params["total_records"] = $total_records;
				$params["app"] = $app;
				$params["categories"] = $categories;

		    	$this->template->set('title', $this->lang->line('seo_17'));
				$this->template->load('cms', 'contents' , 'posts/index', $params);

		    } else {

		    	// empty category
		    	$this->session->set_flashdata('error', $this->lang->line('alert_69'));
	            redirect(site_url('my/apps/'.$app->id.'/posts'));

		    }

		}
	}

	/*
	 * All categories
	 */
	public function categories()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		// Check search value
		if (!isset($_GET['search'])) {
		          
		    $search = null;
		          
		} else {
		          
		    $search = $this->security->xss_clean($_GET['search']);
		          
		}

		$groups_list = $this->users_model->get_groups_list($app->id);

		if (!isset($_GET['status'])) { // all categories

			// init params
	        $params = array();
	        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	        $total_records = $this->posts_model->get_total_categories($app->id, $search);

	        // load config file
	        $this->config->load('pagination', TRUE);
	        $settings_pagination = $this->config->item('pagination');
	        $settings_pagination['total_rows'] = $this->posts_model->get_total_categories($app->id, $search);
	        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/posts/categories';

	        if ($total_records > 0)
			{
			    // get current page records
			    $params["categories"] = $this->posts_model->get_categories($settings_pagination['per_page'], $start_index, $app->id, $search);
			             
			    // use the settings to initialize the library
			    $this->pagination->initialize($settings_pagination);
			             
			    // build paging links
			    $params["links"] = $this->pagination->create_links();
			}

			$params["total_records"] = $total_records;
			$params["app"] = $app;
			$params["groups_list"] = $groups_list;

			$this->template->set('title', $this->lang->line('seo_18'));
			$this->template->load('cms', 'contents' , 'posts/categories', $params);

	    } else {

	    	if ($_GET['status'] == 1 or $_GET['status'] == 2) {

	    		// init params
	        	$params = array();
	        	$start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	        	$total_records = $this->posts_model->get_total_category_for_status($app->id, $_GET['status']);

	        	// load config file
	        	$this->config->load('pagination', TRUE);
	        	$settings_pagination = $this->config->item('pagination');
	        	$settings_pagination['total_rows'] = $this->posts_model->get_total_category_for_status($app->id, $_GET['status']);
	        	$settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/posts/categories';

	        	if ($total_records > 0)
				{
				    // get current page records
				    $params["categories"] = $this->posts_model->get_categorie_for_status($settings_pagination['per_page'], $start_index, $app->id, $_GET['status']);
				             
				    // use the settings to initialize the library
				    $this->pagination->initialize($settings_pagination);
				             
				    // build paging links
				    $params["links"] = $this->pagination->create_links();
				}

				$params["total_records"] = $total_records;
				$params["app"] = $app;
				$params["groups_list"] = $groups_list;

				$this->template->set('title', $this->lang->line('seo_18'));
				$this->template->load('cms', 'contents' , 'posts/categories', $params);

		    } else {

		    	$this->session->set_flashdata('error', $this->lang->line('alert_17'));
	            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

		    }
  
	    }

	}

	/*
	 * Edit category view page
	 * @param int $category_id
	 */
	public function edit_category($category_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($category_id) OR ! is_numeric($category_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_68'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    }

	    $category = $this->posts_model->get_category($category_id);

	    if ($category) {

			$groups_list = $this->users_model->get_groups_list($app->id);

			$data = array(
				"app"			=>  $app,
				"category"		=>  $category,
				"groups_list"	=>  $groups_list
			);

	    	$this->template->set('title', $this->lang->line('seo_19'));
			$this->template->load('cms', 'contents' , 'posts/edit_category', $data);

		} else {

			// empty category
	    	$this->session->set_flashdata('error', $this->lang->line('alert_69'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

		}
	}

	/*
	 * Add category view page
	 */
	public function add_category()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$groups_list = $this->users_model->get_groups_list($app->id);

		$data = array(
			"app"			=>  $app,
			"groups_list"	=>  $groups_list
		);

    	$this->template->set('title', $this->lang->line('seo_20'));
		$this->template->load('cms', 'contents' , 'posts/add_category', $data);
	}

	/*
	 * Add post view page
	 */
	public function add_post()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$groups_list = $this->users_model->get_groups_list($app->id);

		$categories = $this->posts_model->get_categories_for_select($app->id);

		$galleries = $this->galleries_model->get_galleries_for_select($app->id);

		$data = array(
			"app"			=>  $app,
			"groups_list"	=>  $groups_list,
			"categories"	=>  $categories,
			"galleries"		=>  $galleries
		);

    	$this->template->set('title', $this->lang->line('seo_21'));
		$this->template->load('cms', 'contents' , 'posts/add_post', $data);
	}

	/*
	 * Edit post view page
	 * @param int $post_id
	 */
	public function edit_post($post_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($post_id) OR ! is_numeric($post_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_18'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }

	    $post = $this->posts_model->get_post($post_id);

	    if ($post) {

	    	$groups_list = $this->users_model->get_groups_list($app->id);

			$categories = $this->posts_model->get_categories_for_select($app->id);

			$galleries = $this->galleries_model->get_galleries_for_select($app->id);

			$data = array(
				"app"			=>  $app,
				"post"			=>  $post,
				"groups_list"	=>  $groups_list,
				"categories"	=>  $categories,
				"galleries"		=>  $galleries
			);

	    	$this->template->set('title', $this->lang->line('seo_22'));
			$this->template->load('cms', 'contents' , 'posts/edit_post', $data);

	    } else {

	    	//empty post
	    	$this->session->set_flashdata('error', $this->lang->line('alert_19'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }

	}

	/*
	 * Update post
	 * @param int $post_id
	 */
	public function update_post($post_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($post_id) OR ! is_numeric($post_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_18'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }

	    $post = $this->posts_model->get_post($post_id);

	    if ($post) {

	    	$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[200]|min_length[3]');
			$this->form_validation->set_rules('status', "Status", 'trim|required|numeric|in_list[1,2]');
			$this->form_validation->set_rules('category', "Category", 'trim|required|numeric');
			$this->form_validation->set_rules('content', "Content", 'trim|required|min_length[3]');
			$this->form_validation->set_rules('rights', "Access rights", 'trim|required|numeric|in_list[0,1,2]');
			$this->form_validation->set_rules('group', "Users group", 'trim|required|numeric');
			$this->form_validation->set_rules('gallery', "Attach gallery", 'trim|required|numeric');
			$this->form_validation->set_rules('author', "Author", 'trim|required|max_length[200]|min_length[3]');
			$this->form_validation->set_rules('comments', "Comments", 'trim|required|numeric|in_list[1,2]');
			$this->form_validation->set_rules('info', "Description for list", 'trim|required|min_length[3]');

			if ($this->form_validation->run() == false) {

		        $this->session->set_flashdata('error', validation_errors());
		        redirect(site_url('my/apps/'.$app->id.'/posts/add_post'));

		    } else {

		    	// set variable for input data
		        $name = $this->input->post("name", true);
		        $status = $this->input->post("status", true);
		        $category = $this->input->post("category", true);
		        $content = $this->input->post("content");
		        $rights = $this->input->post("rights", true);
		        $group = $this->input->post("group", true);
		        $gallery = $this->input->post("gallery", true);
		        $author = $this->input->post("author", true);
		        $comments = $this->input->post("comments", true);
		        $info = $this->input->post("info", true);

		        // Image upload
		        $config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/posts/posts';
		        $config['allowed_types']    = 'gif|jpg|png';
		        $config['max_size']         = 40000; // 5mb
		        $config['encrypt_name']     = TRUE;
		        $config['remove_spaces']    = TRUE;

		        $this->load->library('upload', $config);

		        // Check image
		        if (!$this->upload->do_upload('image')) {

		            $image = $post->image;

		        } else {

		            $image = $this->upload->data('file_name');

		        }

		        $this->posts_model->update_post($post->id, array(
				    "category"		=> $category,
				    "author"		=> $author,
				    "name"			=> $name,
				    "content"		=> $content,
				    "image"			=> $image,
				    "rights"		=> $rights,
				    "users_group"	=> $group,
				    "status"		=> $status,
				    "gallery"		=> $gallery,
				    "comments"		=> $comments,
				    "info"			=> $info
				    )
				);

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
			    redirect(site_url('my/apps/'.$app->id.'/posts/edit_post/'.$post->id.''));

		    }

	    } else {

	    	// empry post
	    	$this->session->set_flashdata('error', $this->lang->line('alert_19'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }

	}

	/*
	 * Create post
	 */
	public function create_post()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[200]|min_length[3]');
		$this->form_validation->set_rules('status', "Status", 'trim|required|numeric|in_list[1,2]');
		$this->form_validation->set_rules('category', "Category", 'trim|required|numeric');
		$this->form_validation->set_rules('content', "Content", 'trim|required|min_length[3]');
		$this->form_validation->set_rules('rights', "Access rights", 'trim|required|numeric|in_list[0,1,2]');
		$this->form_validation->set_rules('group', "Users group", 'trim|required|numeric');
		$this->form_validation->set_rules('gallery', "Attach gallery", 'trim|required|numeric');
		$this->form_validation->set_rules('author', "Author", 'trim|required|max_length[200]|min_length[3]');
		$this->form_validation->set_rules('comments', "Comments", 'trim|required|numeric|in_list[1,2]');
		$this->form_validation->set_rules('info', "Description for list", 'trim|required|min_length[3]');

		if ($this->form_validation->run() == false) {

	        $this->session->set_flashdata('error', validation_errors());
	        redirect(site_url('my/apps/'.$app->id.'/posts/add_post'));

	    } else {

	    	// set variable for input data
	        $name = $this->input->post("name", true);
	        $status = $this->input->post("status", true);
	        $category = $this->input->post("category", true);
	        $content = $this->input->post("content");
	        $rights = $this->input->post("rights", true);
	        $group = $this->input->post("group", true);
	        $gallery = $this->input->post("gallery", true);
	        $author = $this->input->post("author", true);
	        $comments = $this->input->post("comments", true);
	        $info = $this->input->post("info", true);

	        // Image upload
	        $config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/posts/posts';
	        $config['allowed_types']    = 'gif|jpg|png';
	        $config['max_size']         = 40000; // 5mb
	        $config['encrypt_name']     = TRUE;
	        $config['remove_spaces']    = TRUE;

	        $this->load->library('upload', $config);

	        // Check image
	        if (!$this->upload->do_upload('image')) {

	            $image = '';

	        } else {

	            $image = $this->upload->data('file_name');

	        }

	        $this->posts_model->add_post(array(
			    "app_id"		=> $app->id,
			    "category"		=> $category,
			    "created"		=> date('Y-m-d H:i:s'),
			    "author"		=> $author,
			    "name"			=> $name,
			    "content"		=> $content,
			    "image"			=> $image,
			    "rights"		=> $rights,
			    "users_group"	=> $group,
			    "status"		=> $status,
			    "views_count"	=> 0,
			    "gallery"		=> $gallery,
			    "comments"		=> $comments,
			    "info"			=> $info
			    )
			);

			$this->session->set_flashdata('success', $this->lang->line('alert_1'));
		    redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }
	}

	/*
	 * Update category
	 * @param int $category_id
	 */
	public function update_category($category_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($category_id) OR ! is_numeric($category_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_68'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    }

	    $category = $this->posts_model->get_category($category_id);

	    if ($category) {

	    	$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[200]|min_length[3]');
			$this->form_validation->set_rules('status', "Status", 'trim|required|numeric|in_list[1,2]');
			$this->form_validation->set_rules('info', "Category description", 'trim|required|max_length[2000]|min_length[3]');
			$this->form_validation->set_rules('rights', "Access rights", 'trim|required|numeric|in_list[0,1,2]');
			$this->form_validation->set_rules('group', "Users group", 'trim|required|numeric');
			$this->form_validation->set_rules('view', "Template", 'trim|required|numeric|in_list[1,2,3]');

			if ($this->form_validation->run() == false) {

	            $this->session->set_flashdata('error', validation_errors());
	            redirect(site_url('my/apps/'.$app->id.'/posts/edit_category/'.$category->id.''));

	        } else {

	        	// set variable for input data
	        	$name = $this->input->post("name", true);
	        	$status = $this->input->post("status", true);
	        	$info = $this->input->post("info", true);
	        	$rights = $this->input->post("rights", true);
	        	$group = $this->input->post("group", true);
	        	$view = $this->input->post("view", true);

	        	// Image upload
	            $config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/posts/categories';
	            $config['allowed_types']    = 'gif|jpg|png';
	            $config['max_size']         = 40000; // 5mb
	            $config['encrypt_name']     = TRUE;
	            $config['remove_spaces']    = TRUE;

	            $this->load->library('upload', $config);

	            // Check image
	            if (!$this->upload->do_upload('image')) {

	                $image = $category->image;

	            } else {

	                $image = $this->upload->data('file_name');

	            }

	            $this->posts_model->update_category($category->id, array(
			        "name"			=> $name,
			        "info"			=> $info,
			        "status"		=> $status,
			        "rights"		=> $rights,
			        "image"			=> $image,
			        "users_group"	=> $group,
			        "view"			=> $view
			        )
			    );
				
			    $this->session->set_flashdata('success', $this->lang->line('alert_1'));
		        redirect(site_url('my/apps/'.$app->id.'/posts/edit_category/'.$category->id.''));

	        }

	    } else {

	    	// empty category
	    	$this->session->set_flashdata('error', $this->lang->line('alert_69'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    }
	}

	/*
	 * Create category
	 */
	public function create_category()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[200]|min_length[3]');
		$this->form_validation->set_rules('status', "Status", 'trim|required|numeric|in_list[1,2]');
		$this->form_validation->set_rules('info', "Category description", 'trim|required|max_length[2000]|min_length[3]');
		$this->form_validation->set_rules('rights', "Access rights", 'trim|required|numeric|in_list[0,1,2]');
		$this->form_validation->set_rules('group', "Users group", 'trim|required|numeric');
		$this->form_validation->set_rules('view', "Template", 'trim|required|numeric|in_list[1,2,3]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/posts/add_category'));

        } else {

        	// set variable for input data
        	$name = $this->input->post("name", true);
        	$status = $this->input->post("status", true);
        	$info = $this->input->post("info", true);
        	$rights = $this->input->post("rights", true);
        	$group = $this->input->post("group", true);
        	$view = $this->input->post("view", true);

        	// Image upload
            $config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/posts/categories';
            $config['allowed_types']    = 'gif|jpg|png';
            $config['max_size']         = 40000; // 5mb
            $config['encrypt_name']     = TRUE;
            $config['remove_spaces']    = TRUE;

            $this->load->library('upload', $config);

            // Check image
            if (!$this->upload->do_upload('image')) {

                $image = 'default.png';

            } else {

                $image = $this->upload->data('file_name');

            }
            
            $this->posts_model->add_category(array(
		        "app_id"		=> $app->id,
		        "created"		=> date('Y-m-d H:i:s'),
		        "name"			=> $name,
		        "info"			=> $info,
		        "status"		=> $status,
		        "rights"		=> $rights,
		        "image"			=> $image,
		        "sort"			=> 0,
		        "users_group"	=> $group,
		        "view"			=> $view
		        )
		    );
			
		    $this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        redirect(site_url('my/apps/'.$app->id.'/posts/categories'));
        }
	}

	/*
	 * Unpublish post
	 * @param int $post_id
	 */
	public function unpublish_post($post_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($post_id) OR ! is_numeric($post_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_18'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }

	    $post = $this->posts_model->get_post($post_id);

	    if ($post) {

	    	if ($post->status == 1) {

	    		$this->posts_model->update_post($post->id, array(
		            "status"	=> 2,
		            )
		        );

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$app->id.'/posts'));

	    	} else {

	    		$this->session->set_flashdata('error', $this->lang->line('alert_70'));
            	redirect(site_url('my/apps/'.$app->id.'/posts'));

	    	}

	    } else {

	    	// empry post
	    	$this->session->set_flashdata('error', $this->lang->line('alert_19'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }
	}

	/*
	 * Publish post
	 * @param int $post_id
	 */
	public function publish_post($post_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($post_id) OR ! is_numeric($post_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_18'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }

	    $post = $this->posts_model->get_post($post_id);

	    if ($post) {

	    	if ($post->status == 2) {

	    		$this->posts_model->update_post($post->id, array(
		            "status"	=> 1,
		            )
		        );

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$app->id.'/posts'));

	    	} else {

	    		$this->session->set_flashdata('error', $this->lang->line('alert_71'));
            	redirect(site_url('my/apps/'.$app->id.'/posts'));

	    	}

	    } else {

	    	// empry post
	    	$this->session->set_flashdata('error', $this->lang->line('alert_19'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }
	}


	/*
	 * Delete post
	 * @param int $post_id
	 */
	public function delete_post($post_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($post_id) OR ! is_numeric($post_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_18'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }

	    $post = $this->posts_model->get_post($post_id);

	    if ($post) {

	    	$this->posts_model->del_post($post->id);

	    	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    } else {

	    	// empry post
	    	$this->session->set_flashdata('error', $this->lang->line('alert_19'));
            redirect(site_url('my/apps/'.$app->id.'/posts'));

	    }
	}

	/*
	 * Unpublish category
	 * @param int $category_id
	 */
	public function unpublish($category_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($category_id) OR ! is_numeric($category_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_68'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    }

	    $category = $this->posts_model->get_category($category_id);

	    if ($category) {

	    	if ($category->status == 1) {

	    		$this->posts_model->update_category($category->id, array(
		            "status"	=> 2,
		            )
		        );

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    	} else {

	    		$this->session->set_flashdata('error', $this->lang->line('alert_72'));
            	redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    	}

	    } else {

	    	// empty category
	    	$this->session->set_flashdata('error', $this->lang->line('alert_69'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    }
	}

	/*
	 * Publish category
	 * @param int $category_id
	 */
	public function publish($category_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($category_id) OR ! is_numeric($category_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_68'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    }

	    $category = $this->posts_model->get_category($category_id);

	    if ($category) {

	    	if ($category->status == 2) {

	    		 $this->posts_model->update_category($category->id, array(
		            "status"	=> 1,
		            )
		        );

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    	} else {

	    		$this->session->set_flashdata('error', $this->lang->line('alert_72'));
            	redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    	}

	    } else {

	    	// empty category
	    	$this->session->set_flashdata('error', $this->lang->line('alert_69'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    }
	}

	/*
	 * Delete category
	 * @param int $category_id
	 */
	public function delete_category($category_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($category_id) OR ! is_numeric($category_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_68'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    }

	    $category = $this->posts_model->get_category($category_id);

	    if ($category) {

	    	// delete category in database
	    	$this->posts_model->del_category($category->id);

	    	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    } else {

	    	// empty category
	    	$this->session->set_flashdata('error', $this->lang->line('alert_69'));
            redirect(site_url('my/apps/'.$app->id.'/posts/categories'));

	    }
	}

	/*
	 * Update sort categories
	 * @param int $app_id
	 */
	public function update_sort_categories($app_id)
	{
		if (is_null($app_id) OR ! is_numeric($app_id)) {

	    } else {

	    	$app = $this->apps_model->get_app($app_id);

	    	if ($app) {

	    		$arrayItems = $_GET['item'];
        		$i = 0;

	    		foreach ($arrayItems as $value) {

		           $this->posts_model->update_category($value, array(
		                "sort"   =>  $i
		                )
		            );

		            $i++;
		        }

	    	}

	    }
	}

}