<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Configuration extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('configuration_model');
    	$this->load->model('template_model');
    	$this->load->model('localization_model');

		// ** Load libraries ** //
		$this->load->library('pagination');
		$this->load->library('writer');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('configuration', $user_lang);
    $this->lang->load('layout', $user_lang);
    $this->lang->load('alert', $user_lang);
    $this->lang->load('seo', $user_lang);

	}

	/*
	 * Index page
	 */
	public function index()
	{
		$configuration = $this->configuration_model->get_configuration();

		$data = array(
			"configuration"	=> $configuration,
		);

    	$this->template->set('title', $this->lang->line('seo_5'));
		$this->template->load('apps', 'contents' , 'configuration/index', $data);
	}

	/*
	 * Emaile templates
	 */
	public function email()
	{
		$templates = $this->template_model->get_templates_email();

		$data = array(
			"templates"	=> $templates
		);

    	$this->template->set('title', $this->lang->line('seo_5'));
		$this->template->load('apps', 'contents' , 'configuration/email', $data);
	}

	/*
	 * Edit email template
	 * @param int $id
	 */
	public function edit_mail($id)
	{
		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_24'));
            redirect(site_url('my/configuration/email'));

	    }

	    $template = $this->template_model->get_email_template($id);

	    if (!$template) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_25'));
            redirect(site_url('my/configuration/email'));

	    }

		$data = array(
			"template"	=> $template
		);

    	$this->template->set('title', $this->lang->line('seo_5'));
		$this->template->load('apps', 'contents' , 'configuration/edit_mail', $data);
	}

	/*
	 * Update email template
	 * @param int $id
	 */
	public function update_mail($id)
	{
		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_24'));
            redirect(site_url('my/configuration/email'));

	    }

	    $template = $this->template_model->get_email_template($id);

	    if (!$template) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_25'));
            redirect(site_url('my/configuration/email'));

	    }

		$this->form_validation->set_rules('title', "Title", 'trim|required|max_length[300]|min_length[2]');
		$this->form_validation->set_rules('status', "Status", 'trim|required|in_list[1,2]');
		$this->form_validation->set_rules('message', "Message", 'trim|required|min_length[2]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/configuration/email'));

        } else {

        	// set variable for input data
        	$title = $this->input->post("title", true);
        	$status = $this->input->post("status", true);
        	$message = $this->input->post("message");

        	// update
	        $this->template_model->update_email_template($template->id, array(
		        "title"		=> $title,
		        "status"	=> $status,
		        "message"	=> $message
		        )
		    );

		    $this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/configuration/edit_mail/'.$template->id.''));

        }
	}

	/*
	 * Phonegap connect
	 */
	public function phonegap_connect()
	{
		$this->form_validation->set_rules('client_id', "Client ID", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('client_secret', "Client Secret", 'trim|required|max_length[100]|min_length[2]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/configuration'));

        } else {

        	// set variable for input data
        	$client_id = $this->input->post("client_id", true);
        	$client_secret = $this->input->post("client_secret", true);

        	// update
	        $this->configuration_model->update_configuration(array(
		        "client_id"		=> $client_id,
		        "client_secret"	=> $client_secret,
		        )
		    );

            redirect('https://build.phonegap.com/authorize?client_id='.$client_id.'');

        }
	}

	/*
	 * Phonegap reset
	 */
	public function reset_phonegap()
	{
		$configuration = $this->configuration_model->get_configuration();

		if ($configuration->access_token) {

			// update
		    $this->configuration_model->update_configuration(array(
			    "client_id"		=> "",
			    "client_secret"	=> "",
			    "access_token"	=> ""
			    )
			);

			$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        redirect(site_url('my/configuration'));

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_26'));
	        redirect(site_url('my/configuration'));

		}

	}

	/*
	 * Windows connect
	 */
	/*
	public function windows_connect()
	{
		$this->form_validation->set_rules('title', "Title", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('publisher_id', "Publisher ID", 'trim|required|max_length[100]|min_length[2]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/configuration'));

        } else {

        	$configuration = $this->configuration_model->get_configuration();

        	if ($configuration->access_token) {

        		// set variable for input data
        		$title = $this->input->post("title", true);
        		$publisher_id = $this->input->post("publisher_id", true);

        		$data = array(
				    "data" => '{"title":"'.$title.'","publisher_id":"'.$publisher_id.'"}'
				);
				$handle = curl_init();
				curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/keys/winphone?access_token='.$configuration->access_token.'');
				curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "POST");
				curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($handle, CURLOPT_HTTPHEADER, array(
				  'Content-type: multipart/form-data;',
				));
				curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
				$response = curl_exec($handle);
				$response = json_decode($response, true);
				curl_close ($handle);

				if (!empty($response["id"])) {

					$this->configuration_model->update_configuration(array(
					    "sign_windows"	=> $response["id"],
					    )
					);

					$this->session->set_flashdata('success', "Success");
	        		redirect(site_url('my/configuration'));

				} else {

					$this->session->set_flashdata('error', "Could not add signature");
	        		redirect(site_url('my/configuration'));

				}

        	} else {

        		$this->session->set_flashdata('error', "Phonegap token not found");
	        	redirect(site_url('my/configuration'));

        	}

        }
	}


	public function reset_windows()
	{
		$configuration = $this->configuration_model->get_configuration();

		if ($configuration->sign_windows) {

			// del request
			$handle = curl_init();
			curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/keys/winphone/'.$configuration->sign_windows.'/?access_token='.$configuration->access_token.'');
			curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "DELETE");
			curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
			$response = curl_exec($handle);
			$httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
			$response = json_decode($response, true);
			curl_close ($handle);

			if ($httpCode == 202) {

				$this->configuration_model->update_configuration(array(
					"sign_windows"	=> 0
					)
				);

				$this->session->set_flashdata('success', "Success!");
            	redirect(site_url('my/configuration'));

			} else {

				$this->session->set_flashdata('error', "Signature could not be deleted!");
            	redirect(site_url('my/configuration'));

			}

		} else {

			$this->session->set_flashdata('error', "Windows signature not found");
	        redirect(site_url('my/configuration'));

		}
	}
	*/

	/*
	 * Android connect
	 */
	public function android_connect()
	{
		$this->form_validation->set_rules('title', "Title", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('alias', "Alias", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('key_pw', "Key password", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('keystore_pw', "Keystore password", 'trim|required|max_length[100]|min_length[2]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/configuration'));

        } else {

        	$configuration = $this->configuration_model->get_configuration();

        	if (!$configuration->sign_android) {

        		// set variable for input data
	        	$title = $this->input->post("title", true);
	        	$alias = $this->input->post("alias", true);
	        	$key_pw = $this->input->post("key_pw", true);
	        	$keystore_pw = $this->input->post("keystore_pw", true);

	        	// keystore upload
		        $config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/keys';
		        $config['allowed_types']    = 'keystore';
		        $config['max_size']         = 40000; // 5mb
		        $config['remove_spaces']    = TRUE;
		        $config['overwrite']    	= TRUE;

		        $this->load->library('upload', $config);

		        // check keystore file
		        if (!$this->upload->do_upload('keystore')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
	            	redirect(site_url('my/configuration'));

		        } else {

		            $keystore = $this->upload->data('file_name');

		            $file = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/keys/'.$keystore.'';

		            $data = array(
					    "keystore" 	=> new CURLFile($file),
					    "data" 		=> '{"title":"'.$title.'","alias":"'.$alias.'","key_pw":"'.$key_pw.'","keystore_pw":"'.$keystore_pw.'"}'
					);

					$handle = curl_init();
					curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/keys/android?access_token='.$configuration->access_token.'');
					curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "POST");
					curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
					curl_setopt($handle, CURLOPT_HTTPHEADER, array(
					  'Content-type: multipart/form-data;',
					));
					curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
					$final = curl_exec($handle);
					$response = json_decode($final, true);
					curl_close ($handle);

		            if (!empty($response["id"])) {

						$this->configuration_model->update_configuration(array(
						    "sign_android"	=> $response["id"],
						    )
						);

						$this->session->set_flashdata('success', $this->lang->line('alert_1'));
		        		redirect(site_url('my/configuration'));

					} else {

						$this->session->set_flashdata('error', $this->lang->line('alert_27'));
		        		redirect(site_url('my/configuration'));

					}

		        }

        	} else {

        		$this->session->set_flashdata('error', $this->lang->line('alert_28'));
	            redirect(site_url('my/configuration'));

        	}

        }
	}

	/*
	 * Android delete signature
	 */
	public function reset_android()
	{
		$configuration = $this->configuration_model->get_configuration();

		if ($configuration->sign_android) {

			// del request
			$handle = curl_init();
			curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/keys/android/'.$configuration->sign_android.'/?access_token='.$configuration->access_token.'');
			curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "DELETE");
			curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
			$response = curl_exec($handle);
			$httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
			$response = json_decode($response, true);
			curl_close ($handle);

			if ($httpCode == 202) {

				$this->configuration_model->update_configuration(array(
					"sign_android"	=> 0
					)
				);

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/configuration'));

			} else {

				$this->session->set_flashdata('error', $this->lang->line('alert_29'));
            	redirect(site_url('my/configuration'));

			}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_30'));
	        redirect(site_url('my/configuration'));

		}
	}

	/*
	 * Apple connect
	 */
	public function apple_connect()
	{
		$this->form_validation->set_rules('title', "Title", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('password', "Certificate password", 'trim|required|max_length[100]|min_length[2]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/configuration'));

        } else {

        	// set variable for input data
	        $title = $this->input->post("title", true);
	        $password = $this->input->post("password", true);

        	$configuration = $this->configuration_model->get_configuration();

        	if (!$configuration->sign_ios) {

        		// Certificate upload
		        $config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/keys';
		        $config['allowed_types']    = 'p12|mobileprovision';
		        $config['max_size']         = 40000; // 5mb
		        $config['remove_spaces']    = TRUE;
		        $config['overwrite']    	= TRUE;

		        $this->load->library('upload', $config);

		        // check Certificate file
		        if (!$this->upload->do_upload('certificate')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
	            	redirect(site_url('my/configuration'));

		        } else {

		        	$certificate = $this->upload->data('file_name');

		        	// check Provisioning profile
			        if (!$this->upload->do_upload('provisioning')) {

			            $this->session->set_flashdata('error', $this->upload->display_errors());
		            	redirect(site_url('my/configuration'));

			        } else {

			        	$provisioning = $this->upload->data('file_name');

			        	$file_certificate = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/keys/'.$certificate.'';
			        	$file_provisioning = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/keys/'.$provisioning.'';

			            $data = array(
						    "cert" 		=> new CURLFile($file_certificate),
						    "profile" 	=> new CURLFile($file_provisioning),
						    "data" 		=> '{"title":"'.$title.'","password":"'.$password.'"}'
						);

						$handle = curl_init();
						curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/keys/ios?access_token='.$configuration->access_token.'');
						curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "POST");
						curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($handle, CURLOPT_HTTPHEADER, array(
						  'Content-type: multipart/form-data;',
						));
						curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
						$final = curl_exec($handle);
						$response = json_decode($final, true);
						curl_close ($handle);

						if (!empty($response["id"])) {

							$this->configuration_model->update_configuration(array(
							    "sign_ios"	=> $response["id"],
							    )
							);

							$this->session->set_flashdata('success', $this->lang->line('alert_1'));
			        		redirect(site_url('my/configuration'));

						} else {

							$this->session->set_flashdata('error', $this->lang->line('alert_27'));
			        		redirect(site_url('my/configuration'));

						}

			        }

		        }

        	} else {

        		$this->session->set_flashdata('error', $this->lang->line('alert_31'));
	            redirect(site_url('my/configuration'));

        	}

        }
	}

	/*
	 * Apple delete signature
	 */
	public function reset_apple()
	{
		$configuration = $this->configuration_model->get_configuration();

		if ($configuration->sign_ios) {

			// del request
			$handle = curl_init();
			curl_setopt($handle, CURLOPT_URL, 'https://build.phonegap.com/api/v1/keys/ios/'.$configuration->sign_ios.'/?access_token='.$configuration->access_token.'');
			curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($handle, CURLOPT_CUSTOMREQUEST, "DELETE");
			curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
			$response = curl_exec($handle);
			$httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);
			$response = json_decode($response, true);
			curl_close ($handle);

			if ($httpCode == 202) {

				$this->configuration_model->update_configuration(array(
					"sign_ios"	=> 0
					)
				);

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/configuration'));

			} else {

				$this->session->set_flashdata('error', $this->lang->line('alert_29'));
            	redirect(site_url('my/configuration'));

			}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_32'));
	        redirect(site_url('my/configuration'));

		}
	}

	/*
	 * Design template
	 */
	public function design()
	{
		$templates = $this->template_model->get_templates_design();

		$data = array(
			"templates"	=> $templates
		);

    	$this->template->set('title', $this->lang->line('seo_5'));
		$this->template->load('apps', 'contents' , 'configuration/design', $data);
	}

	/*
	 * Upload template
	 */
	public function upload_template()
	{
		$this->form_validation->set_rules('name', "Name template", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('path', "Path", 'trim|required|max_length[100]|min_length[2]|alpha_numeric');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/configuration/design'));

        } else {

        	// set variable for input data
        	$name = $this->input->post("name", true);
        	$path = $this->input->post("path", true);

        	// create path
        	$directory = $this->writer->create_path_template($path);

        	if ($directory) {

        		// Upload ZIP
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/templates/'.$path.'';
		        $config['allowed_types']    = 'zip';
		        $config['max_size']         = 0;
		        $config['encrypt_name']     = TRUE;
		        $config['remove_spaces']    = TRUE;

		        $this->load->library('upload', $config);

		        // Check zip
		        if (!$this->upload->do_upload('zip_file')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/configuration/design'));

		        } else {

		        	// extract zip
		        	$zip = new ZipArchive;
					$zip->open(''.$_SERVER['DOCUMENT_ROOT'].'/templates/'.$path.'/'.$this->upload->data('file_name').'');
					$zip->extractTo(''.$_SERVER['DOCUMENT_ROOT'].'/templates/'.$path.'');
					$zip->close();

					// delete zip
					unlink(''.$_SERVER['DOCUMENT_ROOT'].'/templates/'.$path.'/'.$this->upload->data('file_name').'');

					// add template in database
					$this->template_model->add_design_template(array(
						"name"	=> $name,
						"path"	=> $path,
						)
					);

		        	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
		            redirect(site_url('my/configuration/design'));

		        }

        	} else {

        		$this->session->set_flashdata('error', $this->lang->line('alert_33'));
            	redirect(site_url('my/configuration/design'));

        	}

        }
	}

	/*
	 * Delete template
	 * @param int $id
	 */
	public function delete_template($id)
	{
		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_24'));
            redirect(site_url('my/configuration/design'));

	    }

	    $template = $this->template_model->get_design_template($id);

	    if ($template) {

	    	if ($template->id > 1) {

	    		$this->template_model->del_design_template($template->id);

	    		// delete files template
	    		$template_directory = ''.$_SERVER['DOCUMENT_ROOT'].'/templates/'.$template->path.'';
	    		$this->load->helper("file");
	    		delete_files($template_directory, true);

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/configuration/design'));

	    	} else {

	    		$this->session->set_flashdata('error', $this->lang->line('alert_34'));
            	redirect(site_url('my/configuration/design'));

	    	}

	    } else {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_25'));
            redirect(site_url('my/configuration/design'));

	    }
	}

	/*
	 * Localizations
	 */
	public function localizations()
	{
		$localizations = $this->localization_model->get_localizations();

		$data = array(
			"localizations"	=> $localizations
		);

    	$this->template->set('title', $this->lang->line('seo_5'));
		$this->template->load('apps', 'contents' , 'configuration/localizations', $data);
	}

	/*
	 * Upload localization
	 */
	public function upload_localization()
	{
		$this->form_validation->set_rules('name', "Name template", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('path', "Path", 'trim|required|max_length[100]|min_length[2]|alpha_numeric');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/configuration/localizations'));

        } else {

        	// set variable for input data
        	$name = $this->input->post("name", true);
        	$path = $this->input->post("path", true);

        	if (file_exists(''.$_SERVER['DOCUMENT_ROOT'].'/application/language/'.$path.'')) {

        		// add template in database
        		
				$this->localization_model->add_localization(array(
					"name"	=> $name,
					"path"	=> $path
					)
				);
				

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	            redirect(site_url('my/configuration/localizations'));

        	} else {

        		$this->session->set_flashdata('error', $this->lang->line('alert_35'));
            	redirect(site_url('my/configuration/localizations'));

        	}

        }
	}

	/*
	 * Delete localization
	 * @param int $id
	 */
	public function delete_localization($id)
	{
		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_24'));
            redirect(site_url('my/configuration/localizations'));

	    }

	    $localization = $this->localization_model->get_localization($id);

	    if ($localization) {

	    	if ($localization->id > 1) {

	    		$this->localization_model->del_localization($localization->id);

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/configuration/localizations'));

	    	} else {

	    		$this->session->set_flashdata('error', $this->lang->line('alert_36'));
            	redirect(site_url('my/configuration/localizations'));

	    	}

	    } else {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_37'));
            redirect(site_url('my/configuration/localizations'));

	    }
	}

	/*
	 * Select language
	 * @param int $id
	 */
	public function select_lang($id)
	{
		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_24'));
            redirect(site_url('my/configuration/localizations'));

	    }

	    $localization = $this->localization_model->get_localization($id);

	    if ($localization) {

	    	// add true login session
      		$data_session = array(
        		'lang' => $localization->path
        	);

        	$this->session->set_userdata($data_session);

        	redirect(site_url('my/apps'));

	    } else {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_37'));
            redirect(site_url('my/apps'));

	    }
	}

}