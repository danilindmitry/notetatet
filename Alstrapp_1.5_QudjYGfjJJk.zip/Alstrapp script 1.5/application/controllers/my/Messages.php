<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Messages extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('messages_model');
    	$this->load->model('users_model');

		// ** Load libraries ** //
		$this->load->library('pagination');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check type app
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('messages', $user_lang);
    	$this->lang->load('layout', $user_lang);
   		$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * Index page - unread messages
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$data = array(
			"app"		=> $app
		);

    	$this->template->set('title', $this->lang->line('seo_9'));
		$this->template->load('cms', 'contents' , 'messages/index', $data);
	}

	/*
	 * All dialogues
	 */
	public function all()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_45'));
            redirect(site_url('my/apps'));

		}

		// init params
	    $params = array();
	    $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	    $total_records = $this->messages_model->get_total_dialogues($app->id);

	    // load config file
	    $this->config->load('pagination', TRUE);
	    $settings_pagination = $this->config->item('pagination');
	    $settings_pagination['total_rows'] = $this->messages_model->get_total_dialogues($app->id);
	    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/messages/all';

	    if ($total_records > 0)
		{
			// get current page records
			$params["dialogues"] = $this->messages_model->get_all_dialogues($settings_pagination['per_page'], $start_index, $app->id);
			             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
			             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

		$params["total_records"] = $total_records;
		$params["app"] = $app;

		$this->template->set('title', $this->lang->line('seo_9'));
		$this->template->load('cms', 'contents' , 'messages/all', $params);
	}

	/*
	 * Get list unread dialogues form AJAX request
	 */
	public function unread_dialogues()
	{
		header('Access-Control-Allow-Origin: *');

		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$response = array ('event' => 'fail', 'message' => $this->lang->line('alert_4'));
			echo json_encode($response);

		}

		$dialogues = $this->messages_model->get_dialogues($app->id);

		if ($dialogues) {

			$all_total_unread = $this->messages_model->get_total_unread_all($app->id);

			// check unread messages for dialogues
			foreach ($dialogues as $data) {

				$dialogue = $this->messages_model->get_dialogue_detail($data->id);

				$user = $this->template->get_user_fullname_for_form($dialogue->user);

				$last_message = $this->messages_model->get_dialogue_last_message($data->id);

				if ($last_message) {

					$data_unread[] = array("dialogue" => $data->id, "user" => $user, "count" => $this->messages_model->get_total_unread_for_request($app->id, $data->id), 'total' => $this->messages_model->get_total_all_for_request($app->id, $data->id), 'last_message' => mb_strimwidth($last_message->message, 0, 80, " ..."));

				} else {

					$data_unread[] = array("dialogue" => $data->id, "user" => $user, "count" => $this->messages_model->get_total_unread_for_request($app->id, $data->id));

				}

			}

			$total_dialogues = $this->messages_model->get_total_dialogues($app->id);

			$count_dialogues = $total_dialogues-1;

			$response = array ('event' => 'success', 'total_unread_message' => $all_total_unread, 'total_dialogues' => $count_dialogues, 'data' => $data_unread);

		    echo json_encode($response, JSON_FORCE_OBJECT);

		} else {

			$response = array ('event' => 'empty');
			echo json_encode($response);

		}
	}

	/*
	 * View dialogue
	 * @param int $dialogue_id
	 */
	public function view($dialogue_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($dialogue_id) OR ! is_numeric($dialogue_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_50'));
            redirect(site_url('my/apps/'.$app->id.'/messages'));

	    }

		$dialogue = $this->messages_model->get_dialogue_detail($dialogue_id);

		if ($dialogue) {

			$messages = $this->messages_model->get_messages($app->id, $dialogue->id);

			$unread_messages = $this->messages_model->get_messages_unread($app->id, $dialogue->id);

			if ($unread_messages) {

				foreach ($unread_messages as $datas) {

					// update read status
					$this->messages_model->update_message($datas->id, array(
				        "status"	=> 2
				        )
				    );

				}

			}

			$data = array(
				"app"		=> $app,
				"dialogue"	=> $dialogue,
				"messages"	=> $messages
			);

	    	$this->template->set('title', $this->lang->line('seo_9'));
			$this->template->load('cms', 'contents' , 'messages/view', $data);

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_51'));
            redirect(site_url('my/apps/'.$app->id.'/messages'));

		}

	}

	/*
	 * Add message
	 * @param int $dialogue_id
	 */
	public function create_message($dialogue_id)
	{
		header('Access-Control-Allow-Origin: *');

		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			$response = array ('event' => 'fail', 'message' => $this->lang->line('alert_4'));
			echo json_encode($response);

		}

		if (is_null($dialogue_id) OR ! is_numeric($dialogue_id)) {

	    	$response = array ('event' => 'fail', 'message' => $this->lang->line('alert_50'));
			echo json_encode($response);

	    }

	    $dialogue = $this->messages_model->get_dialogue_detail($dialogue_id);

	    if ($dialogue) {

	    	$this->form_validation->set_rules('message', "Message", 'trim|required|min_length[2]');

			if ($this->form_validation->run() == false) {

		        $response = array ('event' => 'fail', 'message' => $this->lang->line('alert_52'));
				echo json_encode($response);

		    } else {

		    	// set variable for input data
		        $message = $this->input->post("message", true);

		        $date = date('Y-m-d H:i:s');

		        $this->messages_model->add_message(array(
				    "app_id"		=> $app->id,
				    "dialogue"		=> $dialogue->id,
				    "user"			=> 0,
				    "type"			=> 1,
				    "created"		=> $date,
				    "message"		=> $message,
				    "status"		=> 1
				    )
				);

				$response = array ('event' => 'success', 'message' => $message, 'created' => $date);
				echo json_encode($response);

		    }

	    } else {

	    	$response = array ('event' => 'fail', 'message' => $this->lang->line('alert_51'));
			echo json_encode($response);

	    }
	}

	/*
	 * Check new messages for dialogue
	 * @param int $dialogue_id
	 */
	public function check_new_messages($dialogue_id)
	{
		header('Access-Control-Allow-Origin: *');

		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			$response = array ('event' => 'fail', 'message' => $this->lang->line('alert_4'));
			echo json_encode($response);

		}

		if (is_null($dialogue_id) OR ! is_numeric($dialogue_id)) {

	    	$response = array ('event' => 'fail', 'message' => $this->lang->line('alert_50'));
			echo json_encode($response);

	    }

	    $dialogue = $this->messages_model->get_dialogue_detail($dialogue_id);

	    if ($dialogue) {

	    	// get unread messages
	    	$messages = $this->messages_model->get_messages_unread($app->id, $dialogue->id);

	    	if ($messages) {

	    		$count = $this->messages_model->get_total_unread_for_request($app->id, $dialogue->id);

	    		$total = $count - 1;

	    		foreach ($messages as $datas) {

					// update read status
					$this->messages_model->update_message($datas->id, array(
				        "status"	=> 2
				        )
				    );

				}

	    		$response = array ('event' => 'success', 'count' => $total, 'data' => $messages);

		    	echo json_encode($response, JSON_FORCE_OBJECT);

	    	} else {

	    		$response = array ('event' => 'empty');
				echo json_encode($response);

	    	}

	    } else {

	    	$response = array ('event' => 'fail', 'message' => $this->lang->line('alert_51'));
			echo json_encode($response);

	    }
	}

	/*
	 * Clear chat
	 * @param int $dialogue_id
	 */
	public function clear_chat($dialogue_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($dialogue_id) OR ! is_numeric($dialogue_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_50'));
            redirect(site_url('my/apps/'.$app->id.'/messages'));

	    }

		$dialogue = $this->messages_model->get_dialogue_detail($dialogue_id);

		if ($dialogue) {

			$items = $this->messages_model->get_messages_for_delete($dialogue->id);

			if ($items) {

				$this->messages_model->del_all_messages($items);

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/apps/'.$app->id.'/messages/view/'.$dialogue->id.''));


			} else {

				$this->session->set_flashdata('error', $this->lang->line('alert_53'));
            	redirect(site_url('my/apps/'.$app->id.'/messages/view/'.$dialogue->id.''));

			}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_51'));
            redirect(site_url('my/apps/'.$app->id.'/messages'));

		}
	}

	/*
	 * Block user for chat
	 * @param int $dialogue_id
	 */
	public function user_ban($dialogue_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($dialogue_id) OR ! is_numeric($dialogue_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_50'));
            redirect(site_url('my/apps/'.$app->id.'/messages'));

	    }

		$dialogue = $this->messages_model->get_dialogue_detail($dialogue_id);

		if ($dialogue) {

			if ($dialogue->ban == 1) {

				$this->messages_model->update_dialogue($dialogue->id, array(
		            "ban"	=> 2
		            )
		        );

		        $this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/apps/'.$app->id.'/messages/view/'.$dialogue->id.''));

			} else {

				$this->session->set_flashdata('error', $this->lang->line('alert_54'));
            	redirect(site_url('my/apps/'.$app->id.'/messages/view/'.$dialogue->id.''));

			}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_51'));
            redirect(site_url('my/apps/'.$app->id.'/messages'));

		}
	}

	/*
	 * Unblock user for chat
	 * @param int $dialogue_id
	 */
	public function user_unban($dialogue_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($dialogue_id) OR ! is_numeric($dialogue_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_50'));
            redirect(site_url('my/apps/'.$app->id.'/messages'));

	    }

		$dialogue = $this->messages_model->get_dialogue_detail($dialogue_id);

		if ($dialogue) {

			if ($dialogue->ban == 2) {

				$this->messages_model->update_dialogue($dialogue->id, array(
		            "ban"	=> 1
		            )
		        );

		        $this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/apps/'.$app->id.'/messages/view/'.$dialogue->id.''));

			} else {

				$this->session->set_flashdata('error', $this->lang->line('alert_54'));
            	redirect(site_url('my/apps/'.$app->id.'/messages/view/'.$dialogue->id.''));

			}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_51'));
            redirect(site_url('my/apps/'.$app->id.'/messages'));

		}
	}

	/*
	 * Create dialogue
	 */
	public function create_dialogue()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$data = array(
			"app"		=> $app
		);

    	$this->template->set('title', $this->lang->line('seo_9'));
		$this->template->load('cms', 'contents' , 'messages/create', $data);
	}

	/*
	 * Add dialogue
	 */
	public function add_dialogue()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('username', "Username", 'trim|required|max_length[50]|min_length[3]|alpha_numeric');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/messages/create_dialogue'));

        } else {

        	// set variable for input data
        	$username = $this->input->post("username", true);

        	$user = $this->users_model->get_user_from_username($username);

        	if ($user) {

        		$dialogue = $this->messages_model->get_dialogue_detail_from_user($user->id);

        		if (!$dialogue) {

        			$date = date('Y-m-d H:i:s');

        			// generate token
					$value_1 = rand(0000000000, 5555555555);
					$value_2 = rand(1111111111, 9999999999);
					$token = hash('sha256', $date."-".$value_1."-".$value_2);

        			$id = $this->messages_model->add_dialogue(array(
					    "app_id"		=> $app->id,
					    "token"			=> $token,
					    "user"			=> $user->id,
					    "ban"			=> 1
					    )
					);

					redirect(site_url('my/apps/'.$app->id.'/messages/view/'.$id.''));

        		} else {

        			$this->session->set_flashdata('error', ''.$this->lang->line('alert_55').' <a href="'.base_url('my/apps/'.$app->id.'/messages/view/'.$dialogue->id.'').'" class="alert-link">'.$this->lang->line('alert_56').'</a>');
            		redirect(site_url('my/apps/'.$app->id.'/messages/create_dialogue'));

        		}

        	} else {

        		$this->session->set_flashdata('error', $this->lang->line('alert_57'));
            	redirect(site_url('my/apps/'.$app->id.'/messages/create_dialogue'));

        	}

        }
	}

	/*
	 * Search messages
	 */
	public function search()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (!isset($_GET['search'])) { // search page

			$data = array(
				"app"		=> $app
			);

	    	$this->template->set('title', $this->lang->line('seo_9'));
			$this->template->load('cms', 'contents' , 'messages/search', $data);

		} else {

			$search = $this->security->xss_clean($_GET['search']);

			// init params
        	$params = array();
        	$start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        	$total_records = $this->messages_model->get_total($app->id, $search);

        	// load config file
	        $this->config->load('pagination', TRUE);
	        $settings_pagination = $this->config->item('pagination');
	        $settings_pagination['total_rows'] = $this->messages_model->get_total($app->id, $search);
	        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/messages/search';

	        if ($total_records > 0)
			{
			    // get current page records
			    $params["messages"] = $this->messages_model->get_all_messages_for_search($settings_pagination['per_page'], $start_index, $app->id, $search);
			             
			    // use the settings to initialize the library
			    $this->pagination->initialize($settings_pagination);
			             
			    // build paging links
			    $params["links"] = $this->pagination->create_links();
			}

			$params["total_records"] = $total_records;
			$params["app"] = $app;

			$this->template->set('title', $this->lang->line('seo_9'));
			$this->template->load('cms', 'contents' , 'messages/search', $params);

		}

	}

}