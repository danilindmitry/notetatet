<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('auth_model');

    	// ** Load libraries ** //
		$this->load->library('protect');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('account', $user_lang);
    $this->lang->load('layout', $user_lang);
    $this->lang->load('alert', $user_lang);
    $this->lang->load('seo', $user_lang);

	}

	/*
	 * Index page
	 */
	public function index()
	{
		$admin = $this->auth_model->get_admin_from_id($_SESSION['id']);

		$data = array(
			"admin"	=> $admin
		);

    	$this->template->set('title', $this->lang->line('seo_1'));
		$this->template->load('apps', 'contents' , 'account/index', $data);
	}

	/*
	 * Index page
	 */
	public function update_account()
	{
		$admin = $this->auth_model->get_admin_from_id($_SESSION['id']);

		$this->form_validation->set_rules('email', "Email address", 'trim|required|max_length[50]|valid_email');
		$this->form_validation->set_rules('password', "Password", 'trim|max_length[150]|alpha_numeric');
		$this->form_validation->set_rules('repassword', "Repeat password", 'trim|matches[password]|alpha_numeric');
		$this->form_validation->set_rules('question', "Password reset question", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('answer', "Answer to secret password reset question", 'trim|required|max_length[100]|min_length[2]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/account'));

        } else {

        	// set variable for input data
        	$email = $this->input->post("email", true);
        	$password = $this->input->post("password", true);
        	$repassword = $this->input->post("repassword", true);
        	$question = $this->input->post("question", true);
        	$answer = $this->input->post("answer", true);

        	if (empty($password)) {

        		// without password
        		$this->auth_model->update_admin($admin->id, array(
		            "email"				=> $email,
		            "reset_question"	=> $question,
		            "reset_answer"		=> $answer
		            )
		        );

        	} else {

        		// change password
      			$stamp_pass = $this->protect->encrypt($password);

        		$this->auth_model->update_admin($admin->id, array(
        			"password"			=> $stamp_pass,
		            "email"				=> $email,
		            "reset_question"	=> $question,
		            "reset_answer"		=> $answer
		            )
		        );

        	}

        	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/account'));

        }

	}

}