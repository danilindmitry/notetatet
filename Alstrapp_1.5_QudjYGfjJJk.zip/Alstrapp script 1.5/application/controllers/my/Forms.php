<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forms extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('forms_model');

		// ** Load libraries ** //
		$this->load->library('samples');
		$this->load->library('pagination');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check type app
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if ($app->type) {

			redirect(site_url('my/apps'));

		}


		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('forms', $user_lang);
    	$this->lang->load('layout', $user_lang);
    	$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * Index page
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		// Check search value
		if (!isset($_GET['search'])) {
		          
		    $search = null;
		          
		} else {
		          
		    $search = $this->security->xss_clean($_GET['search']);
		          
		}

		// init params
	    $params = array();
	    $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	    $total_records = $this->forms_model->get_total($app->id, $search);

	    // load config file
	    $this->config->load('pagination', TRUE);
	    $settings_pagination = $this->config->item('pagination');
	    $settings_pagination['total_rows'] = $this->forms_model->get_total($app->id, $search);
	    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/forms/index';

	    if ($total_records > 0)
		{
			// get current page records
			$params["forms"] = $this->forms_model->get_forms($settings_pagination['per_page'], $start_index, $app->id, $search);
			             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
			             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

		$params["total_records"] = $total_records;
		$params["app"] = $app;

    	$this->template->set('title', $this->lang->line('seo_7'));
		$this->template->load('cms', 'contents' , 'forms/index', $params);
	}

	/*
	 * Received forms
	 * @param int $form_id
	 */
	public function inbox($form_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		// Check search value
		if (!isset($_GET['search'])) {
		          
		    $search = null;
		          
		} else {
		          
		    $search = $this->security->xss_clean($_GET['search']);
		          
		}

		if (is_null($form_id) OR ! is_numeric($form_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_12'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }

	    $form = $this->forms_model->get_form($form_id);

	    if ($form) {

	    	// all received
			if (!isset($_GET['sort'])) {

				// init params
			    $params = array();
			    $start_index = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0;
			    $total_records = $this->forms_model->get_total_received($app->id, $form->id, $search);

			    // load config file
			    $this->config->load('pagination', TRUE);
			    $settings_pagination = $this->config->item('pagination');
			    $settings_pagination['total_rows'] = $this->forms_model->get_total_received($app->id, $form->id, $search);
			    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/forms/inbox/'.$form->id.'';

			    if ($total_records > 0)
				{
					// get current page records
					$params["forms_received"] = $this->forms_model->get_forms_inbox($settings_pagination['per_page'], $start_index, $app->id, $form->id, $search);
					             
					// use the settings to initialize the library
					$this->pagination->initialize($settings_pagination);
					             
					// build paging links
					$params["links"] = $this->pagination->create_links();
				}

				$params["total_records"] = $total_records;
				$params["app"] = $app;
				$params["form"] = $form;

    			$this->template->set('title', $this->lang->line('seo_7'));
				$this->template->load('cms', 'contents' , 'forms/inbox', $params);

			} else {

				// unread received
				if ($_GET['sort'] == 'unread') {

					// init params
				    $params = array();
				    $start_index = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0;
				    $total_records = $this->forms_model->get_total_received_unread($app->id, $form->id, $search);

				    // load config file
				    $this->config->load('pagination', TRUE);
				    $settings_pagination = $this->config->item('pagination');
				    $settings_pagination['total_rows'] = $this->forms_model->get_total_received_unread($app->id, $form->id, $search);
				    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/forms/inbox/'.$form->id.'';

				    if ($total_records > 0)
					{
						// get current page records
						$params["forms_received"] = $this->forms_model->get_forms_inbox_unread($settings_pagination['per_page'], $start_index, $app->id, $form->id, $search);
						             
						// use the settings to initialize the library
						$this->pagination->initialize($settings_pagination);
						             
						// build paging links
						$params["links"] = $this->pagination->create_links();
					}

					$params["total_records"] = $total_records;
					$params["app"] = $app;
					$params["form"] = $form;

	    			$this->template->set('title', $this->lang->line('seo_7'));
					$this->template->load('cms', 'contents' , 'forms/inbox_unread', $params);

				} else if ($_GET['sort'] == 'search') {

					$data = array(
						"app"	=>  $app,
						"form"	=>  $form
					);

			    	$this->template->set('title', $this->lang->line('seo_7'));
					$this->template->load('cms', 'contents' , 'forms/inbox_search', $data);

				} else {

					// unknown request
	    			$this->session->set_flashdata('error', $this->lang->line('alert_38'));
            		redirect(site_url('my/apps/'.$app->id.'/forms'));

				}

			}

	    } else {

	    	// empry form
	    	$this->session->set_flashdata('error', $this->lang->line('alert_39'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }
	}

	/*
	 * Delete form result
	 * @param int $id
	 */
	public function delete_form_result($id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_12'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }

	    $form_result = $this->forms_model->get_form_received($id);

	    if ($form_result) {

	    	$this->forms_model->del_form_received($form_result->id);

	    	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/apps/'.$app->id.'/forms/inbox/'.$form_result->form_id.''));

	    } else {

	    	// empty
	    	$this->session->set_flashdata('error', $this->lang->line('alert_40'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }
	}

	/*
	 * Detail inbox form
	 * @param int $id
	 */
	public function detail_inbox($id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$detail = $this->forms_model->get_form_received($id);

		if ($detail) {

			$form_elements = $this->forms_model->get_form_elements($app->id, $detail->form_id);

			$json_array = json_decode($detail->result, true);

			if ($detail->status == 2) {

				// update status
				$this->forms_model->update_form_received($detail->id, array(
				    "status"	=> 1
				    )
				);

			}

			$data = array(
				"app"			=>  $app,
				"detail"		=>  $detail,
				"json_array"	=>  $json_array,
				"form_elements"	=>  $form_elements
			);

	    	$this->template->set('title', $this->lang->line('seo_7'));
			$this->template->load('cms', 'contents' , 'forms/inbox_detail', $data);

		} else {

			// empry
			$this->session->set_flashdata('error', $this->lang->line('alert_40'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

		}

	}

	/*
	 * Create form
	 */
	public function create_form()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[150]|min_length[3]');

		if ($this->form_validation->run() == false) {

	        $this->session->set_flashdata('error', validation_errors());
	        redirect(site_url('my/apps/'.$app->id.'/forms'));

	    } else {

	    	// set variable for input data
	        $name = $this->input->post("name", true);

	        $form_id = $this->forms_model->add_form(array(
			    "app_id"	=> $app->id,
			    "created"	=> date('Y-m-d H:i:s'),
			    "name"		=> $name,
			    )
			);

		    redirect(site_url('my/apps/'.$app->id.'/forms/builder/'.$form_id.''));

	    }
	}

	/*
	 * Update form
	 * @param int $form_id
	 */
	public function update_form($form_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($form_id) OR ! is_numeric($form_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_12'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }

	    $form = $this->forms_model->get_form($form_id);

	    if ($form) {

	    	$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[150]|min_length[3]');

			if ($this->form_validation->run() == false) {

		        $this->session->set_flashdata('error', validation_errors());
		        redirect(site_url('my/apps/'.$app->id.'/forms'));

		    } else {

		    	// set variable for input data
		        $name = $this->input->post("name", true);

		        $this->forms_model->update_form($form->id, array(
				    "name"		=> $name,
				    )
				);

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
				redirect(site_url('my/apps/'.$app->id.'/forms'));

		    }

	    } else {

	    	// empty form
	    	$this->session->set_flashdata('error', $this->lang->line('alert_39'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }
	}

	/*
	 * Delete form
	 * @param int $form_id
	 */
	public function delete_form($form_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($form_id) OR ! is_numeric($form_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_12'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }

	    $form = $this->forms_model->get_form($form_id);

	    if ($form) {

	    	$elements = $this->forms_model->get_form_items_for_delete($form->id);

	    	$received_forms = $this->forms_model->get_form_received_for_delete($form->id);

	    	$this->forms_model->del_form($form->id);

	    	if ($elements) {

	    		$this->forms_model->del_all_form_elements($elements);

	    	}

	    	if ($received_forms) {

	    		$this->forms_model->del_all_form_received($received_forms);

	    	}

	    	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    } else {

	    	// empty form
	    	$this->session->set_flashdata('error', $this->lang->line('alert_39'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }
	}

	/*
	 * Form builder view page
	 * @param int $form_id
	 */
	public function builder($form_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($form_id) OR ! is_numeric($form_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_12'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }

	    $form = $this->forms_model->get_form($form_id);

	    if ($form) {

	    	$form_elements = $this->forms_model->get_form_elements($app->id, $form_id);

	    	$data = array(
				"app"			=>  $app,
				"form"			=>  $form,
				"form_elements"	=>  $form_elements
			);

			$this->template->set('title', $this->lang->line('seo_7'));
			$this->template->load('cms', 'contents' , 'forms/builder', $data);

	    } else {

	    	// empty form
	    	$this->session->set_flashdata('error', $this->lang->line('alert_39'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }
	}

	/*
	 * Create form element
	 * @param int $form_id
	 */
	public function create_element($form_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($form_id) OR ! is_numeric($form_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_12'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }

	    $form = $this->forms_model->get_form($form_id);

	    if ($form) {

		    $this->form_validation->set_rules('name', "Name", 'trim|required|max_length[150]');
	        $this->form_validation->set_rules('prefix', "Prefix", 'trim|required|max_length[150]|alpha_numeric');
	        $this->form_validation->set_rules('type', "Type input", 'trim|required|numeric|in_list[1,2,3,4,5,6,7,8,9,10]');
	        $this->form_validation->set_rules('required', "Required type", 'trim|required|numeric|in_list[1,2]');

	        if ($this->input->post("type") == 6) {

	            $this->form_validation->set_rules('menu_link_count', "Counter oprions", 'trim|required|numeric');
	            $this->form_validation->set_rules('option_item_1', "Option item", 'trim|required');

	        }

	        if ($this->input->post("type") == 8) {

	            $this->form_validation->set_rules('checkbox_count', "Counter checkbox", 'trim|required|numeric');
	            $this->form_validation->set_rules('checkbox_item_1', "Checkbox item", 'trim|required');

	        }

	        if ($this->input->post("type") == 10) {

	            $this->form_validation->set_rules('value', "Default value", 'trim|required|numeric');
	            $this->form_validation->set_rules('min', "Min value", 'trim|required|numeric');
	            $this->form_validation->set_rules('max', "Max value", 'trim|required|numeric');
	            $this->form_validation->set_rules('step', "Step value", 'trim|required|numeric');

	        }

	        if ($this->form_validation->run() == false) {

	            $this->session->set_flashdata('error', validation_errors());
	            redirect(site_url('my/apps/'.$app->id.'/forms/builder/'.$form->id.''));

	        } else {

	        	$name = $this->input->post("name", true);
	            $prefix = $this->input->post("prefix", true);
	            $type = $this->input->post("type", true);
	            $required = $this->input->post("required", true);

	            // Check uniqueness prefix
	            $uniqueness = $this->forms_model->get_form_uniqueness_prefix($app->id, $form_id, $prefix);

	            if (!$uniqueness) {

	            	if ($type == 1 or $type == 2 or $type == 3 or $type == 4 or $type == 5 or $type == 7 or $type == 9) {

	            		$code_element = $this->samples->generate_form_selement($type, $required, $prefix);

	            	} else if ($type == 6) {

	            		$options_count = intval($this->input->post("menu_link_count", true));

		                $options = array();

		                for ($i = 1; $i <= $options_count; $i++) {

		                    $option_item = $this->input->post("option_item_" . $i, true);

		                    $options[] = array("option" => $option_item,);

		                }

	            		$code_element = $this->samples->generate_extended_form_selement($type, $prefix, $options, $name);

	            	} else if ($type == 8) {

	            		$options_count = intval($this->input->post("checkbox_count", true));

		                $options = array();

		                for ($i = 1; $i <= $options_count; $i++) {

		                    $option_item = $this->input->post("checkbox_item_" . $i, true);

		                    $options[] = array("option" => $option_item,);

		                }

		                $code_element = $this->samples->generate_extended_form_selement($type, $prefix, $options, $name);

	            	} else if ($type == 10) {

	            		$values = array("value" =>  $this->input->post("value", true), "min" => $this->input->post("min", true), "max" => $this->input->post("max", true), "step" => $this->input->post("step", true));

	            		$code_element = $this->samples->generate_extended_form_selement($type, $prefix, $values, $name);

	            	}

	            	if ($code_element) {

	            		$this->forms_model->add_form_element(array(
						    "app_id"	=> $app->id,
						    "form_id"	=> $form->id,
						    "created"	=> date('Y-m-d H:i:s'),
						    "code"		=> $code_element,
						    "name"		=> $name,
						    "prefix"	=> $prefix,
						    "sort"		=> 0,
						    "type"		=> $type,
						    "required"	=> $required
						    )
						);

						$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	            		redirect(site_url('my/apps/'.$app->id.'/forms/builder/'.$form->id.''));

	            	} else {

	            		$this->session->set_flashdata('error', $this->lang->line('alert_41'));
	            		redirect(site_url('my/apps/'.$app->id.'/forms/builder/'.$form->id.''));

	            	}


	            } else {

	            	$this->session->set_flashdata('error', $this->lang->line('alert_42'));
	            	redirect(site_url('my/apps/'.$app->id.'/forms/builder/'.$form->id.''));

	            }

	        }

	    } else {

	    	// empty form
	    	$this->session->set_flashdata('error', $this->lang->line('alert_39'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }
	}

	/*
	 * Update sort form elements
	 * @param int $app_id
	 */
	public function update_sort_elements($app_id)
	{
		if (is_null($app_id) OR ! is_numeric($app_id)) {

	    } else {

	    	$app = $this->apps_model->get_app($app_id);

	    	if ($app) {

	    		$arrayItems = $_GET['item'];
        		$i = 0;

	    		foreach ($arrayItems as $value) {

		           $this->forms_model->update_form_elements($value, array(
		                "sort"   =>  $i
		                )
		            );

		            $i++;
		        }

	    	}

	    }
	}

	/*
	 * Delete form_elements
	 * @param int $element_id
	 */
	public function delete_form_elements($element_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($element_id) OR ! is_numeric($element_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_43'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }

	    $form_element = $this->forms_model->get_form_element($element_id);

	    if ($form_element) {

	    	$this->forms_model->del_form_element($form_element->id);

	    	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        redirect(site_url('my/apps/'.$app->id.'/forms/builder/'.$form_element->form_id.''));

	    } else {

	    	// empry element
	    	$this->session->set_flashdata('error', $this->lang->line('alert_44'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }
	}

	/*
	 * Update code for form element
	 * @param int $element_id
	 */
	public function update_code($element_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($element_id) OR ! is_numeric($element_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_43'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }

	    $form_element = $this->forms_model->get_form_element($element_id);

	    if ($form_element) {

	    	$this->form_validation->set_rules('code', "Code", 'trim|required|min_length[3]');

	    	if ($this->form_validation->run() == false) {

		        $this->session->set_flashdata('error', validation_errors());
		        redirect(site_url('my/apps/'.$app->id.'/forms/builder/'.$form_element->form_id.''));

		    } else {

		    	$code = $this->input->post("code");

		    	$this->forms_model->update_form_elements($form_element->id, array(
					"code"		=> $code,
					)
				);

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
		        redirect(site_url('my/apps/'.$app->id.'/forms/builder/'.$form_element->form_id.''));

		    }

	    } else {

	    	// empry element
	    	$this->session->set_flashdata('error', $this->lang->line('alert_44'));
            redirect(site_url('my/apps/'.$app->id.'/forms'));

	    }
	}

}