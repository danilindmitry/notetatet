<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('users_model');

		// ** Load libraries ** //
		$this->load->library('protect');
		$this->load->library('pagination');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check type app
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if ($app->type) {

			redirect(site_url('my/apps'));

		}
    
    	// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('users', $user_lang);
    	$this->lang->load('layout', $user_lang);
    	$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * All users list
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$groups_list = $this->users_model->get_groups_list($app->id);

		if (!isset($_GET['group'])) { // all users

			// Check search value
		    if (!isset($_GET['search'])) {
		          
		        $search = null;
		          
		    } else {
		          
		        $search = $this->security->xss_clean($_GET['search']);
		          
		    }

		    // init params
        	$params = array();
        	$start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        	$total_records = $this->users_model->get_total_users($app->id, $search);

        	// load config file
	        $this->config->load('pagination', TRUE);
	        $settings_pagination = $this->config->item('pagination');
	        $settings_pagination['total_rows'] = $this->users_model->get_total_users($app->id, $search);
	        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/users/index';

	        if ($total_records > 0)
			{
			    // get current page records
			    $params["users"] = $this->users_model->get_users($settings_pagination['per_page'], $start_index, $app->id, $search);
			             
			    // use the settings to initialize the library
			    $this->pagination->initialize($settings_pagination);
			             
			    // build paging links
			    $params["links"] = $this->pagination->create_links();
			}

			$params["total_records"] = $total_records;
			$params["app"] = $app;
			$params["groups_list"] = $groups_list;

			$this->template->set('title', $this->lang->line('seo_29'));
			$this->template->load('cms', 'contents' , 'users/index', $params);

		} else { // sort by group

			if (!is_numeric($_GET['group'])) {

		    	$this->session->set_flashdata('error', $this->lang->line('alert_78'));
	            redirect(site_url('my/apps/'.$app->id.'/users'));

		    }

			$group_id = $this->security->xss_clean($_GET['group']);

			// Check search value
			if (!isset($_GET['search'])) {
			          
			    $search = null;
			          
			} else {
			          
			    $search = $this->security->xss_clean($_GET['search']);
			          
			}

			// widthout group
			if ($group_id == 0) {

				// init params
	        	$params = array();
	        	$start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	        	$total_records = $this->users_model-> get_total_users_for_group($app->id, 0, $search);

	        	// load config file
		        $this->config->load('pagination', TRUE);
		        $settings_pagination = $this->config->item('pagination');
		        $settings_pagination['total_rows'] = $this->users_model-> get_total_users_for_group($app->id, 0, $search);
		        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/users/index';

		        if ($total_records > 0)
				{
				    // get current page records
				    $params["users"] = $this->users_model->get_users_for_group($settings_pagination['per_page'], $start_index, $app->id, 0, $search);
				             
				    // use the settings to initialize the library
				    $this->pagination->initialize($settings_pagination);
				             
				    // build paging links
				    $params["links"] = $this->pagination->create_links();
				 }

				$params["total_records"] = $total_records;
				$params["app"] = $app;
				$params["groups_list"] = $groups_list;

				$this->template->set('title', $this->lang->line('seo_29'));
				$this->template->load('cms', 'contents' , 'users/index', $params);

			} else {

				// group > 0
				$group = $this->users_model->get_group($group_id);

				if ($group) {

					// init params
		        	$params = array();
		        	$start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
		        	$total_records = $this->users_model-> get_total_users_for_group($app->id, $group->id, $search);

		        	// load config file
			        $this->config->load('pagination', TRUE);
			        $settings_pagination = $this->config->item('pagination');
			        $settings_pagination['total_rows'] = $this->users_model-> get_total_users_for_group($app->id, $group->id, $search);
			        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/users/index';

			        if ($total_records > 0)
					{
					    // get current page records
					    $params["users"] = $this->users_model->get_users_for_group($settings_pagination['per_page'], $start_index, $app->id, $group->id, $search);
					             
					    // use the settings to initialize the library
					    $this->pagination->initialize($settings_pagination);
					             
					    // build paging links
					    $params["links"] = $this->pagination->create_links();
					 }

					$params["total_records"] = $total_records;
					$params["app"] = $app;
					$params["groups_list"] = $groups_list;

					$this->template->set('title', $this->lang->line('seo_29'));
					$this->template->load('cms', 'contents' , 'users/index', $params);


				} else {

					// group not found
					$this->session->set_flashdata('error', $this->lang->line('alert_79'));
            		redirect(site_url('my/apps/'.$app->id.'/users'));

				}

			}

		}

	}

	/*
	 * Users groups
	 */
	public function groups()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		// init params
        $params = array();
        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        $total_records = $this->users_model->get_total_groups($app->id);

        // load config file
        $this->config->load('pagination', TRUE);
        $settings_pagination = $this->config->item('pagination');
        $settings_pagination['total_rows'] = $this->users_model->get_total_groups($app->id);
        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/users/groups';

        if ($total_records > 0)
		{
		    // get current page records
		    $params["groups"] = $this->users_model->get_groups($settings_pagination['per_page'], $start_index, $app->id);
		             
		    // use the settings to initialize the library
		    $this->pagination->initialize($settings_pagination);
		             
		    // build paging links
		    $params["links"] = $this->pagination->create_links();
		 }

		$params["total_records"] = $total_records;
		$params["app"] = $app;

    	$this->template->set('title', $this->lang->line('seo_30'));
		$this->template->load('cms', 'contents' , 'users/groups', $params);
	}

	/*
	 * Add user view page
	 */
	public function add_user()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$groups_list = $this->users_model->get_groups_list($app->id);

		$data = array(
			"app"			=>  $app,
			"groups_list"	=>  $groups_list
		);

    	$this->template->set('title', $this->lang->line('seo_31'));
		$this->template->load('cms', 'contents' , 'users/add_user', $data);
	}

	/*
	 * Edit user view page
	 * @param int $id
	 */
	public function edit_user($id)
	{
		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_80'));
            redirect(site_url('my/apps'));

	    }

		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$groups_list = $this->users_model->get_groups_list($app->id);

		$user = $this->users_model->get_user($id);

		if ($user) {

			$data = array(
				"app"			=>  $app,
				"groups_list"	=>  $groups_list,
				"user"			=>  $user
			);

	    	$this->template->set('title', $this->lang->line('seo_32'));
			$this->template->load('cms', 'contents' , 'users/edit_user', $data);

		} else {

			// empty user
			$this->session->set_flashdata('error', $this->lang->line('alert_57'));
            redirect(site_url('my/apps/'.$app->id.'/users'));

		}

	}

	/*
	 * Create user
	 * @param int $app_id
	 */
	public function create_user($app_id)
	{
		if (is_null($app_id) OR ! is_numeric($app_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_2'));
            redirect(site_url('my/apps'));

	    }

		$app = $this->apps_model->get_app($app_id);

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('username', "Username", 'trim|required|max_length[50]|min_length[3]|alpha_numeric');
		$this->form_validation->set_rules('email', "Email", 'trim|required|max_length[100]|valid_email');
		$this->form_validation->set_rules('group', "User group", 'trim|required|numeric');
		$this->form_validation->set_rules('first_name', "First name", 'trim|required|max_length[50]|min_length[3]');
		$this->form_validation->set_rules('last_name', "Last name", 'trim|required|max_length[70]|min_length[3]');
		$this->form_validation->set_rules('password', "Password", 'trim|required|max_length[150]|min_length[5]|alpha_numeric');
		$this->form_validation->set_rules('repassword', "Repeat password", 'trim|required|matches[password]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/users/add_user'));

        } else {

        	// set variable for input data
        	$username = $this->input->post("username", true);
        	$email = $this->input->post("email", true);
        	$group = $this->input->post("group", true);
        	$first_name = $this->input->post("first_name", true);
        	$last_name = $this->input->post("last_name", true);
        	$password = $this->input->post("password", true);
        	$repassword = $this->input->post("repassword", true);

        	// check email uniqueness
        	$email_uniqueness = $this->users_model->get_user_from_email($email);

        	if (!$email_uniqueness) {

        		// generate HASH for password
      			$stamp_pass = $this->protect->encrypt($password);

      			// add userp
	            $this->users_model->add_user(array(
		            "app_id"		=> $app->id,
		            "username"		=> $username,
		            "password"		=> $stamp_pass,
		            "first_name"	=> $first_name,
		            "last_name"		=> $last_name,
		            "email"			=> $email,
		            "created"		=> date('Y-m-d H:i:s'),
		            "user_group"	=> $group,
                "block"	=> 1
		            )
		        );

	            $this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$app->id.'/users'));

        	} else {

        		// email already used
        		$this->session->set_flashdata('error', $this->lang->line('alert_81'));
            	redirect(site_url('my/apps/'.$app->id.'/users/add_user'));

        	}
        }
	}

	/*
	 * Update user
	 * @param int $user_id
	 */
	public function update_user($user_id)
	{
		if (is_null($user_id) OR ! is_numeric($user_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_2'));
            redirect(site_url('my/apps'));

	    }

		$user = $this->users_model->get_user($user_id);

		if (!$user) {

			// empty user
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('username', "Username", 'trim|required|max_length[50]|min_length[3]|alpha_numeric');
		$this->form_validation->set_rules('email', "Email", 'trim|required|max_length[100]|valid_email');
		$this->form_validation->set_rules('group', "User group", 'trim|required|numeric');
		$this->form_validation->set_rules('first_name', "First name", 'trim|required|max_length[50]|min_length[3]');
		$this->form_validation->set_rules('last_name', "Last name", 'trim|required|max_length[70]|min_length[3]');
		$this->form_validation->set_rules('password', "Password", 'trim|max_length[150]|alpha_numeric');
		$this->form_validation->set_rules('repassword', "Repeat password", 'trim|matches[password]|alpha_numeric');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/users/add_user'));

        } else {

        	// set variable for input data
        	$username = $this->input->post("username", true);
        	$email = $this->input->post("email", true);
        	$group = $this->input->post("group", true);
        	$first_name = $this->input->post("first_name", true);
        	$last_name = $this->input->post("last_name", true);
        	$password = $this->input->post("password", true);
        	$repassword = $this->input->post("repassword", true);

        	if ($user->email != $email) {

        		// check email uniqueness
        		$email_uniqueness = $this->users_model->get_user_from_email($email);

        		if ($email_uniqueness) {

        			$this->session->set_flashdata('error', $this->lang->line('alert_82'));
	        		redirect(site_url('my/apps/'.$user->app_id.'/users/edit_user/'.$user->id.''));

        		}

        	}

        	if (empty($password)) {

        		// widthout password
	            $this->users_model->update_user($user->id, array(
		            "username"		=> $username,
		            "first_name"	=> $first_name,
		            "last_name"		=> $last_name,
		            "email"			=> $email,
		            "user_group"	=> $group,
		            )
		        );

	            $this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$user->app_id.'/users/edit_user/'.$user->id.''));


        	} else {

        		// change password
      			$stamp_pass = $this->protect->encrypt($password);

      			// update user
	            $this->users_model->update_user($user->id, array(
		            "username"		=> $username,
		            "password"		=> $stamp_pass,
		            "first_name"	=> $first_name,
		            "last_name"		=> $last_name,
		            "email"			=> $email,
		            "user_group"	=> $group,
		            )
		        );

	            $this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$user->app_id.'/users/edit_user/'.$user->id.''));

        	}
        }
	}

	/*
	 * Delete user
	 * @param int $user_id
	 */
	public function delete_user($user_id)
	{
		if (is_null($user_id) OR ! is_numeric($user_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_78'));
            redirect(site_url('my/apps'));

	    }
	    
		$user = $this->users_model->get_user($user_id);

		if ($user) {

	    	// delete app in database
	    	$this->users_model->del_user($user->id);

	    	$this->session->set_flashdata('success', $this->lang->line('alert_3'));
        	redirect(site_url('my/apps/'.$user->app_id.'/users'));

	    } else {

	    	// empty user
	    	$this->session->set_flashdata('error', $this->lang->line('alert_57'));
            redirect(site_url('my/apps/'.$user->app_id.'/users'));

	    }

	}

	/*
	 * Create group
	 * @param int $app_id
	 */
	public function create_group($app_id)
	{
		if (is_null($app_id) OR ! is_numeric($app_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_2'));
            redirect(site_url('my/apps'));

	    }

		$app = $this->apps_model->get_app($app_id);

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[150]|min_length[3]');

        if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/users/groups'));

        } else {

        	// set variable for input data
        	$name = $this->input->post("name", true);

        	// add user group
            $this->users_model->add_group(array(
	            "app_id"    => $app->id,
	            "created"   => date('Y-m-d H:i:s'),
	            "name"    	=> $name,
	            )
	        );

            $this->session->set_flashdata('success', $this->lang->line('alert_1'));
        	redirect(site_url('my/apps/'.$app->id.'/users/groups'));

        }
	}

	/*
	 * Delete group
	 * @param int $group_id
	 */
	public function delete_group($group_id)
	{
		if (is_null($group_id) OR ! is_numeric($group_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_78'));
            redirect(site_url('my/apps'));

	    }
	    
		$group = $this->users_model->get_group($group_id);

		if ($group) {

			// check users in group
			$checking = $this->users_model->get_users_in_group($group_id);

			if (!$checking) {

				// delete app in database
	    		$this->users_model->del_group($group->id);

	    		$this->session->set_flashdata('success', $this->lang->line('alert_3'));
        		redirect(site_url('my/apps/'.$group->app_id.'/users/groups'));

			} else {

				// not empty group
	    		$this->session->set_flashdata('error', $this->lang->line('alert_83'));
            	redirect(site_url('my/apps/'.$group->app_id.'/users/groups'));

			}

	    } else {

	    	// empty group
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps/'.$group->app_id.'/users/groups'));

	    }

	}

	/*
	 * Update group
	 * @param int $group_id
	 */
	public function update_group($group_id)
	{
		if (is_null($group_id) OR ! is_numeric($group_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_78'));
            redirect(site_url('my/apps'));

	    }

	    $group = $this->users_model->get_group($group_id);

		if ($group) {

			$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[150]|min_length[3]');

	        if ($this->form_validation->run() == false) {

	            $this->session->set_flashdata('error', validation_errors());
	            redirect(site_url('my/apps/'.$group->app_id.'/users/groups'));

	        } else {

	        	// set variable for input data
	        	$name = $this->input->post("name", true);

	        	// update user group
	            $this->users_model->update_group($group->id, array(
		            "name"	=> $name,
		            )
		        );

	            $this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$group->app_id.'/users/groups'));

	        }

	    } else {

	    	// empty group
	    	$this->session->set_flashdata('error', $this->lang->line('alert_79'));
            redirect(site_url('my/apps/'.$group->app_id.'/users/groups'));

	    }

	}

}