<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Comments extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('comments_model');
    	$this->load->model('posts_model');
    	$this->load->model('template_model');
    	$this->load->model('users_model');

		// ** Load libraries ** //
		$this->load->library('pagination');
		$this->load->library('send_email');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// check type app
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		// ** Load language ** //
		$this->lang->load('comments', $user_lang);
    	$this->lang->load('layout', $user_lang);
    	$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * Index page
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		// Check search value
		if (!isset($_GET['search'])) {
		          
		    $search = null;
		          
		} else {
		          
		    $search = $this->security->xss_clean($_GET['search']);
		          
		}

		if (!isset($_GET['status'])) { // all comments

			$params = array();
	        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	        $total_records = $this->comments_model->get_total($app->id, $search);

	        // load config file
	        $this->config->load('pagination', TRUE);
	        $settings_pagination = $this->config->item('pagination');
	        $settings_pagination['total_rows'] = $this->comments_model->get_total($app->id, $search);
	        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/comments/index';

	        if ($total_records > 0)
			{
			    // get current page records
			    $params["comments"] = $this->comments_model->get_comments($settings_pagination['per_page'], $start_index, $app->id, $search);
			             
			    // use the settings to initialize the library
			    $this->pagination->initialize($settings_pagination);
			             
			    // build paging links
			    $params["links"] = $this->pagination->create_links();
			}

			$params["total_records"] = $total_records;
			$params["app"] = $app;

			$this->template->set('title', $this->lang->line('seo_4'));
			$this->template->load('cms', 'contents' , 'comments/index', $params);

		} else {

			// sort by status
			if ($_GET['status'] == 1 or $_GET['status'] == 2) {

		    	$params = array();
	        	$start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	        	$total_records = $this->comments_model->get_total_for_status($app->id, $_GET['status']);

	        	// load config file
	        	$this->config->load('pagination', TRUE);
	        	$settings_pagination = $this->config->item('pagination');
	        	$settings_pagination['total_rows'] = $this->comments_model->get_total_for_status($app->id, $_GET['status']);
	        	$settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/comments/index';

	        	if ($total_records > 0)
				{
				    // get current page records
				    $params["comments"] = $this->comments_model->get_comments_for_status($settings_pagination['per_page'], $start_index, $app->id, $_GET['status']);
				             
				    // use the settings to initialize the library
				    $this->pagination->initialize($settings_pagination);
				             
				    // build paging links
				    $params["links"] = $this->pagination->create_links();
				}

				$params["total_records"] = $total_records;
				$params["app"] = $app;

				$this->template->set('title', $this->lang->line('seo_4'));
				$this->template->load('cms', 'contents' , 'comments/index', $params);

		    } else {

		    	// empry status
		    	$this->session->set_flashdata('error', $this->lang->line('alert_17'));
	            redirect(site_url('my/apps/'.$app->id.'/comments'));

		    }

		}

	}

	/*
	 * View all comments for post
	 * @param int $post_id
	 */
	public function view($post_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($post_id) OR ! is_numeric($post_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_18'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }

	    $post = $this->posts_model->get_post($post_id);

	    if ($post) {

	    	// get all comments list
	    	$comments = $this->comments_model->get_comments_for_view($app->id, $post->id);

	    	$data = array(
				"app"		=> $app,
				"post"		=> $post,
				"comments"	=> $comments
			);

			$this->template->set('title', $this->lang->line('seo_4'));
			$this->template->load('cms', 'contents' , 'comments/view', $data);

	    } else {

	    	// empry post
	    	$this->session->set_flashdata('error', $this->lang->line('alert_19'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }

	}

	/*
	 * Create comment
	 * @param int $post_id
	 */
	public function create_comment($post_id)
	{

		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($post_id) OR ! is_numeric($post_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_18'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }

	    $post = $this->posts_model->get_post($post_id);

	    if ($post) {

	    	$this->form_validation->set_rules('comment', "Comments", 'trim|required|max_length[500]|min_length[3]');
	    	$this->form_validation->set_rules('comment_id', "Comment ID", 'trim|required|numeric');

	    	if ($this->form_validation->run() == false) {

		        $this->session->set_flashdata('error', validation_errors());
		        redirect(site_url('my/apps/'.$app->id.'/comments/view/'.$post->id.''));

		    } else {

		    	// set variable for input data
		        $comment = $this->input->post("comment", true);
		        $comment_id = $this->input->post("comment_id", true);
		        $date = date('Y-m-d H:i:s');

		        $this->comments_model->add_comment(array(
				    "app_id"		=> $app->id,
				    "post_id"		=> $post_id,
				    "created"		=> $date,
				    "user"			=> 0,
				    "comment"		=> $comment,
				    "type"			=> 2,
				    "reply_id"		=> $comment_id,
				    "status"		=> 1
				    )
				);

		        // send email notification
		        $email_template = $this->template_model->get_email_template(3);

		        if ($email_template->status == 1) {

		        	$user_comment = $this->comments_model->get_comment($comment_id);

		        	if ($user_comment) {

		        		$user = $this->users_model->get_user($user_comment->user);

		        		if ($user) {

		        			$message = $email_template->message;
				        	$email_variables = array('[POST]', '[DATE]', '[ADMIN_COMMENT]', '[APPNAME]');
				        	$code_variable = array($post->name, $date, $comment, $app->name);
				        	$replace = str_replace($email_variables, $code_variable, $message);

				        	$this->send_email->start_send($app->id, $user->email, $email_template->title, $replace);

		        		}

		        	}

		        }

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
		    	redirect(site_url('my/apps/'.$app->id.'/comments/view/'.$post->id.''));

		    }

	    } else {

	    	// empry post
	    	$this->session->set_flashdata('error', $this->lang->line('alert_19'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }
	}

	/*
	 * Delete comment
	 * @param int $comment_id
	 */
	public function delete_comment($comment_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($comment_id) OR ! is_numeric($comment_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_20'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }

	    $comment = $this->comments_model->get_comment($comment_id);

	    if ($comment) {

	    	$reply = $this->comments_model->get_reply_for_delete($comment->id);

	    	if (!$reply) {

	    		// one delete
	    		$this->comments_model->del_comment($comment->id);

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/apps/'.$app->id.'/comments'));

	    	} else {

	    		// delete comment and reply
	    		$this->comments_model->del_all_reply($reply);

	    		$this->comments_model->del_comment($comment->id);

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/apps/'.$app->id.'/comments'));

	    	}

	    } else {

	    	// empry comment
	    	$this->session->set_flashdata('error', $this->lang->line('alert_21'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }
	}

	/*
	 * Unpublish comment
	 * @param int $comment_id
	 */
	public function unpublish($comment_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($comment_id) OR ! is_numeric($comment_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_20'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }

	    $comment = $this->comments_model->get_comment($comment_id);

	    if ($comment) {

	    	if ($comment->status == 1) {

	    		$this->comments_model->update_comment($comment->id, array(
		            "status"	=> 2,
		            )
		        );

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$app->id.'/comments'));

	    	} else {

	    		// empry comment
	    		$this->session->set_flashdata('error', $this->lang->line('alert_22'));
            	redirect(site_url('my/apps/'.$app->id.'/comments'));

	    	}

	    } else {

	    	// empry comment
	    	$this->session->set_flashdata('error', $this->lang->line('alert_21'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }
	}

	/*
	 * Publish comment
	 * @param int $comment_id
	 */
	public function publish($comment_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($comment_id) OR ! is_numeric($comment_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_20'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }

	    $comment = $this->comments_model->get_comment($comment_id);

	    if ($comment) {

	    	if ($comment->status == 2) {

	    		$this->comments_model->update_comment($comment->id, array(
		            "status"	=> 1,
		            )
		        );

	    		$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$app->id.'/comments'));

	    	} else {

	    		// empry comment
	    		$this->session->set_flashdata('error', $this->lang->line('alert_23'));
            	redirect(site_url('my/apps/'.$app->id.'/comments'));

	    	}

	    } else {

	    	// empry comment
	    	$this->session->set_flashdata('error', $this->lang->line('alert_21'));
            redirect(site_url('my/apps/'.$app->id.'/comments'));

	    }
	}

}