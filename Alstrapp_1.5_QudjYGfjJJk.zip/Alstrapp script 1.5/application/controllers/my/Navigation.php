<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Navigation extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('navigation_model');
    	$this->load->model('users_model');
    	$this->load->model('posts_model');
    	$this->load->model('galleries_model');
    	$this->load->model('forms_model');

		// ** Load libraries ** //
		$this->load->library('pagination');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check type app
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('navigation', $user_lang);
    	$this->lang->load('layout', $user_lang);
    	$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * Start menu
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$main_items = $this->navigation_model->get_main_menu($app->id);

		$data = array(
			"app"			=>  $app,
			"main_items"	=>  $main_items
		);

    	$this->template->set('title', $this->lang->line('seo_10'));
		$this->template->load('cms', 'contents' , 'navigation/index', $data);
	}

	/*
	 * Auth menu
	 */
	public function auth()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$main_items = $this->navigation_model->get_auth_menu($app->id);

		$data = array(
			"app"			=>  $app,
			"main_items"	=>  $main_items
		);

    	$this->template->set('title', $this->lang->line('seo_10'));
		$this->template->load('cms', 'contents' , 'navigation/auth', $data);
	}

	/*
	 * User menu
	 */
	public function user()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$main_items = $this->navigation_model->get_user_menu($app->id);

		$data = array(
			"app"			=>  $app,
			"main_items"	=>  $main_items
		);

    	$this->template->set('title', $this->lang->line('seo_10'));
		$this->template->load('cms', 'contents' , 'navigation/user', $data);
	}

	/*
	 * Start menu
	 */
	public function create_item()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('name', "Item name", 'trim|required|max_length[150]|min_length[2]');
		$this->form_validation->set_rules('type', "Type", 'trim|required|numeric|in_list[1,2,3,4,5,6]');
		$this->form_validation->set_rules('icon_library', "Icons library", 'trim|required|numeric|in_list[1,2]');
		$this->form_validation->set_rules('icon', "Icon", 'trim|max_length[50]');
		$this->form_validation->set_rules('view', "View type", 'trim|required|numeric|in_list[1,2,3]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/navigation'));

        } else {

        	// set variable for input data
        	$name = $this->input->post("name", true);
        	$type = $this->input->post("type", true);
        	$icon_library = $this->input->post("icon_library", true);
        	$icon = $this->input->post("icon", true);
        	$view = $this->input->post("view", true);

        	if ($type == 6) {

        	} else {

        	}

        	// add item
	        $item = $this->navigation_model->add_main_item(array(
		        "app_id"		=> $app->id,
		        "view"			=> $view,
		        "type"			=> $type,
		        "icon_library"	=> $icon_library,
		        "icon"			=> $icon,
		        "name"			=> $name,
		        "status"		=> 1,
		        "sort"			=> 0
		        )
		    );

		    if ($type == 6) {

		    	$this->navigation_model->update_main_item($item, array(
				    "path" 		=> '/categories/'
				    )
				);

			}

	        $this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        redirect(site_url('my/apps/'.$app->id.'/navigation/build/'.$item.''));

        }
	}

	/*
	 * Build menu item
	 * @param int $id
	 */
	public function build($id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_58'));
            redirect(site_url('my/apps/'.$app->id.'/navigation'));

	    }

	    $item = $this->navigation_model->get_menu_detail($id);

	    if ($item) {

	    	$groups_list = $this->users_model->get_groups_list($app->id);

	    	if ($item->type == 1) { // external link

	    		$result = null;

	    		$data = array(
					"app"			=>  $app,
					"item"			=>  $item,
					"result"		=>  $result,
					"groups_list"	=>  $groups_list
				);

		    	$this->template->set('title', $this->lang->line('seo_10'));
				$this->template->load('cms', 'contents' , 'navigation/build', $data);

	    	} else if ($item->type == 2) { // post categories

	    		$result = $this->posts_model->get_categories_for_select($app->id);

	    		$data = array(
					"app"			=>  $app,
					"item"			=>  $item,
					"result"		=>  $result,
					"groups_list"	=>  $groups_list
				);

		    	$this->template->set('title', $this->lang->line('seo_10'));
				$this->template->load('cms', 'contents' , 'navigation/build', $data);

	    	} else if ($item->type == 3) { // posts

	    		// init params
		        $params = array();
		        $start_index = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0;
		        $total_records = $this->posts_model->get_total_active_posts($app->id);

		        // load config file
		        $this->config->load('pagination', TRUE);
		        $settings_pagination = $this->config->item('pagination');
		        $settings_pagination['total_rows'] = $this->posts_model->get_total_active_posts($app->id);
		        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/navigation/build/'.$item->id.'';

		        if ($total_records > 0)
				{
				    // get current page records
				    $params["result"] = $this->posts_model->get_active_posts($settings_pagination['per_page'], $start_index, $app->id);
				             
				    // use the settings to initialize the library
				    $this->pagination->initialize($settings_pagination);
				             
				    // build paging links
				    $params["links"] = $this->pagination->create_links();
				}

				$params["total_records"] = $total_records;
				$params["item"] = $item;
				$params["app"] = $app;
				$params["groups_list"] = $groups_list;

				$this->template->set('title', $this->lang->line('seo_10'));
				$this->template->load('cms', 'contents' , 'navigation/build', $params);

	    	} else if ($item->type == 4) { // gallery

	    		// init params
		        $params = array();
		        $start_index = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0;
		        $total_records = $this->galleries_model->get_total($app->id, 0);

		        // load config file
			    $this->config->load('pagination', TRUE);
			    $settings_pagination = $this->config->item('pagination');
			    $settings_pagination['total_rows'] = $this->galleries_model->get_total($app->id, 0);
			    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/navigation/build/'.$item->id.'';

			    if ($total_records > 0)
				{
					// get current page records
					$params["result"] = $this->galleries_model->get_galleries($settings_pagination['per_page'], $start_index, $app->id, 0);
					             
					// use the settings to initialize the library
					$this->pagination->initialize($settings_pagination);
					             
					// build paging links
					$params["links"] = $this->pagination->create_links();
				}

				$params["total_records"] = $total_records;
				$params["app"] = $app;
				$params["item"] = $item;
				$params["groups_list"] = $groups_list;

	    		$this->template->set('title', $this->lang->line('seo_10'));
				$this->template->load('cms', 'contents' , 'navigation/build', $params);

	    	} else if ($item->type == 5) { // forms

	    		$result = $this->forms_model->get_forms_for_select($app->id);

	    		$data = array(
					"app"			=>  $app,
					"item"			=>  $item,
					"result"		=>  $result,
					"groups_list"	=>  $groups_list
				);

		    	$this->template->set('title', $this->lang->line('seo_10'));
				$this->template->load('cms', 'contents' , 'navigation/build', $data);

	    	} else if ($item->type == 6) { // category list

	    		$result = null;

	    		$data = array(
					"app"			=>  $app,
					"item"			=>  $item,
					"result"		=>  $result,
					"groups_list"	=>  $groups_list
				);

		    	$this->template->set('title', $this->lang->line('seo_10'));
				$this->template->load('cms', 'contents' , 'navigation/build', $data);

	    	}

	    } else {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_59'));
            redirect(site_url('my/apps/'.$app->id.'/navigation'));

	    }
	}

	/*
	 * Update menu item
	 * @param int $id_item
	 */
	public function update_item($id_item)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($id_item) OR ! is_numeric($id_item)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_58'));
            redirect(site_url('my/apps/'.$app->id.'/navigation'));

	    }

	    $item = $this->navigation_model->get_menu_detail($id_item);

	    if ($item) {

	    	$this->form_validation->set_rules('name', "Item name", 'trim|required|max_length[150]|min_length[2]');
			$this->form_validation->set_rules('icon_library', "Icons library", 'trim|required|numeric|in_list[1,2]');
			$this->form_validation->set_rules('icon', "Icon", 'trim|max_length[50]');
			$this->form_validation->set_rules('rights', "Access rights", 'trim|required|numeric|in_list[0,1,2]');
			$this->form_validation->set_rules('group', "Users group", 'trim|required|numeric');

			if ($item->type == 1) {

				$this->form_validation->set_rules('path', "Link", 'trim|required|min_length[5]|valid_url');

			} else if ($item->type != 6) {

				$this->form_validation->set_rules('id', "ID item for select", 'trim|required|numeric');

			}

			if ($this->form_validation->run() == false) {

            	$this->session->set_flashdata('error', validation_errors());
            	redirect(site_url('my/apps/'.$app->id.'/navigation/build/'.$item->id.''));

        	} else {

        		// set variable for input data
	        	$name = $this->input->post("name", true);
	        	$icon_library = $this->input->post("icon_library", true);
	        	$icon = $this->input->post("icon", true);
	        	$rights = $this->input->post("rights", true);
		        $group = $this->input->post("group", true);

		        if ($item->type == 1) {

		        	$path = $this->input->post("path", true);

		        } else {

		        	$id = $this->input->post("id", true);

		        }

		        // generate link
		        if ($item->type == 1) {

		        	$link = $path;

		        } else if ($item->type == 2) {

		        	$link = '/category/'.$id;

		        } else if ($item->type == 3) {

		        	$link = '/post/'.$id;

		        } else if ($item->type == 4) {

		        	$link = '/gallery/'.$id;

		        } else if ($item->type == 5) {

		        	$link = '/form/'.$id;

		        } else if ($item->type == 6) {

		        	$link = '/categories/'.$id;

		        }

		        $this->navigation_model->update_main_item($item->id, array(
				    "name"			=> $name,
				    "icon_library"	=> $icon_library,
				    "icon"			=> $icon,
				    "rights"		=> $rights,
				    "user_group"	=> $group,
				    "path" 			=> $link
				    )
				);

				$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	            redirect(site_url('my/apps/'.$app->id.'/navigation/build/'.$item->id.''));

        	}

	    } else {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_59'));
            redirect(site_url('my/apps/'.$app->id.'/navigation'));

	    }

	}

	/*
	 * Delete menu item
	 * @param int $id_item
	 */
	public function delete_item($id_item)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($id_item) OR ! is_numeric($id_item)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_58'));
            redirect(site_url('my/apps/'.$app->id.'/navigation'));

	    }

	    $item = $this->navigation_model->get_menu_detail($id_item);

	    if ($item) {

	    	$this->navigation_model->del_main_item($item->id);

	    	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/apps/'.$app->id.'/navigation'));

	    } else {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_59'));
            redirect(site_url('my/apps/'.$app->id.'/navigation'));

	    }
	}

	/*
	 * Update sort menu items
	 * @param int $app_id
	 */
	public function update_sort_menu($app_id)
	{
		if (is_null($app_id) OR ! is_numeric($app_id)) {

	    } else {

	    	$app = $this->apps_model->get_app($app_id);

	    	if ($app) {

	    		$arrayItems = $_GET['item'];
        		$i = 0;

	    		foreach ($arrayItems as $value) {

		           $this->navigation_model->update_main_item($value, array(
		                "sort"   =>  $i
		                )
		            );

		            $i++;
		        }

	    	}

	    }
	}

}