<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Statistics extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('statistics_model');

		// ** Load libraries ** //
		$this->load->library('pagination');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}
    
    // check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('statistic', $user_lang);
    $this->lang->load('layout', $user_lang);
    $this->lang->load('alert', $user_lang);
    $this->lang->load('seo', $user_lang);

	}

	/*
	 * Index page
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$year = date("Y");

		if (empty($_GET["month"])) {

			$current_m = date("m");

		} else {

			$current_m = $this->security->xss_clean($_GET["month"]);

			if ($current_m > 12 OR $current_m < 1) {

				$this->session->set_flashdata('error', $this->lang->line('alert_75'));
            	redirect(site_url('my/apps/'.$app->id.'/statistics'));

			}

		}

		if ($current_m == 1) {

            $month = "January";
            $left = 0;
            $left_code = 0;
            $right = "February";
            $right_code = 2;

        } elseif ($current_m == 2) {

            $month = "February";
            $left = "January";
            $left_code = 1;
            $right = "March";
            $right_code = 3;

        } elseif ($current_m == 3) {

            $month = "March";
            $left = "February";
            $left_code = 2;
            $right = "April";
            $right_code = 4;

        } elseif ($current_m == 4) {

            $month = "April";
            $left = "March";
            $left_code = 3;
            $right = "May";
            $right_code = 5;

        } elseif ($current_m == 5) {

            $month = "May";
            $left = "April";
            $left_code = 4;
            $right = "June";
            $right_code = 6;

        } elseif ($current_m == 6) {

            $month = "June";
            $left = "May";
            $left_code = 5;
            $right = "July";
            $right_code = 7;

        } elseif ($current_m == 7) {

            $month = "July";
            $left = "June";
            $left_code = 6;
            $right = "August";
            $right_code = 8;

        } elseif ($current_m == 8) {

            $month = "August";
            $left = "July";
            $left_code = 7;
            $right = "September";
            $right_code = 9;

        } elseif ($current_m == 9) {

            $month = "September";
            $left = "August";
            $left_code = 8;
            $right = "October";
            $right_code = 10;

        } elseif ($current_m == 10) {

            $month = "October";
            $left = "September";
            $left_code = 9;
            $right = "November";
            $right_code = 11;

        } elseif ($current_m == 11) {

            $month = "November";
            $left = "October";
            $left_code = 10;
            $right = "December";
            $right_code = 12;

        } elseif ($current_m == 12) {

            $month = "December";
            $left = "November";
            $left_code = 11;
            $right = 0;
            $right_code = 0;

        }

	    $num_of_days = cal_days_in_month(CAL_GREGORIAN, $current_m, date("Y"));
	    for ($i=1; $i<= $num_of_days; $i++) $dates[]= str_pad($i,2,'0', STR_PAD_LEFT);

	    // init params
	    $params = array();
	    $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	    $total_records = $this->statistics_model->get_total_for_month_all($app->id, ''.date("Y").'-'.$current_m.'-01 00:00:00', ''.date("Y").'-'.$current_m.'-31 23:59:59');

	    // load config file
		$this->config->load('pagination', TRUE);
		$settings_pagination = $this->config->item('pagination');
		$settings_pagination['total_rows'] = $this->statistics_model->get_total_for_month_all($app->id, ''.date("Y").'-'.$current_m.'-01 00:00:00', ''.date("Y").'-'.$current_m.'-31 23:59:59');
		$settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/statistics/index';

		if ($total_records > 0)
		{
			// get current page records
			$params["statistics"] = $this->statistics_model->get_statistic_for_month_all($settings_pagination['per_page'], $start_index, $app->id, ''.date("Y").'-'.$current_m.'-01 00:00:00', ''.date("Y").'-'.$current_m.'-31 23:59:59');
				             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
				             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

	    $ios_total = $this->statistics_model->get_total_for_month($app->id, 1, ''.date("Y").'-'.$current_m.'-01 00:00:00', ''.date("Y").'-'.$current_m.'-31 23:59:59');
	    $android_total = $this->statistics_model->get_total_for_month($app->id, 2, ''.date("Y").'-'.$current_m.'-01 00:00:00', ''.date("Y").'-'.$current_m.'-31 23:59:59');
	    $windows_total = $this->statistics_model->get_total_for_month($app->id, 3, ''.date("Y").'-'.$current_m.'-01 00:00:00', ''.date("Y").'-'.$current_m.'-31 23:59:59');

	    $params["total_records"] = $total_records;
		$params["app"] = $app;
		$params["month"] = $month;
		$params["current_m"] = $current_m;
		$params["left"] = $left;
		$params["left_code"] = $left_code;
		$params["right"] = $right;
		$params["right_code"] = $right_code;
		$params["year"] = $year;
		$params["dates"] = $dates;
		$params["ios_total"] = $ios_total;
		$params["android_total"] = $android_total;
		$params["windows_total"] = $windows_total;

    	$this->template->set('title', $this->lang->line('seo_28'));
		$this->template->load('cms', 'contents' , 'statistics/index', $params);
	}

	/*
	 * Annual report page
	 */
	public function annual()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (empty($_GET["year"])) {

			$year = date("Y");

		} else {

			$year = $this->security->xss_clean($_GET["year"]);

			if (is_null($year) OR ! is_numeric($year)) {

		    	$this->session->set_flashdata('error', $this->lang->line('alert_76'));
	            redirect(site_url('my/apps/'.$app->id.'/statistics'));

		    }

		    if ($year < 2000 OR $year > 2999) {

		    	$this->session->set_flashdata('error', $this->lang->line('alert_76'));
	            redirect(site_url('my/apps/'.$app->id.'/statistics'));

		    }

		}

		// init params
	    $params = array();
	    $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
	    $total_records = $this->statistics_model->get_total_for_year_all($app->id, ''.$year.'-01-01 00:00:00', ''.$year.'-12-31 23:59:59');

	    // load config file
		$this->config->load('pagination', TRUE);
		$settings_pagination = $this->config->item('pagination');
		$settings_pagination['total_rows'] = $this->statistics_model->get_total_for_year_all($app->id, ''.$year.'-01-01 00:00:00', ''.$year.'-12-31 23:59:59');
		$settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/statistics/annual';

		if ($total_records > 0)
		{
			// get current page records
			$params["statistics"] = $this->statistics_model->get_statistic_for_month_all($settings_pagination['per_page'], $start_index, $app->id, ''.$year.'-01-01 00:00:00', ''.$year.'12-31 23:59:59');
				             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
				             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

		$ios_total = $this->statistics_model->get_total_for_month($app->id, 1, ''.$year.'-01-01 00:00:00', ''.$year.'-12-31 23:59:59');
	    $android_total = $this->statistics_model->get_total_for_month($app->id, 2, ''.$year.'-01-01 00:00:00', ''.$year.'-12-31 23:59:59');
	    $windows_total = $this->statistics_model->get_total_for_month($app->id, 3, ''.$year.'-01-01 00:00:00', ''.$year.'-12-31 23:59:59');

	    // get statistic for every month
	    $january_stat_ios = $this->statistics_model->get_total_for_month($app->id, 1, ''.$year.'-01-01 00:00:00', ''.$year.'-01-31 23:59:59');
	    $january_stat_android = $this->statistics_model->get_total_for_month($app->id, 2, ''.$year.'-01-01 00:00:00', ''.$year.'-01-31 23:59:59');
	    $january_stat_windows = $this->statistics_model->get_total_for_month($app->id, 3, ''.$year.'-01-01 00:00:00', ''.$year.'-01-31 23:59:59');

	    $february_stat_ios = $this->statistics_model->get_total_for_month($app->id, 1, ''.$year.'-02-01 00:00:00', ''.$year.'-02-31 23:59:59');
	    $february_stat_android = $this->statistics_model->get_total_for_month($app->id, 2, ''.$year.'-02-01 00:00:00', ''.$year.'-02-31 23:59:59');
	    $february_stat_windows = $this->statistics_model->get_total_for_month($app->id, 3, ''.$year.'-02-01 00:00:00', ''.$year.'-02-31 23:59:59');

	    $params["total_records"] = $total_records;
		$params["app"] = $app;
		$params["year"] = $year;
		$params["ios_total"] = $ios_total;
		$params["android_total"] = $android_total;
		$params["windows_total"] = $windows_total;

    	$this->template->set('title', $this->lang->line('seo_28'));
		$this->template->load('cms', 'contents' , 'statistics/annual', $params);

	}

	/*
	 * Delete item
	 * @param int $id
	 */
	public function delete_item($id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_77'));
            redirect(site_url('my/apps/'.$app->id.'/statistics'));

	    }

		$item = $this->statistics_model->get_item($id);

		if ($item) {

			$this->statistics_model->del_item($item->id);

			$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/apps/'.$app->id.'/statistics'));

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_59'));
            redirect(site_url('my/apps/'.$app->id.'/statistics'));

		}
	}

}