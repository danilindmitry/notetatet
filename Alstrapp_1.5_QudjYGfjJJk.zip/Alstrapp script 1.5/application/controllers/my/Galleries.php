<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Galleries extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('galleries_model');

		// ** Load libraries ** //
		$this->load->library('pagination');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check type app
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('galleries', $user_lang);
    	$this->lang->load('layout', $user_lang);
    	$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * All galleries
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		// Check search value
		if (!isset($_GET['search'])) {
		          
		    $search = null;
		          
		} else {
		          
		    $search = $this->security->xss_clean($_GET['search']);
		          
		}

		// init params
        $params = array();
        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        $total_records = $this->galleries_model->get_total($app->id, $search);

        // load config file
	    $this->config->load('pagination', TRUE);
	    $settings_pagination = $this->config->item('pagination');
	    $settings_pagination['total_rows'] = $this->galleries_model->get_total($app->id, $search);
	    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/galleries/index';

	    if ($total_records > 0)
		{
			// get current page records
			$params["galleries"] = $this->galleries_model->get_galleries($settings_pagination['per_page'], $start_index, $app->id, $search);
			             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
			             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

		$params["total_records"] = $total_records;
		$params["app"] = $app;

    	$this->template->set('title', $this->lang->line('seo_8'));
		$this->template->load('cms', 'contents' , 'galleries/index', $params);
	}

	/*
	 * Create gallery
	 */
	public function create_gallery()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[150]|min_length[3]');

        if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

        } else {

        	// set variable for input data
        	$name = $this->input->post("name", true);

        	// add user group
            $this->galleries_model->add_gallery(array(
	            "app_id"    => $app->id,
	            "created"   => date('Y-m-d H:i:s'),
	            "name"    	=> $name,
	            )
	        );

            $this->session->set_flashdata('success', $this->lang->line('alert_1'));
        	redirect(site_url('my/apps/'.$app->id.'/galleries'));

        }
	}

	/*
	 * Upload view page
	 * @param int $gallery_id
	 */
	public function upload($gallery_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($gallery_id) OR ! is_numeric($gallery_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_45'));
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

	    }

		$gallery = $this->galleries_model->get_gallery($gallery_id);

		if ($gallery) {

			$items = $this->galleries_model->get_gallery_items($gallery_id);

			$data = array(
				"app"		=> $app,
				"gallery"	=> $gallery,
				"items"		=> $items
			);

	    	$this->template->set('title', $this->lang->line('seo_8'));
			$this->template->load('cms', 'contents' , 'galleries/upload', $data);

		} else {

			// empry gallery
	    	$this->session->set_flashdata('error', $this->lang->line('alert_46'));
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

		}
	}

	/*
	 * Upload images
	 * @param int $gallery_id
	 */
	public function upload_images($gallery_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($gallery_id) OR ! is_numeric($gallery_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_45'));
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

	    }

	    $gallery = $this->galleries_model->get_gallery($gallery_id);

	    if ($gallery) {

	    	$this->load->library('upload');

	    	$date = date('Y-m-d H:i:s');

        	$image = array();

        	$ImageCount = count($_FILES['image_name']['name']);

        	for($i = 0; $i < $ImageCount; $i++) {

	            $_FILES['file']['name']       	= $_FILES['image_name']['name'][$i];
	            $_FILES['file']['type']       	= $_FILES['image_name']['type'][$i];
	            $_FILES['file']['tmp_name']		= $_FILES['image_name']['tmp_name'][$i];
	            $_FILES['file']['error']      	= $_FILES['image_name']['error'][$i];
	            $_FILES['file']['size']       	= $_FILES['image_name']['size'][$i];

	            // File upload configuration
	            $uploadPath                 	= ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/galleries';
	            $config['upload_path']      	= $uploadPath;
	            $config['allowed_types']    	= 'jpg|jpeg|png|gif';
	            $config['encrypt_name']     	= TRUE;
	            $config['remove_spaces']    	= TRUE;

	            // Load and initialize upload library
	            $this->load->library('upload', $config);
	            $this->upload->initialize($config);

	            // Upload file to server
	            if($this->upload->do_upload('file')) {

	                // Uploaded file data
	                $imageData = $this->upload->data();
	                $uploadImgData[$i]['path']     		= $imageData['file_name'];
	                $uploadImgData[$i]['gallery_id']	= $gallery->id;
	                $uploadImgData[$i]['created']   	= $date;
	                $uploadImgData[$i]['app_id']   		= $app->id;

	            }

	        }

	        if(!empty($uploadImgData)) {

	        	// add images to database
	        	$this->galleries_model->add_images($uploadImgData);

	        	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            	redirect(site_url('my/apps/'.$app->id.'/galleries/upload/'.$gallery->id.''));

	        } else {

	        	// empry request
	    		$this->session->set_flashdata('error', $this->lang->line('alert_47'));
            	redirect(site_url('my/apps/'.$app->id.'/galleries/upload/'.$gallery->id.''));

	        }

	    } else {

	    	// empry gallery
	    	$this->session->set_flashdata('error', $this->lang->line('alert_46'));
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

	    }
	}

	/*
	 * Delete item gallery
	 * @param int $item_id
	 */
	public function delete_image($item_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($item_id) OR ! is_numeric($item_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_48'));
            redirect(site_url('my/apps'));

	    }
	    
		$item = $this->galleries_model->get_item_gallery($item_id);

		if ($item) {

	    	// delete image in database
	    	$this->galleries_model->del_item_gallery($item_id);

	    	$this->session->set_flashdata('success', $this->lang->line('alert_3'));
        	redirect(site_url('my/apps/'.$app->id.'/galleries/upload/'.$item->gallery_id.''));

	    } else {

	    	// empty item
	    	$this->session->set_flashdata('error', $this->lang->line('alert_49'));
            redirect(site_url('my/apps/'.$app->id.'/galleries/upload/'.$item->gallery_id.''));

	    }

	}

	/*
	 * Delete gallery
	 * @param int $gallery_id
	 */
	public function delete_gallery($gallery_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($gallery_id) OR ! is_numeric($gallery_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_45'));
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

	    }

	    $gallery = $this->galleries_model->get_gallery($gallery_id);

	    if ($gallery) {

	    	$items = $this->galleries_model->get_gallery_items_for_delete($gallery_id);

	    	$this->galleries_model->del_gallery($gallery->id);

	    	if ($items) {

	    		$this->galleries_model->del_all_items($items);

	    	}

	    	$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

	    } else {

	    	// empry gallery
	    	$this->session->set_flashdata('error', $this->lang->line('alert_46'));
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

	    }
	}

	/*
	 * Update gallery
	 * @param int $gallery_id
	 */
	public function update_gallery($gallery_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (is_null($gallery_id) OR ! is_numeric($gallery_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_45'));
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

	    }

	    $gallery = $this->galleries_model->get_gallery($gallery_id);

	    if ($gallery) {

	    	$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[150]|min_length[3]');

	    	if ($this->form_validation->run() == false) {

	            $this->session->set_flashdata('error', validation_errors());
	            redirect(site_url('my/apps/'.$app->id.'/galleries'));

	        } else {

	        	// set variable for input data
	        	$name = $this->input->post("name", true);

	        	// update gallery
	        	$this->galleries_model->update_gallery($gallery->id, array(
		            "name"	=> $name,
		            )
		        );

		        $this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        	redirect(site_url('my/apps/'.$app->id.'/galleries'));

	        }

	    } else {

	    	// empty gallery
	    	$this->session->set_flashdata('error', $this->lang->line('alert_46'));
            redirect(site_url('my/apps/'.$app->id.'/galleries'));

	    }

	}

}