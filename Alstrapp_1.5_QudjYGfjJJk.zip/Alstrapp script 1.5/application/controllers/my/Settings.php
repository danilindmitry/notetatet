<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('settings_model');
    	$this->load->model('icons_model');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}
    
    // check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('settings', $user_lang);
    $this->lang->load('layout', $user_lang);
    $this->lang->load('alert', $user_lang);
    $this->lang->load('seo', $user_lang);

	}

	/*
	 * App settings
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$settings = $this->settings_model->get_settings($app->id);

		$data = array(
			"app"		=>  $app,
			"settings"	=>  $settings
		);

    	$this->template->set('title', $this->lang->line('seo_23'));
		$this->template->load('cms', 'contents' , 'settings/index', $data);
	}

	/*
	 * PUSH settings
	 */
	public function push()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$settings = $this->settings_model->get_settings($app->id);

		$data = array(
			"app"		=>  $app,
			"settings"	=>  $settings
		);

    	$this->template->set('title', $this->lang->line('seo_24'));
		$this->template->load('cms', 'contents' , 'settings/push', $data);
	}

	/*
	 * Update One signal settings
	 */
	public function update_push()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('app_id', "One Signal APP ID", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('rest_api_key', "REST API key", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('user_auth_key', "User auth key", 'trim|required|max_length[100]|min_length[2]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/settings/push'));

        } else {

        	// set variable for input data
        	$app_id = $this->input->post("app_id", true);
        	$rest_api_key = $this->input->post("rest_api_key", true);
        	$user_auth_key = $this->input->post("user_auth_key", true);

        	// update
	        $this->settings_model->update_settings($app->id, array(
		        "onesignal_api_key"		=> $app_id,
		        "onesignal_rest_api"	=> $rest_api_key,
		        "onesignal_auth_key"	=> $user_auth_key
		        )
		    );

		    $this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/apps/'.$app->id.'/settings/push'));

        }

	}

	/*
	 * Update One signal settings
	 */
	public function update_app_settings()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('name', "App name", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('app_id', "App ID", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('description_app', "App description", 'trim|required|max_length[3000]|min_length[10]');
		$this->form_validation->set_rules('author', "Author", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('version', "Version", 'trim|required|max_length[100]|min_length[2]');
		$this->form_validation->set_rules('check_comments', "Comments moderation", 'trim|required|in_list[0,1]');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/settings'));

        } else {

        	$date = date('Y-m-d H:i:s');

        	// set variable for input data
        	$name = $this->input->post("name", true);
        	$app_id = $this->input->post("app_id", true);
        	$description_app = $this->input->post("description_app", true);
        	$author = $this->input->post("author", true);
        	$version = $this->input->post("version", true);
        	$check_comments = $this->input->post("check_comments", true);
        	$check_users = $this->input->post("check_users", true);

        	$this->apps_model->update_app($app->id, array(
			    "app_id"    		=>  $app_id,
			    "updated"   		=>  $date,
			    "name"   			=>  $name,
			    "description_app"   =>  $description_app,
			    "author"   			=>  $author,
			    "version"   		=>  $version
			    )
			);

			// update settings
	        $this->settings_model->update_settings($app->id, array(
		        "check_comments"	=> $check_comments
		        )
		    );

			$this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/apps/'.$app->id.'/settings'));

        }
	}

	/*
	 * Icons and screen
	 */
	public function icons()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$settings = $this->settings_model->get_settings($app->id);

		$icon = $this->icons_model->get_icons($app->id);

		$data = array(
			"app"		=>  $app,
			"settings"	=>  $settings,
			"icon"		=>  $icon
		);

    	$this->template->set('title', $this->lang->line('seo_25'));
		$this->template->load('cms', 'contents' , 'settings/icons', $data);
	}

	/*
	 * Icons and screen for iOS
	 */
	public function icons_ios()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$settings = $this->settings_model->get_settings($app->id);

		$icon = $this->icons_model->get_icons($app->id);

		$data = array(
			"app"		=>  $app,
			"settings"	=>  $settings,
			"icon"		=>  $icon
		);

    	$this->template->set('title', $this->lang->line('seo_25'));
		$this->template->load('cms', 'contents' , 'settings/icons_ios', $data);
	}

	/*
	 * Avatars for chat and comments
	 */
	public function avatars()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$settings = $this->settings_model->get_settings($app->id);

		$icon = $this->icons_model->get_icons($app->id);

		$data = array(
			"app"		=>  $app,
			"settings"	=>  $settings,
			"icon"		=>  $icon
		);

    	$this->template->set('title', $this->lang->line('seo_26'));
		$this->template->load('cms', 'contents' , 'settings/avatars', $data);
	}

	/*
	 * Icon upload
	 */
	public function upload_icon()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('type', "Type icon", 'trim|required|numeric');

		if ($this->form_validation->run() == false) {

	        $this->session->set_flashdata('error', validation_errors());
	        redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

	    } else {

	    	// set variable for input data
	        $type = $this->input->post("type", true);

	        if ($type == 1) {

	        	// Android default
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 512;
	        	$config['min_width']    	= 512;
	        	$config['max_height']    	= 512;
	        	$config['min_height']    	= 512;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 2) {

	        	// Android MDPI
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 48;
	        	$config['min_width']    	= 48;
	        	$config['max_height']    	= 48;
	        	$config['min_height']    	= 48;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_mdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 3) {

	        	// Android HDPI
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 72;
	        	$config['min_width']    	= 72;
	        	$config['max_height']    	= 72;
	        	$config['min_height']    	= 72;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_hdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 4) {

	        	// Android XHDPI
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 96;
	        	$config['min_width']    	= 96;
	        	$config['max_height']    	= 96;
	        	$config['min_height']    	= 96;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_xhdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 5) {

	        	// Android XXHDPI
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 144;
	        	$config['min_width']    	= 144;
	        	$config['max_height']    	= 144;
	        	$config['min_height']    	= 144;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_xxhdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 6) {

	        	// Android XXXHDPI
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 192;
	        	$config['min_width']    	= 192;
	        	$config['max_height']    	= 192;
	        	$config['min_height']    	= 192;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_xxxhdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 7) {

	        	// iOS 7.0+ iPhone 6 / 6+ Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 180;
	        	$config['min_width']    	= 60;
	        	$config['max_height']    	= 180;
	        	$config['min_height']    	= 60;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_60_3x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 8) {

	        	// iOS 7.0+ iPhone / iPod Touch
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 60;
	        	$config['min_width']    	= 60;
	        	$config['max_height']    	= 60;
	        	$config['min_height']    	= 60;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_60"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 9) {

	        	// iOS 7.0+ iPhone / iPod Touch Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 120;
	        	$config['min_width']    	= 60;
	        	$config['max_height']    	= 120;
	        	$config['min_height']    	= 60;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_60_2x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 10) {

	        	// iOS 7.0+ iPad
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 76;
	        	$config['min_width']    	= 76;
	        	$config['max_height']    	= 76;
	        	$config['min_height']    	= 76;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_76"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 11) {

	        	// iOS 7.0+ iPad @2x Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 152;
	        	$config['min_width']    	= 76;
	        	$config['max_height']    	= 152;
	        	$config['min_height']    	= 76;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_76_2x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 12) {

	        	// iOS 7.0+ iPad @2x Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 167;
	        	$config['min_width']    	= 83.5;
	        	$config['max_height']    	= 167;
	        	$config['min_height']    	= 83.5;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_83_5_2x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 13) {

	        	// iOS 7.0+ Settings Icon
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 29;
	        	$config['min_width']    	= 29;
	        	$config['max_height']    	= 29;
	        	$config['min_height']    	= 29;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_small"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 14) {

	        	// iOS 7.0+ Settings Icon Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 58;
	        	$config['min_width']    	= 29;
	        	$config['max_height']    	= 58;
	        	$config['min_height']    	= 29;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_small_2x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 15) {

	        	// iOS 7.0+ Settings Icon Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 87;
	        	$config['min_width']    	= 29;
	        	$config['max_height']    	= 87;
	        	$config['min_height']    	= 29;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_small_3x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 16) {

	        	// iOS 7.0+ Spotlight Icon
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 40;
	        	$config['min_width']    	= 40;
	        	$config['max_height']    	= 40;
	        	$config['min_height']    	= 40;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_40"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 17) {

	        	// iOS 7.0+ Spotlight Icon Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 80;
	        	$config['min_width']    	= 40;
	        	$config['max_height']    	= 80;
	        	$config['min_height']    	= 40;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_40_2x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 18) {

	        	// iOS 7.0+ Spotlight Icon Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 120;
	        	$config['min_width']    	= 40;
	        	$config['max_height']    	= 120;
	        	$config['min_height']    	= 40;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_40_3x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 19) {

	        	// iOS 6.1 iPhone / iPod Touch
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 57;
	        	$config['min_width']    	= 57;
	        	$config['max_height']    	= 57;
	        	$config['min_height']    	= 57;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 20) {

	        	// iOS 6.1 iPhone / iPod Touch Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 114;
	        	$config['min_width']    	= 57;
	        	$config['max_height']    	= 114;
	        	$config['min_height']    	= 57;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_2x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 21) {

	        	// iOS 6.1 iPad
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 72;
	        	$config['min_width']    	= 72;
	        	$config['max_height']    	= 72;
	        	$config['min_height']    	= 72;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_72"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 22) {

	        	// iOS 6.1 iPad Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 144;
	        	$config['min_width']    	= 72;
	        	$config['max_height']    	= 144;
	        	$config['min_height']    	= 72;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_72_2x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 23) {

	        	// iOS 6.1 iPad Spotlight and Settings Icon
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 50;
	        	$config['min_width']    	= 50;
	        	$config['max_height']    	= 50;
	        	$config['min_height']    	= 50;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_50"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 24) {

	        	// iOS 6.1 iPad Spotlight and Settings Icon Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/icon/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 100;
	        	$config['min_width']    	= 50;
	        	$config['max_height']    	= 100;
	        	$config['min_height']    	= 50;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_icon_50_2x"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 25) {

	        	// Notify
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/notify';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 96;
	        	$config['min_width']    	= 96;
	        	$config['max_height']    	= 96;
	        	$config['min_height']    	= 96;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "notify_android"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else {

	        	$this->session->set_flashdata('error', $this->lang->line('alert_73'));
		         redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

	        }

	    }
	}

	/*
	 * Splash upload
	 */
	public function upload_splash()
	{

		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('type', "Type screen", 'trim|required|numeric');

		if ($this->form_validation->run() == false) {

	        $this->session->set_flashdata('error', validation_errors());
	        redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

	    } else {

	    	// set variable for input data
	        $type = $this->input->post("type", true);

	        if ($type == 1) {

	        	// Android ldpi
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 200;
	        	$config['min_width']    	= 200;
	        	$config['max_height']    	= 320;
	        	$config['min_height']    	= 320;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_screen_ldpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 2) {

	        	// Android mdpi
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 320;
	        	$config['min_width']    	= 320;
	        	$config['max_height']    	= 480;
	        	$config['min_height']    	= 480;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_screen_mdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 3) {

	        	// Android hdpi
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 480;
	        	$config['min_width']    	= 480;
	        	$config['max_height']    	= 800;
	        	$config['min_height']    	= 800;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_screen_hdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 4) {

	        	// Android xhdpi
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 720;
	        	$config['min_width']    	= 720;
	        	$config['max_height']    	= 1280;
	        	$config['min_height']    	= 1280;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_screen_xhdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 5) {

	        	// Android xxhdpi
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 960;
	        	$config['min_width']    	= 960;
	        	$config['max_height']    	= 1600;
	        	$config['min_height']    	= 1600;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_screen_xxhdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 6) {

	        	// Android xxxhdpi
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/android';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 1280;
	        	$config['min_width']    	= 1280;
	        	$config['max_height']    	= 1920;
	        	$config['min_height']    	= 1920;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "android_screen_xxxhdpi"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons'));

		        }

	        } else if ($type == 7) {

	        	// iPhone and iPod touch
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 320;
	        	$config['min_width']    	= 320;
	        	$config['max_height']    	= 480;
	        	$config['min_height']    	= 480;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_screen_default"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 8) {

	        	// iPhone and iPod touch Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 640;
	        	$config['min_width']    	= 320;
	        	$config['max_height']    	= 960;
	        	$config['min_height']    	= 480;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_screen_default_2"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 9) {

	        	// iPhone 5 / iPod Touch Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 640;
	        	$config['min_width']    	= 640;
	        	$config['max_height']    	= 1136;
	        	$config['min_height']    	= 1136;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_screen_iphone_5"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 10) {

	        	// iPhone 6 default Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 750;
	        	$config['min_width']    	= 750;
	        	$config['max_height']    	= 1334;
	        	$config['min_height']    	= 1334;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_screen_667h"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 11) {

	        	// iPhone 6 default portrait Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 1242;
	        	$config['min_width']    	= 1242;
	        	$config['max_height']    	= 2208;
	        	$config['min_height']    	= 2208;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_screen_736h"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 12) {

	        	// iPad
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 768;
	        	$config['min_width']    	= 768;
	        	$config['max_height']    	= 1024;
	        	$config['min_height']    	= 1024;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_screen_ipad"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        } else if ($type == 13) {

	        	// iPad Retina
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'/www/img/screen/ios';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 1536;
	        	$config['min_width']    	= 1536;
	        	$config['max_height']    	= 2048;
	        	$config['min_height']    	= 2048;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "ios_screen_ipad_retina"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/icons_ios'));

		        }

	        }

	    }
	}

	/*
	 * Icon avatar
	 */
	public function upload_avatar()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('type', "Type avatar", 'trim|required|numeric');

		if ($this->form_validation->run() == false) {

	        $this->session->set_flashdata('error', validation_errors());
	        redirect(site_url('my/apps/'.$app->id.'/settings/avatars'));

	    } else {

	    	// set variable for input data
	        $type = $this->input->post("type", true);

	        if ($type == 1) {

	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/avatars';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 256;
	        	$config['min_width']    	= 256;
	        	$config['max_height']    	= 256;
	        	$config['min_height']    	= 256;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/avatars'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "chat_avatar"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/avatars'));

		        }

	        } else if ($type == 2) {

	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/avatars';
	        	$config['allowed_types']    = 'jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	//$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;
	        	$config['max_width']    	= 256;
	        	$config['min_width']    	= 256;
	        	$config['max_height']    	= 256;
	        	$config['min_height']    	= 256;

	        	$this->load->library('upload', $config);

	        	// Check image
		        if (!$this->upload->do_upload('image')) {

		            $this->session->set_flashdata('error', $this->upload->display_errors());
		            redirect(site_url('my/apps/'.$app->id.'/settings/avatars'));

		        } else {

		            $image = $this->upload->data('file_name');

		            // update path
		            $this->icons_model->update_icon($app->id, array(
					    "comment_avatar"	=> $image
					    )
					);

					$this->session->set_flashdata('success', $this->lang->line('alert_1'));
	        		redirect(site_url('my/apps/'.$app->id.'/settings/avatars'));

		        }

	        } else {

	        	$this->session->set_flashdata('error', $this->lang->line('alert_74'));
	        	redirect(site_url('my/apps/'.$app->id.'/settings/avatars'));

	        }

	    }
	}

	/*
	 * Email settings
	 */
	public function emails()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$settings = $this->settings_model->get_settings($app->id);

		$data = array(
			"app"		=>  $app,
			"settings"	=>  $settings
		);

    	$this->template->set('title', $this->lang->line('seo_27'));
		$this->template->load('cms', 'contents' , 'settings/emails', $data);
	}

	/*
	 * Update Email settings
	 */
	public function update_email_settings()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));
		
		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('method', "Sending merhod", 'required|trim|in_list[1,2]');
		$this->form_validation->set_rules('admin_email', "Admin email", 'required|max_length[100]|valid_email');
		$this->form_validation->set_rules('cs_sender', "Sender name for CI", 'trim|max_length[100]');
		$this->form_validation->set_rules('cs_email', "Sender email for CI", 'trim|max_length[100]|valid_email');
		$this->form_validation->set_rules('smtp_sender', "Sender name for SMTP", 'trim|max_length[100]');
		$this->form_validation->set_rules('smtp_port', "SMTP port", 'trim|max_length[100]|numeric');
		$this->form_validation->set_rules('smtp_host', "SMTP host", 'trim|max_length[200]');
		$this->form_validation->set_rules('smtp_email', "Sender email for SMTP", 'trim|max_length[100]|valid_email');
		$this->form_validation->set_rules('smtp_password', "Password for SMTP", 'trim|max_length[100]|alpha_numeric');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/settings/emails'));

        } else {

        	// set variable for input data
        	$method = $this->input->post("method", true);
        	$cs_sender = $this->input->post("cs_sender", true);
        	$cs_email = $this->input->post("cs_email", true);
        	$smtp_sender = $this->input->post("smtp_sender", true);
        	$smtp_port = $this->input->post("smtp_port", true);
        	$smtp_host = $this->input->post("smtp_host", true);
        	$smtp_email = $this->input->post("smtp_email", true);
        	$smtp_password = $this->input->post("smtp_password", true);
        	$admin_email = $this->input->post("admin_email", true);

        	// update
	        $this->settings_model->update_settings($app->id, array(
		        "mail_method"	=> $method,
		        "smtp_sender"	=> $smtp_sender,
		        "smtp_port"		=> $smtp_port,
		        "smtp_host"		=> $smtp_host,
		        "smtp_email"	=> $smtp_email,
		        "smtp_password"	=> $smtp_password,
		        "cs_sender"		=> $cs_sender,
		        "cs_email"		=> $cs_email,
		        "admin_email"	=> $admin_email
		        )
		    );

		    $this->session->set_flashdata('success', $this->lang->line('alert_1'));
            redirect(site_url('my/apps/'.$app->id.'/settings/emails'));

        }


	}

}