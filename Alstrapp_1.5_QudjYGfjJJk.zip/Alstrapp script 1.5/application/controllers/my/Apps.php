<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Apps extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('icons_model');
    	$this->load->model('template_model');
    	$this->load->model('settings_model');
    	$this->load->model('comments_model');
    	$this->load->model('forms_model');
    	$this->load->model('galleries_model');
    	$this->load->model('icons_model');
    	$this->load->model('messages_model');
    	$this->load->model('navigation_model');
    	$this->load->model('notifications_model');
    	$this->load->model('posts_model');
    	$this->load->model('statistics_model');
    	$this->load->model('users_model');
    	$this->load->model('builder_model');

		// ** Load libraries ** //
		$this->load->library('pagination');
		$this->load->library('writer');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('app', $user_lang);
    	$this->lang->load('layout', $user_lang);
    	$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * Apps list
	 */
	public function index()
	{
		$templates = $this->template_model->get_templates_design();

		// all apps
		if (!isset($_GET['sort'])) {

			// init params
        	$params = array();
        	$start_index = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
        	$total_records = $this->apps_model->get_total_apps(0);

        	// load config file
        	$this->config->load('pagination', TRUE);
        	$settings_pagination = $this->config->item('pagination');
        	$settings_pagination['total_rows'] = $this->apps_model->get_total_apps(0);
        	$settings_pagination['base_url'] = base_url() . 'my/apps/index';

        	if ($total_records > 0)
		    {
		        // get current page records
		        $params["apps"] = $this->apps_model->get_apps($settings_pagination['per_page'], $start_index, 0);
		             
		        // use the settings to initialize the library
		        $this->pagination->initialize($settings_pagination);
		             
		        // build paging links
		        $params["links"] = $this->pagination->create_links();
		    }

		    $params["total_records"] = $total_records;
		    $params["templates"] = $templates;

	    	$this->template->set('title', $this->lang->line('seo_2'));
			$this->template->load('apps', 'contents' , 'apps/all_apps', $params);
                  
        } else {
            
            if ($_GET['sort'] == 2) { // active apps

            	// init params
	        	$params = array();
	        	$start_index = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
	        	$total_records = $this->apps_model->get_total_apps(2);

	        	// load config file
	        	$this->config->load('pagination', TRUE);
	        	$settings_pagination = $this->config->item('pagination');
	        	$settings_pagination['total_rows'] = $this->apps_model->get_total_apps(2);
	        	$settings_pagination['base_url'] = base_url() . 'my/apps/index';

	        	if ($total_records > 0)
			    {
			        // get current page records
			        $params["apps"] = $this->apps_model->get_apps($settings_pagination['per_page'], $start_index, 2);
			             
			        // use the settings to initialize the library
			        $this->pagination->initialize($settings_pagination);
			             
			        // build paging links
			        $params["links"] = $this->pagination->create_links();
			    }

			    $params["total_records"] = $total_records;
			    $params["templates"] = $templates;

		    	$this->template->set('title', $this->lang->line('seo_2'));
				$this->template->load('apps', 'contents' , 'apps/active_apps', $params);

            } else if ($_GET['sort'] == 1) { // drafts

            	// init params
	        	$params = array();
	        	$start_index = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
	        	$total_records = $this->apps_model->get_total_apps(1);

	        	// load config file
	        	$this->config->load('pagination', TRUE);
	        	$settings_pagination = $this->config->item('pagination');
	        	$settings_pagination['total_rows'] = $this->apps_model->get_total_apps(1);
	        	$settings_pagination['base_url'] = base_url() . 'my/apps/index';

	        	if ($total_records > 0)
			    {
			        // get current page records
			        $params["apps"] = $this->apps_model->get_apps($settings_pagination['per_page'], $start_index, 1);
			             
			        // use the settings to initialize the library
			        $this->pagination->initialize($settings_pagination);
			             
			        // build paging links
			        $params["links"] = $this->pagination->create_links();
			    }

			    $params["total_records"] = $total_records;
			    $params["templates"] = $templates;

		    	$this->template->set('title', $this->lang->line('seo_2'));
				$this->template->load('apps', 'contents' , 'apps/drafts', $params);

            } else {

            	// sort not found
            	redirect(site_url('my/apps'));

            }
                  
        }

	}

	/*
	 * Create app
	 */
	public function create_app()
	{
		// ** Start Input validation ** //
		$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[150]|min_length[3]');
		$this->form_validation->set_rules('template', "Design template", 'trim|required|numeric');
		$this->form_validation->set_rules('id_app', "App id", 'trim|required');
		$this->form_validation->set_rules('device', "Device theme for template", 'trim|required|in_list[1,2,3]');
		$this->form_validation->set_rules('type', "Type project", 'trim|required|in_list[0,1]');
		$this->form_validation->set_rules('source_path', "Source path", 'trim|required');
		// ** End Input validation ** //

		// ** Check Result Form ** //
        if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps'));

        } else {

        	// set variable for input data
        	$name = $this->input->post("name", true);
            $template = $this->input->post("template", true);
            $id_app = $this->input->post("id_app", true);
            $device = $this->input->post("device", true);
            $type = $this->input->post("type", true);
            $source_path = $this->input->post("source_path", true);

            // add app
            $app = $this->apps_model->add_app(array(
	            "app_id"    		=> $id_app,
	            "created"   		=> date('Y-m-d H:i:s'),
	            "updated"   		=> date('Y-m-d H:i:s'),
	            "published"			=> date('Y-m-d H:i:s'),
	            "name"    			=> $name,
	            "template"  		=> $template,
	            "device"  			=> $device,
	            "status"    		=> 1,
	            "online"    		=> 1,
	            "version" 			=> "1.0.0",
	            "description_app" 	=> "App project via Alstrapp",
	            "author" 			=> "Alstrapp",
	            "type" 				=> $type,
	            "source_path" 		=> $source_path
	            )
	        );

           	// add icons
	        $this->icons_model->add_icons(array(
	            "app_id"    =>  $app
	            )
	        );

	        // add settings project
	        $this->settings_model->add_settings(array(
	            "app_id"    =>  $app
	            )
	        );

	        // create files project
	        $create = $this->writer->create_project($app, $device);

	        if ($create['event'] == 'success') {

	        	$this->session->set_flashdata('success', $create['message']);
        		redirect(site_url('my/apps'));

	        } else {

	        	$this->session->set_flashdata('error', $create['message']);
        		redirect(site_url('my/apps'));

	        }

        }
	}

	/*
	 * Delete app
	 * @param int $id
	 */
	public function delete_app($id)
	{
		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_2'));
            redirect(site_url('my/apps'));

	    }

	    $app = $this->apps_model->get_app($id);

	    if ($app) {

	    	// delete files
	    	$app_directory = ''.$_SERVER['DOCUMENT_ROOT'].'/projects/'.$app->id.'';
	    	$this->load->helper("file");
	    	delete_files($app_directory, true);

	    	// delete comments
	    	$comments = $this->comments_model->get_all_comments_for_app($app->id);

	    	if ($comments) {

	    		foreach ($comments as $data_comments) {
	    			
	    			$this->comments_model->del_comment($data_comments->id);

	    		}

	    	}

	    	// delete forms
	    	$forms = $this->forms_model->get_all_forms_for_app($app->id);

	    	if ($forms) {

	    		foreach ($forms as $data_forms) {
	    			
	    			$this->forms_model->del_form($data_forms->id);

	    		}

	    	}

	    	// delete received forms
	    	$forms_received = $this->forms_model->get_all_received_forms_for_app($app->id);

	    	if ($forms_received) {

	    		foreach ($forms_received as $data_forms_received) {
	    			
	    			$this->forms_model->del_form_received($data_forms_received->id);

	    		}

	    	}


	    	// delete form elements
	    	$forms_elements = $this->forms_model->get_all_elements_forms_for_app($app->id);

	    	if ($forms_elements) {

	    		foreach ($forms_elements as $data_forms_elements) {
	    			
	    			$this->forms_model->del_form_element($data_forms_elements->id);

	    		}

	    	}

	    	// delete galleries
	    	$galleries = $this->galleries_model->get_all_gallery_for_app($app->id);

	    	if ($galleries) {

	    		foreach ($galleries as $data_galleries) {
	    			
	    			$this->galleries_model->del_gallery($data_galleries->id);

	    		}

	    	}

	    	// delete items galleries
	    	$galleries_items = $this->galleries_model->get_all_gallery_items_for_app($app->id);

	    	if ($galleries_items) {

	    		foreach ($galleries_items as $data_galleries_items) {
	    			
	    			$this->galleries_model->del_item_gallery($data_galleries_items->id);

	    		}

	    	}

	    	// delete icons
	    	$icons = $this->icons_model->get_icons($app->id);

	    	if ($icons) {

	    		$this->icons_model->del_icon($icons->id);

	    	}

	    	// delete messages
	    	$messages = $this->messages_model->get_all_messages_for_app($app->id);

	    	if ($messages) {

	    		foreach ($messages as $data_messages) {
	    			
	    			$this->messages_model->del_message($data_messages->id);

	    		}

	    	}

	    	// delete dialogues
	    	$dialogues = $this->messages_model->get_all_dialogues_for_app($app->id);

	    	if ($dialogues) {

	    		foreach ($dialogues as $data_dialogues) {
	    			
	    			$this->messages_model->del_dialogues($data_dialogues->id);

	    		}

	    	}

	    	// delete navigation
	    	$navigation = $this->navigation_model->get_all_navigation_for_app($app->id);

	    	if ($navigation) {

	    		foreach ($navigation as $data_navigation) {
	    			
	    			$this->navigation_model->del_main_item($data_navigation->id);

	    		}

	    	}

	    	// notifications
	    	$notifications = $this->notifications_model->get_all_notifications_for_app($app->id);

	    	if ($notifications) {

	    		foreach ($notifications as $data_notifications) {
	    			
	    			$this->notifications_model->del_alert($data_notifications->id);

	    		}

	    	}

	    	// delete posts
	    	$posts = $this->posts_model->get_all_posts_for_app($app->id);

	    	if ($posts) {

	    		foreach ($posts as $data_posts) {
	    			
	    			$this->posts_model->del_post($data_posts->id);

	    		}

	    	}

	    	// delete post categories
	    	$posts_categories = $this->posts_model->get_all_posts_categories_for_app($app->id);

	    	if ($posts_categories) {

	    		foreach ($posts_categories as $data_posts_categories) {
	    			
	    			$this->posts_model->del_category($data_posts_categories->id);

	    		}

	    	}

	    	// delete settings
	    	$settings = $this->settings_model->get_settings($app->id);

	    	if ($settings) {

	    		$this->settings_model->del_settings($settings->id);

	    	}

	    	// delete statistic
	    	$statistics = $this->statistics_model->get_all_statistics_for_app($app->id);

	    	if ($statistics) {

	    		foreach ($statistics as $data_statistics) {
	    			
	    			$this->statistics_model->del_item($data_statistics->id);

	    		}

	    	}

	    	// delete users
	    	$users = $this->users_model->get_all_users_for_app($app->id);

	    	if ($users) {

	    		foreach ($users as $data_users) {
	    			
	    			$this->users_model->del_user($data_users->id);

	    		}

	    	}

	    	// delete users group
	    	$users_group = $this->users_model->get_all_users_groups_for_app($app->id);

	    	if ($users_group) {

	    		foreach ($users_group as $data_users_group) {
	    			
	    			$this->users_model->del_group($data_users_group->id);

	    		}

	    	}

	    	// delete versions
	    	$versions = $this->builder_model->get_all_versions_for_app($app->id);

	    	if ($versions) {

	    		foreach ($versions as $data_versions) {
	    			
	    			$this->builder_model->del_app($data_versions->id);

	    		}

	    	}

	    	// delete app in database
	    	$this->apps_model->del_app($id);

	    	$this->session->set_flashdata('success', $this->lang->line('alert_3'));
        	redirect(site_url('my/apps'));

	    } else {

	    	// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

	    }
	}

	/*
	 * Get preview link
	 * @param int $id
	 */
	public function get_preview($id)
	{
		header('Access-Control-Allow-Origin: *');

		if (is_null($id) OR ! is_numeric($id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_2'));
            redirect(site_url('my/apps'));

	    }

	    $app = $this->apps_model->get_app($id);

	    if ($app) {

	    	$preview_link = site_url('projects/'.$app->id.'/www/');

	    	$response = array ('event' => 'success', 'link' => $preview_link);
			echo json_encode($response);

	    }

	}

}