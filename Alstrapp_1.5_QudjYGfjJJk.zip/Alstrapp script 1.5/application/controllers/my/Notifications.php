<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notifications extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('users_model');
    	$this->load->model('notifications_model');
    	$this->load->model('settings_model');
    	$this->load->model('icons_model');

		// ** Load libraries ** //
		$this->load->library('pagination');

		// check login status
		if (empty($_SESSION['id'])) {
    		
			redirect(site_url('auth'));

		}

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('notification', $user_lang);
    	$this->lang->load('layout', $user_lang);
    	$this->lang->load('alert', $user_lang);
    	$this->lang->load('seo', $user_lang);

	}

	/*
	 * Alert notifications
	 */
	public function index()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		$date = date('Y-m-d H:i:s');

		// init params
        $params = array();
        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        $total_records = $this->notifications_model->get_total_active_notifications($app->id, $date);

        // load config file
	    $this->config->load('pagination', TRUE);
	    $settings_pagination = $this->config->item('pagination');
	    $settings_pagination['total_rows'] = $this->notifications_model->get_total_active_notifications($app->id, $date);
	    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/notifications/index';

	    if ($total_records > 0)
		{
			// get current page records
			$params["notifications"] = $this->notifications_model->get_active_notifications($settings_pagination['per_page'], $start_index, $app->id, $date);
			             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
			             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

		$params["total_records"] = $total_records;
		$params["app"] = $app;

    	$this->template->set('title', $this->lang->line('seo_11'));
		$this->template->load('cms', 'contents' , 'notifications/index', $params);
	}

	/*
	 * Planned Alert notifications
	 */
	public function planned()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		$date = date('Y-m-d H:i:s');

		// init params
        $params = array();
        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        $total_records = $this->notifications_model->get_total_planned_notifications($app->id, $date);

        // load config file
	    $this->config->load('pagination', TRUE);
	    $settings_pagination = $this->config->item('pagination');
	    $settings_pagination['total_rows'] = $this->notifications_model->get_total_planned_notifications($app->id, $date);
	    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/notifications/planned';

	    if ($total_records > 0)
		{
			// get current page records
			$params["notifications"] = $this->notifications_model->get_planned_notifications($settings_pagination['per_page'], $start_index, $app->id, $date);
			             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
			             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

		$params["total_records"] = $total_records;
		$params["app"] = $app;

    	$this->template->set('title', $this->lang->line('seo_11'));
		$this->template->load('cms', 'contents' , 'notifications/planned', $params);
	}

	/*
	 * Archive Alert notifications
	 */
	public function archive()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		$date = date('Y-m-d H:i:s');

		// init params
        $params = array();
        $start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;
        $total_records = $this->notifications_model->get_total_archive_notifications($app->id, $date);

        // load config file
	    $this->config->load('pagination', TRUE);
	    $settings_pagination = $this->config->item('pagination');
	    $settings_pagination['total_rows'] = $this->notifications_model->get_total_archive_notifications($app->id, $date);
	    $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/notifications/archive';

	    if ($total_records > 0)
		{
			// get current page records
			$params["notifications"] = $this->notifications_model->get_archive_notifications($settings_pagination['per_page'], $start_index, $app->id, $date);
			             
			// use the settings to initialize the library
			$this->pagination->initialize($settings_pagination);
			             
			// build paging links
			$params["links"] = $this->pagination->create_links();
		}

		$params["total_records"] = $total_records;
		$params["app"] = $app;

    	$this->template->set('title', $this->lang->line('seo_11'));
		$this->template->load('cms', 'contents' , 'notifications/archive', $params);
	}

	/*
	 * Add notice view page
	 */
	public function add_notice()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		// check type app
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		$groups_list = $this->users_model->get_groups_list($app->id);

		$data = array(
			"app"			=>  $app,
			"groups_list"	=>  $groups_list
		);

    	$this->template->set('title', $this->lang->line('seo_12'));
		$this->template->load('cms', 'contents' , 'notifications/add_notice', $data);
	}

	/*
	 * Edit notice view page
	 * @param int $notice_id
	 */
	public function edit_notice($notice_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		if (is_null($notice_id) OR ! is_numeric($notice_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_60'));
            redirect(site_url('my/apps'));

	    }

	    $notice = $this->notifications_model->get_alert($notice_id);

	    if (!$notice) {

			// empty notifications
	    	$this->session->set_flashdata('error', $this->lang->line('alert_61'));
            redirect(site_url('my/apps'));

		}

		$groups_list = $this->users_model->get_groups_list($app->id);

		$data = array(
			"app"			=>  $app,
			"notice"		=>  $notice,
			"groups_list"	=>  $groups_list
		);

    	$this->template->set('title', $this->lang->line('seo_13'));
		$this->template->load('cms', 'contents' , 'notifications/edit_notice', $data);
	}

	/*
	 * Create notice form
	 */
	public function create_notice()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[15]|min_length[2]');
		$this->form_validation->set_rules('start_date', "Start date", 'trim|required');
		$this->form_validation->set_rules('end_date', "End date", 'trim|required');
		$this->form_validation->set_rules('message', "Message", 'trim|required|max_length[80]|min_length[2]');
		$this->form_validation->set_rules('group', "User group", 'trim|required|numeric');
		$this->form_validation->set_rules('rights', "Access rights", 'trim|required|numeric');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/notifications/add_notice'));

        } else {

        	// set variable for input data
        	$name = $this->input->post("name", true);
        	$start_date = $this->input->post("start_date", true);
        	$end_date = $this->input->post("end_date", true);
        	$message = $this->input->post("message", true);
        	$group = $this->input->post("group", true);
        	$rights = $this->input->post("rights", true);

        	// add notification
	        $id = $this->notifications_model->add_notification(array(
		        "app_id"		=> $app->id,
		        "name"			=> $name,
		        "message"		=> $message,
		        "start_date"	=> $start_date,
		        "end_date"		=> $end_date,
		        "rights"		=> $rights,
		        "users_group"	=> $group
		        )
		    );

		    $this->session->set_flashdata('success', $this->lang->line('alert_62'));
            redirect(site_url('my/apps/'.$app->id.'/notifications/edit_notice/'.$id.''));

        }
	}

	/*
	 * Update notice form
	 * @param int $notice_id
	 */
	public function update_notice($notice_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		if (is_null($notice_id) OR ! is_numeric($notice_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_60'));
            redirect(site_url('my/apps'));

	    }

	    $notice = $this->notifications_model->get_alert($notice_id);

	    if (!$notice) {

			// empty notifications
	    	$this->session->set_flashdata('error', $this->lang->line('alert_61'));
            redirect(site_url('my/apps'));

		}

		$this->form_validation->set_rules('name', "Name", 'trim|required|max_length[15]|min_length[2]');
		$this->form_validation->set_rules('start_date', "Start date", 'trim|required');
		$this->form_validation->set_rules('end_date', "End date", 'trim|required');
		$this->form_validation->set_rules('message', "Message", 'trim|required|max_length[80]|min_length[2]');
		$this->form_validation->set_rules('group', "User group", 'trim|required|numeric');
		$this->form_validation->set_rules('rights', "Access rights", 'trim|required|numeric');

		if ($this->form_validation->run() == false) {

            $this->session->set_flashdata('error', validation_errors());
            redirect(site_url('my/apps/'.$app->id.'/notifications/add_notice'));

        } else {

        	// set variable for input data
        	$name = $this->input->post("name", true);
        	$start_date = $this->input->post("start_date", true);
        	$end_date = $this->input->post("end_date", true);
        	$message = $this->input->post("message", true);
        	$group = $this->input->post("group", true);
        	$rights = $this->input->post("rights", true);

        	// update notification
	        $this->notifications_model->update_notice($notice->id, array(
		        "name"			=> $name,
		        "message"		=> $message,
		        "start_date"	=> $start_date,
		        "end_date"		=> $end_date,
		        "rights"		=> $rights,
		        "users_group"	=> $group
		        )
		    );

		    $this->session->set_flashdata('success', $this->lang->line('alert_62'));
            redirect(site_url('my/apps/'.$app->id.'/notifications/edit_notice/'.$notice->id.''));

        }
	}

	/*
	 * Update notice form
	 * @param int $notice_id
	 */
	public function delete_notice($notice_id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if ($app->type) {

			redirect(site_url('my/apps'));

		}

		if (is_null($notice_id) OR ! is_numeric($notice_id)) {

	    	$this->session->set_flashdata('error', $this->lang->line('alert_60'));
            redirect(site_url('my/apps'));

	    }

	    $notice = $this->notifications_model->get_alert($notice_id);

	    if ($notice) {

			$this->notifications_model->del_alert($notice->id);

			$this->session->set_flashdata('success', $this->lang->line('alert_3'));
            redirect(site_url('my/apps/'.$app->id.'/notifications/'));

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_63'));
            redirect(site_url('my/apps/'.$app->id.'/notifications/'));

		}

	}

	/*
	 * PUSH newsletter
	 */
	public function newsletter()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$settings = $this->settings_model->get_settings($app->id);

		if ($settings->onesignal_api_key & $settings->onesignal_rest_api & $settings->onesignal_auth_key) {

			// get detail app
			$ch = curl_init();
		    curl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/apps/'.$settings->onesignal_api_key.'');
		    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',
		    'Authorization: Basic '.$settings->onesignal_auth_key.''));
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		    curl_setopt($ch, CURLOPT_HEADER, FALSE);
		    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

		    $final = curl_exec($ch);
		    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			$response = json_decode($final, true);
		    curl_close($ch);

		    if ($httpCode == 200) {

		    	$start_index = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;

		    	$this->config->load('pagination', TRUE);
		    	$settings_pagination = $this->config->item('pagination');

		    	// get notifications list
		    	$list = curl_init();
			    curl_setopt($list, CURLOPT_URL, 'https://onesignal.com/api/v1/notifications?app_id='.$response['id'].'&limit='.$settings_pagination['per_page'].'&offset='.$start_index.'');
			    curl_setopt($list, CURLOPT_HTTPHEADER, array('Content-Type: application/json',
			    'Authorization: Basic '.$settings->onesignal_rest_api.''));
			    curl_setopt($list, CURLOPT_RETURNTRANSFER, TRUE);
			    curl_setopt($list, CURLOPT_HEADER, FALSE);
			    curl_setopt($list, CURLOPT_SSL_VERIFYPEER, FALSE);

			    $final_list = curl_exec($list);
			    $httpCodeList = curl_getinfo($list, CURLINFO_HTTP_CODE);
				$response_list = json_decode($final_list, true);
			    curl_close($list);

			    if ($httpCode == 200) {

			    	// init params
			        $params = array();
			        $total_records = $response_list['total_count'];

			        $settings_pagination['total_rows'] = $response_list['total_count'];
			        $settings_pagination['base_url'] = base_url() . 'my/apps/'.$app->id.'/notifications/newsletter';

			        if ($total_records > 0)
					{
					    // get current page records
					    $params["notifications"] = $response_list['notifications'];
					             
					    // use the settings to initialize the library
					    $this->pagination->initialize($settings_pagination);
					             
					    // build paging links
					    $params["links"] = $this->pagination->create_links();
					}

					$params["total_records"] = $total_records;
					$params["app"] = $app;
					$params["settings"] = $settings;
					$params["response"] = $response;

					$this->template->set('title', $this->lang->line('seo_14'));
					$this->template->load('cms', 'contents' , 'notifications/newsletter', $params);

			    } else {

			    	$this->session->set_flashdata('error', $this->lang->line('alert_64'));
			    	redirect(site_url('my/apps/'.$app->id.'/settings/push'));

			    }


		    } else {

		    	$this->session->set_flashdata('error', $this->lang->line('alert_65'));
            	redirect(site_url('my/apps/'.$app->id.'/settings/push'));

		    }

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_66'));
            redirect(site_url('my/apps/'.$app->id.'/settings/push'));

		}

	}

	/*
	 * Detail PUSH newsletter
	 * @param string $id
	 */
	public function push_detail($id)
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		if (!empty($id)) {

			$push_id = $this->security->xss_clean($id);

			$settings = $this->settings_model->get_settings($app->id);

			if ($settings->onesignal_api_key & $settings->onesignal_rest_api & $settings->onesignal_auth_key) {

				// get detail notification
				$ch = curl_init();
			    curl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/notifications/'.$push_id.'?app_id='.$settings->onesignal_api_key.'');
			    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',
			    'Authorization: Basic '.$settings->onesignal_rest_api.''));
			    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			    curl_setopt($ch, CURLOPT_HEADER, FALSE);
			    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

			    $final = curl_exec($ch);
			    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				$response = json_decode($final, true);
			    curl_close($ch);

			    if ($httpCode == 200) {

			    	$data = array(
						"app"		=>  $app,
						"settings"	=>  $settings,
						"response"	=>  $response
					);

			    	$this->template->set('title', $this->lang->line('seo_15'));
					$this->template->load('cms', 'contents' , 'notifications/push_detail', $data);

			    } else {

			    	$this->session->set_flashdata('error', $this->lang->line('alert_64'));
			    	redirect(site_url('my/apps/'.$app->id.'/settings/push'));

			    }

			} else {

				$this->session->set_flashdata('error', $this->lang->line('alert_66'));
            	redirect(site_url('my/apps/'.$app->id.'/settings/push'));

			}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_67'));
			redirect(site_url('my/apps/'.$app->id.'/notifications/newsletter'));

		}

	}

	/*
	 * New push view page
	 */
	public function add_push()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$settings = $this->settings_model->get_settings($app->id);

		$data = array(
			"app"		=>  $app,
			"settings"	=>  $settings
		);

    	$this->template->set('title', $this->lang->line('seo_16'));
		$this->template->load('cms', 'contents' , 'notifications/add_push', $data);
	}

	/*
	 * Send push newsletter
	 */
	public function send_push()
	{
		$app = $this->apps_model->get_app($this->uri->segment(3, 0));

		if (!$app) {

			// empty app
	    	$this->session->set_flashdata('error', $this->lang->line('alert_4'));
            redirect(site_url('my/apps'));

		}

		$settings = $this->settings_model->get_settings($app->id);

		if ($settings->onesignal_api_key & $settings->onesignal_rest_api & $settings->onesignal_auth_key) {

			$this->form_validation->set_rules('title', "Title", 'trim|required|max_length[100]|min_length[2]');
			$this->form_validation->set_rules('message', "Message", 'trim|required|max_length[300]|min_length[2]');
			$this->form_validation->set_rules('android_led_color', "LED collor for Android", 'trim|max_length[8]|min_length[8]');

			if ($this->form_validation->run() == false) {

	            $this->session->set_flashdata('error', validation_errors());
	            redirect(site_url('my/apps/'.$app->id.'/notifications/add_push'));

        	} else {

        		// set variable for input data
	        	$title = $this->input->post("title", true);
	        	$message = $this->input->post("message", true);
	        	$android_led_color = $this->input->post("android_led_color", true);
	        	$icon = $this->icons_model->get_icons($app->id);

	        	// Image upload
	        	$config['upload_path']      = ''.$_SERVER['DOCUMENT_ROOT'].'/uploads/push';
	        	$config['allowed_types']    = 'gif|jpg|png';
	        	$config['max_size']         = 40000; // 5mb
	        	$config['encrypt_name']     = TRUE;
	        	$config['remove_spaces']    = TRUE;

	        	$this->load->library('upload', $config);

		        // Check image for Android
		        if (!$this->upload->do_upload('android_big_picture')) {

		            $android_big_picture = '';

		        } else {

		        	$android_big_picture = ''.base_url().'uploads/push/'.$this->upload->data('file_name').'';

		        }


	        	$headings = array(
			        "en" => $title
			    );

	        	$content = array(
			        "en" => $message
			    );

			    $fields = array(
			        'app_id' 			=> $settings->onesignal_api_key,
			        'included_segments' => array('All'),
			        'contents' 			=> $content,
			        'headings' 			=> $headings,
			        'android_led_color' => $android_led_color,
			        'big_picture' 		=> $android_big_picture,
			        'large_icon' 		=> base_url('uploads/notify/'.$icon->notify_android.'')
			    );

			    $fields = json_encode($fields);

        		// create notification
				$ch = curl_init();
			    curl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/notifications/');
			    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8',
			    'Authorization: Basic '.$settings->onesignal_rest_api.''));
			    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			    curl_setopt($ch, CURLOPT_HEADER, FALSE);
			    curl_setopt($ch, CURLOPT_POST, TRUE);
    			curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
			    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

			    $final = curl_exec($ch);
			    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				$response = json_decode($final, true);
			    curl_close($ch);

			    if ($httpCode == 200) {

				    $this->session->set_flashdata('success', $this->lang->line('alert_1'));
				    redirect(site_url('my/apps/'.$app->id.'/notifications/push_detail/'.$response['id'].''));

				} else {

					$this->session->set_flashdata('error', $this->lang->line('alert_64'));
			    	redirect(site_url('my/apps/'.$app->id.'/notifications/add_push'));

				}

        	}

		} else {

			$this->session->set_flashdata('error', $this->lang->line('alert_66'));
            redirect(site_url('my/apps/'.$app->id.'/settings/push'));

		}
	}
}