<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chat extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('users_model');
    	$this->load->model('messages_model');
    	$this->load->model('icons_model');
    	$this->load->model('settings_model');
    	$this->load->model('template_model');

	}

	/*
	 * Get list messages
	 */
	public function get_start_messages()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["chat_token"])) {

				$chat_token = $this->security->xss_clean($_GET["chat_token"]);

				$dialogue = $this->messages_model->get_dialogue_detail_for_user($chat_token);

				if ($dialogue) {

					$icon = $this->icons_model->get_icons($app_id);

					$messages = $this->messages_model->get_start_messages($app_id, $dialogue->id);

					if ($messages) {

						foreach ($messages as $datas) {

							if ($datas->status == 1 & $datas->type == 1)

							// update read status
							$this->messages_model->update_message($datas->id, array(
						        "status"	=> 2
						        )
						    );

						}

					}

					$response = array ('event' => 'success', 'messages' => $messages, 'avatar' => $icon->chat_avatar);

					echo json_encode($response);

				} else {

					$response = array ('event' => 'empty');

					echo json_encode($response);

				}

			} else {

				// create dialogue
				$date = date('Y-m-d H:i:s');
				$value_1 = rand(0000000000, 5555555555);
				$value_2 = rand(1111111111, 9999999999);
				$chat_token = hash('sha256', $date."-".$value_1."-".$value_2);

				if ($this->input->get_request_header('authorization', TRUE)) {

					$token = $this->input->get_request_header('authorization', TRUE);

					$user = $this->users_model->get_user_from_token($token);

					if ($user) {

						$chat_user = $user->id;

					} else {

						$chat_user = 0;

					}


				} else {

					$chat_user = 0;

				}

				$id = $this->messages_model->add_dialogue(array(
					"app_id"	=> $app_id,
					"token"		=> $chat_token,
					"user"		=> $chat_user,
					"ban"		=> 1
					)
				);

				$response = array ('event' => 'new', 'chat_token' => $chat_token);

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}

	}

	/*
	 * Send message
	 */
	public function send_message()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["chat_token"])) {

				$chat_token = $this->security->xss_clean($_GET["chat_token"]);

				$dialogue = $this->messages_model->get_dialogue_detail_for_user($chat_token);

				if ($dialogue) {

					if ($dialogue->ban == 2) {

						$response = array ('event' => 'fail', 'message' => 'You can not send messages');

						echo json_encode($response);

					} else {

						$this->form_validation->set_rules('message', "Message", 'trim|required|max_length[1000]|min_length[1]');

						if ($this->form_validation->run() == false) {

							$response = array ('event' => 'fail', 'message' => validation_errors());

							echo json_encode($response);

						} else {

							// Set variables for input data
	      					$message = $this->input->post("message", true);

	      					$date = date('Y-m-d H:i:s');

	      					// check user
	      					if (!$dialogue->user) {

	      						if ($this->input->get_request_header('authorization', TRUE)) {

	      							$token = $this->input->get_request_header('authorization', TRUE);

									$user = $this->users_model->get_user_from_token($token);

									if ($user) {

										// update update_dialogue
										$this->messages_model->add_message(array(
										    "user"		=> $user->id,
										    )
										);

										$user_id = $user->id;

									} else {

										$user_id = $dialogue->user;

									}

	      						} else {

	      							$user_id = $dialogue->user;

	      						}

	      					} else {

	      						$user_id = $dialogue->user;

	      					}

	      					$this->messages_model->add_message(array(
							    "app_id"		=> $app_id,
							    "dialogue"		=> $dialogue->id,
							    "user"			=> $user_id,
							    "type"			=> 2,
							    "created"		=> $date,
							    "message"		=> $message,
							    "status"		=> 1
							    )
							);

							// send email notification for admin
			        		$email_template = $this->template_model->get_email_template(7);

			        		if ($email_template->status == 1) {

			        			$settings = $this->settings_model->get_settings($app_id);

			        			if (!empty($_GET["user"])) {

			        				$mail_user = $user->username;

			        			} else {

			        				$mail_user = 'Not register';

			        			}

			        			$app = $this->apps_model->get_app($app_id);

			        			$messages = $email_template->message;
					        	$email_variables = array('[USER]', '[MESSAGE]', '[APPNAME]');
					        	$code_variable = array($mail_user, $message, $app->name);
					        	$replace = str_replace($email_variables, $code_variable, $messages);

					        	$this->send_email->start_send($app_id, $settings->admin_email, $email_template->title, $replace);

			        		}

							$response = array ('event' => 'success', 'message' => $message);

							echo json_encode($response);

						}

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'Dialogue not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Chat token not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Get new messages
	 */
	public function get_new_messages()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["chat_token"])) {

				$chat_token = $this->security->xss_clean($_GET["chat_token"]);

				$dialogue = $this->messages_model->get_dialogue_detail_for_user($chat_token);

				if ($dialogue) {

					$messages = $this->messages_model->get_new_messages_for_user($app_id, $dialogue->id);

					if ($messages) {

						$icon = $this->icons_model->get_icons($app_id);

						$count = $this->messages_model->get_total_unread_for_user($app_id, $dialogue->id);

						$total = $count - 1;

						foreach ($messages as $datas) {

							// update read status
							$this->messages_model->update_message($datas->id, array(
						        "status"	=> 2
						        )
						    );

						}

						$response = array ('event' => 'success', 'count' => $total, 'messages' => $messages, 'avatar' => $icon->chat_avatar);

						echo json_encode($response, JSON_FORCE_OBJECT);

					} else {

						$response = array ('event' => 'empty');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'Dialogue not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Chat token not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

}