<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Content extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('users_model');
    	$this->load->model('posts_model');
    	$this->load->model('comments_model');
    	$this->load->model('galleries_model');
    	$this->load->model('icons_model');
    	$this->load->model('settings_model');
    	$this->load->model('template_model');

    	// ** Load libraries ** //
		$this->load->library('protect');

	}

	/*
	 * Get list categories
	 */
	public function get_categories()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if ($this->input->get_request_header('authorization', TRUE)) {

				$token = $this->input->get_request_header('authorization', TRUE);

				$user = $this->users_model->get_user_from_token($token);

				if ($user) {

					$categories = $this->posts_model->get_start_categories_for_register_users($app_id, $user->user_group);

					if ($categories) {

						$response = array ('event' => 'success', "categories" => $categories);

						echo json_encode($response);

					} else {

						$response = array ('event' => 'fail', 'message' => 'Categories not yet created');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'User not found');

					echo json_encode($response);

				}

			} else {

				// not auth user
				$categories = $this->posts_model->get_start_categories_for_unregister_users($app_id);

				if ($categories) {

					$response = array ('event' => 'success', "categories" => $categories);

					echo json_encode($response);

				} else {

					$response = array ('event' => 'fail', 'message' => 'Categories not yet created');

					echo json_encode($response);

				}

			}


		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Get list categories for infiniti scroll
	 */
	public function get_categories_infiniti()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if ($this->input->get_request_header('authorization', TRUE)) {

				$token = $this->input->get_request_header('authorization', TRUE);

				$user = $this->users_model->get_user_from_token($token);

				if ($user) {

					if (!empty($_GET["offset"])) {

						$offset = $this->security->xss_clean($_GET["offset"]);

						$categories = $this->posts_model->get_infiniti_categories_for_register_users($offset, $app_id, $user->user_group);

						if ($categories) {

							$count = $this->posts_model->get_total_categories_infiniti_scroll_register($offset, $app_id, $user->user_group);

							$total_count = $count-1;

							$response = array ('event' => 'success', 'count' => $total_count, 'categories' => $categories);

							echo json_encode($response, JSON_FORCE_OBJECT);

						} else {

							$response = array ('event' => 'empty');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'Offset not received');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'User not found');

					echo json_encode($response);

				}

			} else {

				// not login user
				if (!empty($_GET["offset"])) {

					$offset = $this->security->xss_clean($_GET["offset"]);

					$categories = $this->posts_model->get_infiniti_categories_for_unregister_users($offset, $app_id);

					if ($categories) {

						$count = $this->posts_model->get_total_categories_infiniti_scroll($offset, $app_id);

						$total_count = $count-1;

						$response = array ('event' => 'success', 'count' => $total_count, 'categories' => $categories);

						echo json_encode($response, JSON_FORCE_OBJECT);

					} else {

						$response = array ('event' => 'empty');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'Offset not received');

					echo json_encode($response);

				}

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}

	}

	/*
	 * Get posts
	 */
	public function get_posts()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["category_id"])) {

				$category_id = $this->security->xss_clean($_GET["category_id"]);

				$category = $this->posts_model->get_category($category_id);

				if ($category) {

					if ($this->input->get_request_header('authorization', TRUE)) {

						$token = $this->input->get_request_header('authorization', TRUE);

						$user = $this->users_model->get_user_from_token($token);

						if ($user) {

							$posts = $this->posts_model->get_start_posts_for_register_users($app_id, $category->id, $user->user_group);

							if ($posts) {

								$response = array ('event' => 'success', "category_name" => $category->name, "category_info" => $category->info, "template" => $category->view, "posts" => $posts);

								echo json_encode($response);

							} else {

								$response = array ('event' => 'fail', 'message' => 'Posts not found');

								echo json_encode($response);

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'User not found');

							echo json_encode($response);

						}

					} else {

						// user not login
						$posts = $this->posts_model->get_start_posts_for_unregister_users($app_id, $category->id);

						if ($posts) {

							$response = array ('event' => 'success', "category_name" => $category->name, "category_info" => $category->info, "template" => $category->view, "posts" => $posts);

							echo json_encode($response);

						} else {

							$response = array ('event' => 'fail', 'message' => 'Posts not found');

							echo json_encode($response);

						}

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'Category not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Category ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}

	}

	/*
	 * Get list posts for infiniti scroll
	 */
	public function get_posts_infiniti()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["category_id"])) {

				$category_id = $this->security->xss_clean($_GET["category_id"]);

				$category = $this->posts_model->get_category($category_id);

				if ($category) {

					if ($this->input->get_request_header('authorization', TRUE)) {

						$token = $this->input->get_request_header('authorization', TRUE);

						$user = $this->users_model->get_user_from_token($token);

						if ($user) {

							// user login
							if (!empty($_GET["offset"])) {

								$offset = $this->security->xss_clean($_GET["offset"]);

								$posts = $this->posts_model->get_infiniti_posts_for_register_users($offset, $app_id, $category->id, $user->user_group);

								if ($posts) {

									$count = $this->posts_model->get_total_posts_infiniti_scroll_register($offset, $app_id, $category->id, $user->user_group);

									$total_count = $count-1;

									$response = array ('event' => 'success', 'count' => $total_count, 'template' => $category->view, 'posts' => $posts);

	            					echo json_encode($response, JSON_FORCE_OBJECT);

								} else {

									$response = array ('event' => 'empty');

									echo json_encode($response);

								}

							} else {

								$response = array ('event' => 'fail', 'message' => 'Offset not received');

								echo json_encode($response);

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'User not found');

							echo json_encode($response);

						}

					} else {

						// user not login
						if (!empty($_GET["offset"])) {

							$offset = $this->security->xss_clean($_GET["offset"]);

							$posts = $this->posts_model->get_infiniti_posts_for_unregister_users($offset, $app_id, $category->id);

							if ($posts) {

								$count = $this->posts_model->get_total_posts_infiniti_scroll($offset, $app_id, $category->id);

								$total_count = $count-1;

								$response = array ('event' => 'success', 'count' => $total_count, 'template' => $category->view, 'posts' => $posts);

            					echo json_encode($response, JSON_FORCE_OBJECT);

							} else {

								$response = array ('event' => 'empty');

								echo json_encode($response);

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'Offset not received');

							echo json_encode($response);
								
						}

					}

				} else {

					// category not found
					$response = array ('event' => 'fail', 'message' => 'Category not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Category ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Get detail post
	 */
	public function get_post()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			$icon = $this->icons_model->get_icons($app_id);

			if (!empty($_GET["post_id"])) {

				$post_id = $this->security->xss_clean($_GET["post_id"]);

				if ($this->input->get_request_header('authorization', TRUE)) {

					$token = $this->input->get_request_header('authorization', TRUE);

					$user = $this->users_model->get_user_from_token($token);

					if ($user) {

						$post = $this->posts_model->get_post_register($post_id, $user->user_group);

						if ($post) {

							$comments = $this->comments_model->get_comments_for_page($app_id, $post->id);

							if ($comments) {

								$fruits = array();

								foreach ($comments as $data) {

									$fruits[] = array('id' => $data->id,'name' => $this->template->get_user_fullname($data->user), 'created' => $data->created, 'comment' => $data->comment, 'type' => $data->type, 'reply_id' => $data->reply_id, 'avatar' => $this->template->get_user_avatar($data->user), 'replys' => $this->template->get_replyes_app($app_id, $post->id, $data->id), 'user_id' => $data->user);

								}

							} else {

								$fruits = null;

							}

							$total_comments = $this->comments_model->get_total_for_page($app_id, $post->id);

							$gallery = $this->galleries_model->get_gallery($post->gallery);

							if ($gallery) {

								$items = $this->galleries_model->get_gallery_items($gallery->id);

								$response = array ('event' => 'success', 'post' => $post, 'comments' => $fruits, 'total_comments' => $total_comments, 'gallery' => $gallery, 'items' => $items, 'user' => $user->id, 'avatar' => $icon->comment_avatar);

								echo json_encode($response);

							} else {

								$response = array ('event' => 'success', 'post' => $post, 'comments' => $fruits, 'total_comments' => $total_comments, 'gallery' => $gallery, 'items' => null, 'user' => $user->id, 'avatar' => $icon->comment_avatar);

								echo json_encode($response);

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'Post not found');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'User not found');

						echo json_encode($response);

					}

				} else {

					// user not login
					$post = $this->posts_model->get_post_unregister($post_id);

					if ($post) {

						$total_comments = $this->comments_model->get_total_for_page($app_id, $post->id);

						$comments = $this->comments_model->get_comments_for_page($app_id, $post->id);

						if ($comments) {

							$fruits = array();

							foreach ($comments as $data) {

								$fruits[] = array('id' => $data->id, 'name' => $this->template->get_user_fullname($data->user), 'created' => $data->created, 'comment' => $data->comment, 'type' => $data->type, 'reply_id' => $data->reply_id, 'avatar' => $this->template->get_user_avatar($data->user), 'replys' => $this->template->get_replyes_app($app_id, $post->id, $data->id), 'user_id' => $data->user);

							}

						} else {

							$fruits = null;

						}

						$gallery = $this->galleries_model->get_gallery($post->gallery);

						if ($gallery) {

							$items = $this->galleries_model->get_gallery_items($gallery->id);

							$response = array ('event' => 'success', 'post' => $post, 'comments' => $fruits, 'total_comments' => $total_comments, 'gallery' => $gallery, 'items' => $items, 'avatar' => $icon->comment_avatar);

							echo json_encode($response);

						} else {

							$response = array ('event' => 'success', 'post' => $post, 'comments' => $fruits, 'total_comments' => $total_comments, 'gallery' => $gallery, 'items' => null, 'avatar' => $icon->comment_avatar);

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'Post not found');

						echo json_encode($response);

					}

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Post ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Get detail post
	 */
	public function delete_comment()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["comment_id"])) {

				$comment_id = $this->security->xss_clean($_GET["comment_id"]);

				if ($this->input->get_request_header('authorization', TRUE)) {

					$token = $this->input->get_request_header('authorization', TRUE);

					$user = $this->users_model->get_user_from_token($token);

					if ($user) {

						$comment = $this->comments_model->get_comment($comment_id);

						if ($comment) {

							if ($user->id == $comment->user) {

						    	// one delete
						    	$this->comments_model->del_comment($comment->id);

						    	$response = array ('event' => 'success');

								echo json_encode($response);

							} else {

								$response = array ('event' => 'fail', 'message' => 'Access disabled');

								echo json_encode($response);

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'Comment not found');

							echo json_encode($response);

						}

					} else {

						// user not found
						$response = array ('event' => 'fail', 'message' => 'User not found');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'Authorization required');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Comment ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Get comments
	 */
	public function get_comments()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			$icon = $this->icons_model->get_icons($app_id);

			if (!empty($_GET["post_id"])) {

				$post_id = $this->security->xss_clean($_GET["post_id"]);

				if ($this->input->get_request_header('authorization', TRUE)) {

					$token = $this->input->get_request_header('authorization', TRUE);

					$user = $this->users_model->get_user_from_token($token);

					if ($user) {

						$post = $this->posts_model->get_post_register($post_id, $user->user_group);

						if ($post) {

							$comments = $this->comments_model->get_comments_for_start_page($app_id, $post->id);

							if ($comments) {

								$fruits = array();

								foreach ($comments as $data) {

									$fruits[] = array('id' => $data->id,'name' => $this->template->get_user_fullname($data->user), 'created' => $data->created, 'comment' => $data->comment, 'type' => $data->type, 'reply_id' => $data->reply_id, 'avatar' => $this->template->get_user_avatar($data->user), 'replys' => $this->template->get_replyes_app($app_id, $post->id, $data->id), 'user_id' => $data->user);

								}

								$response = array ('event' => 'success', 'post' => $post, 'comments' => $fruits, 'user' => $user->id, 'avatar' => $icon->comment_avatar);

								echo json_encode($response);

							} else {

								$response = array ('event' => 'fail', 'message' => 'Comments not found');

								echo json_encode($response);

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'Post not found');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'User not found');

						echo json_encode($response);

					}

				} else {

					// user not login
					$post = $this->posts_model->get_post_unregister($post_id);

					if ($post) {

						$comments = $this->comments_model->get_comments_for_start_page($app_id, $post->id);

						if ($comments) {

							$fruits = array();

							foreach ($comments as $data) {

								$fruits[] = array('id' => $data->id,'name' => $this->template->get_user_fullname($data->user), 'created' => $data->created, 'comment' => $data->comment, 'type' => $data->type, 'reply_id' => $data->reply_id, 'avatar' => $this->template->get_user_avatar($data->user), 'replys' => $this->template->get_replyes_app($app_id, $post->id, $data->id), 'user_id' => $data->user);

							}

							$response = array ('event' => 'success', 'post' => $post, 'comments' => $fruits, 'avatar' => $icon->comment_avatar);

							echo json_encode($response);

						} else {

							$response = array ('event' => 'fail', 'message' => 'Comments not found');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'Post not found');

						echo json_encode($response);

					}

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Post ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}

	}

	/*
	 * Get infiniti comments
	 */
	public function get_infiniti_comments()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["post_id"])) {

				$post_id = $this->security->xss_clean($_GET["post_id"]);

				if ($this->input->get_request_header('authorization', TRUE)) {

					$token = $this->input->get_request_header('authorization', TRUE);

					$user = $this->users_model->get_user_from_token($token);

					if ($user) {

						$post = $this->posts_model->get_post_register($post_id, $user->user_group);

						if ($post) {

							if (!empty($_GET["offset"])) {

								$offset = $this->security->xss_clean($_GET["offset"]);

								$comments = $this->comments_model->get_comments_for_infiniti($offset, $app_id, $post->id);

								if ($comments) {

									$fruits = array();

									foreach ($comments as $data) {

										$fruits[] = array('id' => $data->id, 'name' => $this->template->get_user_fullname($data->user), 'created' => $data->created, 'comment' => $data->comment, 'type' => $data->type, 'reply_id' => $data->reply_id, 'avatar' => $this->template->get_user_avatar($data->user), 'replys' => $this->template->get_replyes_app($app_id, $post->id, $data->id), 'user_id' => $data->user, 'count_replys' => $this->comments_model->get_total_reply_comments($app_id, $post->id, $data->id));

									}

									$count = $this->comments_model->get_total_comments_infiniti_scroll($offset, $app_id, $post->id);

									$total_count = $count-1;

									$response = array ('event' => 'success', 'post' => $post, 'comments' => $fruits, 'count' => $total_count, 'user' => $user->id);

									echo json_encode($response, JSON_FORCE_OBJECT);

								} else {

									$response = array ('event' => 'empty');

									echo json_encode($response);

								}

							} else {

								$response = array ('event' => 'fail', 'message' => 'Offset ID not received');

								echo json_encode($response);

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'Post not found');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'User not found');

						echo json_encode($response);

					}

				} else {

					// user not login
					if (!empty($_GET["offset"])) {

						$offset = $this->security->xss_clean($_GET["offset"]);

						$post = $this->posts_model->get_post_unregister($post_id);

						$comments = $this->comments_model->get_comments_for_infiniti($offset, $app_id, $post->id);

						if ($comments) {

							$fruits = array();

							foreach ($comments as $data) {

								$fruits[] = array('id' => $data->id, 'name' => $this->template->get_user_fullname($data->user), 'created' => $data->created, 'comment' => $data->comment, 'type' => $data->type, 'reply_id' => $data->reply_id, 'avatar' => $this->template->get_user_avatar($data->user), 'replys' => $this->template->get_replyes_app($app_id, $post->id, $data->id), 'user_id' => $data->user, 'count_replys' => $this->comments_model->get_total_reply_comments($app_id, $post->id, $data->id));

							}

							$count = $this->comments_model->get_total_comments_infiniti_scroll($offset, $app_id, $post->id);

							$total_count = $count-1;

							$response = array ('event' => 'success', 'post' => $post, 'comments' => $fruits, 'count' => $total_count, 'user' => '1');

							echo json_encode($response, JSON_FORCE_OBJECT);

						} else {

							$response = array ('event' => 'empty');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'Offset ID not received');

						echo json_encode($response);

					}


				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Post ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * New comment
	 */
	public function add_comment()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["post_id"])) {

				$post_id = $this->security->xss_clean($_GET["post_id"]);

				if ($this->input->get_request_header('authorization', TRUE)) {

					$token = $this->input->get_request_header('authorization', TRUE);

					$user = $this->users_model->get_user_from_token($token);

					if ($user) {

						$post = $this->posts_model->get_active_post($post_id);

						if ($post) {

							if ($post->comments == 1) {

								$this->form_validation->set_rules('comment', "Comment", 'trim|required|max_length[500]|min_length[2]');

								if ($this->form_validation->run() == false) {

									$response = array ('event' => 'fail', 'message' => validation_errors());

									echo json_encode($response);

								} else {

									// set variable for input data
	        						$comment = $this->input->post("comment", true);

	        						$settings = $this->settings_model->get_settings($app_id);

	        						if ($settings->check_comments) { //true moderation

	        							$id = $this->comments_model->add_comment(array(
										    "app_id"		=> $app_id,
										    "post_id"		=> $post->id,
										    "created"		=> date('Y-m-d H:i:s'),
										    "user"			=> $user->id,
										    "comment"		=> $comment,
										    "type"			=> 1,
										    "reply_id"		=> 0,
										    "status"		=> 2
										    )
										);

										$response = array ('event' => 'success', 'info' => 'Сomment will be published after moderation', 'comment' => $comment, 'name' => $this->template->get_user_fullname($user->id), 'avatar' => $this->template->get_user_avatar($user->id), 'user_id' => $user->id, 'id' => $id);

										echo json_encode($response);

	        						} else {

	        							$id = $this->comments_model->add_comment(array(
										    "app_id"		=> $app_id,
										    "post_id"		=> $post->id,
										    "created"		=> date('Y-m-d H:i:s'),
										    "user"			=> $user->id,
										    "comment"		=> $comment,
										    "type"			=> 1,
										    "reply_id"		=> 0,
										    "status"		=> 1
										    )
										);

										$response = array ('event' => 'success', 'info' => 'Comment added', 'comment' => $comment, 'name' => $this->template->get_user_fullname($user->id), 'avatar' => $this->template->get_user_avatar($user->id), 'user_id' => $user->id, 'id' => $id);

										echo json_encode($response);

	        						}

	        						// send email notification for admin
					        		$email_template = $this->template_model->get_email_template(5);

					        		if ($email_template->status == 1) {

					        			$settings = $this->settings_model->get_settings($app_id);

					        			$app = $this->apps_model->get_app($app_id);

					        			$message = $email_template->message;
							        	$email_variables = array('[POST]', '[USER]', '[COMMENT]', '[APPNAME]');
							        	$code_variable = array($post->name, $user->username, $comment, $app->name);
							        	$replace = str_replace($email_variables, $code_variable, $message);

							        	$this->send_email->start_send($app_id, $settings->admin_email, $email_template->title, $replace);

					        		}

								}

							} else {

								$response = array ('event' => 'fail', 'message' => 'Comments disabled');

								echo json_encode($response);

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'Post not found');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'User not found');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'User token not received');

					echo json_encode($response);

				}


			} else {

				$response = array ('event' => 'fail', 'message' => 'Post ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

}