<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('users_model');
    	$this->load->model('forms_model');
    	$this->load->model('settings_model');
    	$this->load->model('template_model');

	}

	/*
	 * Detail form
	 */
	public function get_detail_form()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["form_id"])) {

				$form_id = $this->security->xss_clean($_GET["form_id"]);

				$form = $this->forms_model->get_form($form_id);

				if ($form) {

					$form_elements = $this->forms_model->get_form_elements($app_id, $form->id);

					if ($form_elements) {

						$response = array ('event' => 'success', "name" => $form->name, 'elements' => $form_elements);

						echo json_encode($response);

					} else {

						$response = array ('event' => 'fail', 'message' => 'Empty form');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'Form not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Parameter Form ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Send form
	 */
	public function send_form()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["form_id"])) {

				$form_id = $this->security->xss_clean($_GET["form_id"]);

				$form = $this->forms_model->get_form($form_id);

				if ($form) {

					$form_elements = $this->forms_model->get_form_elements($app_id, $form->id);

					if ($form_elements) {

						// form validate
						foreach ($form_elements as $datas) {

							if ($datas->type == 1) {

								if ($datas->required == 1) {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|required');

								} else {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim');

								}

							}

							if ($datas->type == 2) {

								if ($datas->required == 1) {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|required|valid_email');

								} else {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|valid_email');

								}

							}

							if ($datas->type == 3) {

								if ($datas->required == 1) {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|required|numeric');

								} else {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|numeric');

								}

							}

							if ($datas->type == 4) {

								if ($datas->required == 1) {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|required');

								} else {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim');

								}

							}

							if ($datas->type == 5) {

								if ($datas->required == 1) {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|required');

								} else {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim');

								}

							}

							if ($datas->type == 6) {

								if ($datas->required == 1) {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|required');

								} else {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim');

								}

							}

							if ($datas->type == 8) {

								if ($datas->required == 1) {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|required');

								} else {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim');

								}

							}

							if ($datas->type == 10) {

								if ($datas->required == 1) {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|required|numeric');

								} else {

									$this->form_validation->set_rules($datas->prefix, $datas->name, 'trim|numeric');

								}

							}

						}

						if ($this->form_validation->run() == false) {

							$response = array ('event' => 'fail', 'message' => validation_errors());

							echo json_encode($response);

						} else {

							$form_result = json_encode($this->input->post());

							if ($this->input->get_request_header('authorization', TRUE)) {

								$token = $this->input->get_request_header('authorization', TRUE);

								$user = $this->users_model->get_user_from_token($token);

								if ($user) {

									$user_form = $user->id;

								} else {

									$user_form = 0;

								}

								// save form result
			        			$this->forms_model->add_form_receive(array(
							        "app_id"	=> $app_id,
							        "form_id"	=> $form->id,
							        "created"	=> date('Y-m-d H:i:s'),
							        "user"		=> $user_form,
							        "result"	=> $form_result,
							        "status"	=> 2
							        )
							    );

								$response = array ('event' => 'success');

								echo json_encode($response);

							} else {

								// save form result
			        			$this->forms_model->add_form_receive(array(
							        "app_id"	=> $app_id,
							        "form_id"	=> $form->id,
							        "created"	=> date('Y-m-d H:i:s'),
							        "user"		=> 0,
							        "result"	=> $form_result,
							        "status"	=> 2
							        )
							    );

								$response = array ('event' => 'success');

								echo json_encode($response);

							}

							// send email notification for admin
				        	$email_template = $this->template_model->get_email_template(6);

				        	if ($email_template->status == 1) {

				        		$settings = $this->settings_model->get_settings($app_id);

				        		$app = $this->apps_model->get_app($app_id);

				        		$message = $email_template->message;
						        $email_variables = array('[FORM]', '[APPNAME]');
						        $code_variable = array($form->name, $app->name);
						        $replace = str_replace($email_variables, $code_variable, $message);

						        $this->send_email->start_send($app_id, $settings->admin_email, $email_template->title, $replace);

				        	}

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'Empty form');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'Form not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Parameter Form ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

}