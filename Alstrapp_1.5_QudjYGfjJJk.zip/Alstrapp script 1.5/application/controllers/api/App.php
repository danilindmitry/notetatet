<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('users_model');
    	$this->load->model('navigation_model');
    	$this->load->model('statistics_model');
    	$this->load->model('messages_model');
    	$this->load->model('notifications_model');

	}

	/*
	 * App status
	 */
	public function get_status()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			$app = $this->apps_model->get_app($app_id);

			if ($app) {

				$response = array ('event' => 'success', 'online' => $app->online);
				echo json_encode($response);

			} else {

				$response = array ('event' => 'fail', 'message' => 'App not found');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * App status
	 */
	public function get_menu_items()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			$app = $this->apps_model->get_app($app_id);

			if ($app) {

				if ($app->online == 1) {

					if (!empty($_GET["chat_token"])) {

						$chat_token = $this->security->xss_clean($_GET["chat_token"]);

						$dialogue = $this->messages_model->get_dialogue_detail_for_user($chat_token);

						if ($dialogue) {

							$inbox_messages = $this->messages_model->get_total_unread_messages_for_user($app->id, $dialogue->id);

						} else {

							$inbox_messages = 0;

						}

					} else {

						$inbox_messages = 0;

					}

					if ($this->input->get_request_header('authorization', TRUE)) {

						$token = $this->input->get_request_header('authorization', TRUE);

						$user = $this->users_model->get_user_from_token($token);

						if ($user) {

							if ($user->app_id == $app_id) {

								if ($user->block == 1) {

									//$unread_messages = $this->messages_model->get_total_unread_messages_for_user($app->id, $chat_token);

									$main_menu = $this->navigation_model->get_main_menu_for_register_user($app_id, $user->user_group);

									$user_menu = $this->navigation_model->get_user_menu_for_register_user($app_id, $user->user_group);

									$response = array ('event' => 'success', 'user_status' => 1, 'main_menu' => $main_menu, 'user_menu' => $user_menu, 'auth_menu' => 0, 'app_name' => $app->name, 'inbox_messages' => $inbox_messages);

									echo json_encode($response);

								} else {

									$response = array ('event' => 'fail', 'code' => '104', 'message' => 'User blocked.');

									echo json_encode($response);

								}

							} else {

								$response = array ('event' => 'fail', 'code' => '105', 'message' => 'User in app not found. Need to relogin');

								echo json_encode($response);

							}

						} else {


							$response = array ('event' => 'fail', 'code' => '103', 'message' => 'User not found. Need to relogin');

							echo json_encode($response);

						}


					} else {

						$main_menu = $this->navigation_model->get_main_menu_for_unregister_user($app_id);

						$auth_menu = $this->navigation_model->get_auth_menu_for_unregister_user($app_id);

						$response = array ('event' => 'success', 'user_status' => null, 'main_menu' => $main_menu, 'auth_menu' => $auth_menu, 'app_name' => $app->name, 'inbox_messages' => $inbox_messages);

						echo json_encode($response);

					}

				} else {

					// app offline
					$response = array ('event' => 'fail', 'code' => '102', 'message' => 'App offline');

					echo json_encode($response);

				}

			} else {

				// app not found
				$response = array ('event' => 'fail', 'code' => '101', 'message' => 'App not found');

				echo json_encode($response);

			}


		} else {

			$response = array ('event' => 'fail', 'code' => '100', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Add statistic item
	 */
	public function add_statistic()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			$app = $this->apps_model->get_app($app_id);

			$date = date('Y-m-d H:i:s');

			if ($app) {

				if (!empty($_GET["device"])) {

					$device = $this->security->xss_clean($_GET["device"]);

					if ($this->input->get_request_header('authorization', TRUE)) {

						$token = $this->input->get_request_header('authorization', TRUE);

						$user = $this->users_model->get_user_from_token($token);

						if ($user) {

							$user_id = $user->id;

							// notify only for register user
							$count_alerts = $this->notifications_model->get_total_alerts_for_register_users($app->id, $user->user_group, $date);
							$alerts = $this->notifications_model->get_alerts_for_register_users($app->id, $user->user_group, $date);

						} else {

							$user_id = 0;

							// notify only for unregister user
							$count_alerts = $this->notifications_model->get_total_alerts_for_unregister_users($app->id, $date);
							$alerts = $this->notifications_model->get_alerts_for_unregister_users($app->id, $date);

						}

					} else {

						$user_id = 0;

						// notify only for unregister user
						$count_alerts = $this->notifications_model->get_total_alerts_for_unregister_users($app->id, $date);
						$alerts = $this->notifications_model->get_alerts_for_unregister_users($app->id, $date);

					}

					if ($device == 1 or $device == 2) {

						$this->statistics_model->add_item(array(
						    "app_id"	=> $app->id,
						    "date"		=> date('Y-m-d H:i:s'),
						    "user"		=> $user_id,
						    "device"	=> $device
						    )
						);

					}

					if ($count_alerts > 0) {

						$response = array ('event' => 'success', 'count' => $count_alerts-1, 'alerts' => $alerts);

	            		echo json_encode($response, JSON_FORCE_OBJECT);

					} else {

						$response = array ('event' => 'empty');

						echo json_encode($response);

					}

				}

			}

		}
	}

}