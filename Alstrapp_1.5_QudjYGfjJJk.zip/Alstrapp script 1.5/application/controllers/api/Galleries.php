<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Galleries extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('users_model');
    	$this->load->model('galleries_model');

    	// ** Load libraries ** //
		$this->load->library('protect');

	}

	/*
	 * Gallery detail
	 */
	public function get_gallery()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!empty($_GET["gallery_id"])) {

				$gallery_id = $this->security->xss_clean($_GET["gallery_id"]);

				$gallery = $this->galleries_model->get_gallery($gallery_id);

				if ($gallery) {

					$items = $this->galleries_model->get_gallery_items($gallery->id);

					if ($items) {

						$response = array ('event' => 'success', "name" => $gallery->name, 'items' => $items);

						echo json_encode($response);

					} else {

						$response = array ('event' => 'fail', 'message' => 'Images for gallery not found');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'Gallery not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'Parameter Gallery ID not received');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}

	}

}