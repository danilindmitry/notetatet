<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('users_model');
    	$this->load->model('template_model');
    	$this->load->model('settings_model');

    	// ** Load libraries ** //
		$this->load->library('protect');
		$this->load->library('send_email');

	}

	/*
	 * Sign in
	 */
	public function sign_in()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			// post validation
			$this->form_validation->set_rules('username', "Username", 'trim|required|max_length[50]|min_length[3]|alpha_numeric');
			$this->form_validation->set_rules('password', "Password", 'trim|required|max_length[150]|min_length[5]|alpha_numeric');

			if ($this->form_validation->run() == false) {

				$response = array ('event' => 'fail', 'message' => validation_errors());

				echo json_encode($response);

			} else {

				// Set variables for input data
	      		$username = $this->input->post("username", true);
	      		$password = $this->input->post("password", true);

	      		$user = $this->users_model->get_user_from_username($username);

	      		if ($user) {

	      			if ($user->app_id == $app_id) {

	      				$phpass = new PasswordHash(12, false);

		      			// check password
	      				if ($phpass->CheckPassword($password, $user->password)) {

	      					// check block user
	      					if ($user->block == 1) {

	      						// generate auth token
		      					$hash = hash('sha256', date('Y-m-d H:i:s')."-".$user->password."-".$user->email."-".$password);

		      					// update user
		      					$this->users_model->update_user($user->id, array(
						            "token"			=> $hash,
						            "last_login"	=> date('Y-m-d H:i:s')
						            )
						        );

		      					$response = array ('event' => 'success', 'token' => $hash);

								echo json_encode($response);

	      					} else {

	      						$response = array ('event' => 'fail', 'message' => 'Your account has been blocked');

								echo json_encode($response);

	      					}

	      				} else {

	      					$response = array ('event' => 'fail', 'message' => 'Invalid password');

							echo json_encode($response);

	      				}

	      			} else {

	      				$response = array ('event' => 'fail', 'message' => 'User for app not found');

						echo json_encode($response);

	      			}

	      		} else {

	      			$response = array ('event' => 'fail', 'message' => 'Invalid username');

					echo json_encode($response);

	      		}

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Sign up
	 */
	public function sign_up()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			// post validation
			$this->form_validation->set_rules('username', "Username", 'trim|required|max_length[50]|min_length[3]|alpha_numeric');
			$this->form_validation->set_rules('email', "Email", 'trim|required|max_length[100]|valid_email');
			$this->form_validation->set_rules('first_name', "First name", 'trim|required|max_length[50]|min_length[3]');
			$this->form_validation->set_rules('last_name', "Last name", 'trim|required|max_length[70]|min_length[3]');
			$this->form_validation->set_rules('password', "Password", 'trim|required|max_length[150]|min_length[5]|alpha_numeric');
			$this->form_validation->set_rules('repassword', "Repeat password", 'trim|required|matches[password]');

			if ($this->form_validation->run() == false) {

				$response = array ('event' => 'fail', 'message' => validation_errors());

				echo json_encode($response);

			} else {

				// set variable for input data
	        	$username = $this->input->post("username", true);
	        	$email = $this->input->post("email", true);
	        	$first_name = $this->input->post("first_name", true);
	        	$last_name = $this->input->post("last_name", true);
	        	$password = $this->input->post("password", true);
	        	$repassword = $this->input->post("repassword", true);

	        	// check email uniqueness
        		$email_uniqueness = $this->users_model->get_user_from_email($email);

        		if (!$email_uniqueness) {

        			// check username uniqueness
        			$username_uniqueness = $this->users_model->get_user_from_username($username);

        			if (!$username_uniqueness) {

        				// generate HASH for password
      					$stamp_pass = $this->protect->encrypt($password);

        				// add user
        				$user = $this->users_model->add_user(array(
				            "app_id"		=> $app_id,
				            "username"		=> $username,
				            "password"		=> $stamp_pass,
				            "first_name"	=> $first_name,
				            "last_name"		=> $last_name,
				            "email"			=> $email,
				            "created"		=> date('Y-m-d H:i:s'),
				            "user_group"	=> 0,
				            "block"			=> 1
				            )
				        );

				        // generate auth token
		      			$hash = hash('sha256', date('Y-m-d H:i:s')."-".$stamp_pass."-".$email."-".$password);

		      			// update user
		      			$this->users_model->update_user($user, array(
						    "token"			=> $hash,
						    "last_login"	=> date('Y-m-d H:i:s')
						    )
						);

						// send email notification
				        $email_template = $this->template_model->get_email_template(1);

				        if ($email_template->status == 1) {

				        	$app = $this->apps_model->get_app($app_id);

				        	$message = $email_template->message;
				        	$email_variables = array('[APPNAME]');
				        	$code_variable = array($app->name);
				        	$replace = str_replace($email_variables, $code_variable, $message);

						    $this->send_email->start_send($app_id, $email, $email_template->title, $replace);


				        }

				        // send email notification for admin
		        		$email_template = $this->template_model->get_email_template(4);

		        		if ($email_template->status == 1) {

		        			$settings = $this->settings_model->get_settings($app_id);

		        			$app = $this->apps_model->get_app($app_id);

		        			$message = $email_template->message;
				        	$email_variables = array('[USERNAME]', '[EMAIL]', '[APPNAME]');
				        	$code_variable = array($username, $email, $app->name);
				        	$replace = str_replace($email_variables, $code_variable, $message);

				        	$this->send_email->start_send($app_id, $settings->admin_email, $email_template->title, $replace);

		        		}

						$response = array ('event' => 'success', 'token' => $hash);

						echo json_encode($response);

        			} else {

        				$response = array ('event' => 'fail', 'message' => 'This username cannot be used');

						echo json_encode($response);

        			}

        		} else {

        			$response = array ('event' => 'fail', 'message' => 'This email cannot be used');

					echo json_encode($response);

        		}

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * User detail
	 */
	public function detail()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if ($this->input->get_request_header('authorization', TRUE)) {

				$token = $this->input->get_request_header('authorization', TRUE);

				$user = $this->users_model->get_user_from_token($token);

				if ($user) {

					if ($user->app_id == $app_id) {

						if ($user->block == 1) {

							$response = array ('event' => 'success', 'user' => $user);

							echo json_encode($response);

						} else {

							$response = array ('event' => 'fail', 'message' => 'Your account has been blocked');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'User for app not found');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'User not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'User not login');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Update profile
	 */
	public function update_profile()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if ($this->input->get_request_header('authorization', TRUE)) {

				$token = $this->input->get_request_header('authorization', TRUE);

				$user = $this->users_model->get_user_from_token($token);

				if ($user) {

					if ($user->app_id == $app_id) {

						if ($user->block == 1) {

							// post validation
							$this->form_validation->set_rules('username', "Username", 'trim|required|max_length[50]|min_length[3]|alpha_numeric');
							$this->form_validation->set_rules('email', "Email", 'trim|required|max_length[100]|valid_email');
							$this->form_validation->set_rules('first_name', "First name", 'trim|required|max_length[50]|min_length[3]');
							$this->form_validation->set_rules('last_name', "Last name", 'trim|required|max_length[70]|min_length[3]');

							if ($this->form_validation->run() == false) {

								$response = array ('event' => 'fail', 'message' => validation_errors());

								echo json_encode($response);

							} else {

								// set variable for input data
					        	$username = $this->input->post("username", true);
					        	$email = $this->input->post("email", true);
					        	$first_name = $this->input->post("first_name", true);
					        	$last_name = $this->input->post("last_name", true);

					        	if ($user->email != $email) {

					        		// check email uniqueness
				        			if ($this->users_model->get_user_from_email($email)) {

				        				$check_email = 1;

				        			} else {

				        				$check_email = null;

				        			}

					        	} else {

					        		$check_email = null;

					        	}

				        		if (!$check_email) {

				        			if ($user->username != $username) {

						        		// check email uniqueness
					        			if ($this->users_model->get_user_from_username($username)) {

					        				$check_username = 1;

					        			} else {

					        				$check_username = null;

					        			}

						        	} else {

						        		$check_username = null;

						        	}

				        			if (!$check_username) {

				        				$this->users_model->update_user($user->id, array(
								            "username"		=> $username,
								            "first_name"	=> $first_name,
								            "last_name"		=> $last_name,
								            "email"			=> $email,
								            )
								        );

								        $response = array ('event' => 'success');

										echo json_encode($response);

				        			} else {

				        				$response = array ('event' => 'fail', 'message' => 'This username cannot be used');

										echo json_encode($response);

				        			}

				        		} else {

				        			$response = array ('event' => 'fail', 'message' => 'This email cannot be used');

									echo json_encode($response);

				        		}

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'Your account has been blocked');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'User for app not found');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'User not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'User not login');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Update password
	 */
	public function update_password()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if ($this->input->get_request_header('authorization', TRUE)) {

				$token = $this->input->get_request_header('authorization', TRUE);

				$user = $this->users_model->get_user_from_token($token);

				if ($user) {

					if ($user->app_id == $app_id) {

						if ($user->block == 1) {

							$this->form_validation->set_rules('password', "Password", 'trim|required|max_length[150]|alpha_numeric');
							$this->form_validation->set_rules('newpassword', "New password", 'trim|required|max_length[150]|alpha_numeric');
							$this->form_validation->set_rules('repassword', "Repeat new password", 'trim|required|matches[newpassword]|alpha_numeric');

							if ($this->form_validation->run() == false) {

								$response = array ('event' => 'fail', 'message' => validation_errors());

								echo json_encode($response);

							} else {

								// set variable for input data
								$password = $this->input->post("password", true);
								$newpassword = $this->input->post("newpassword", true);
        						$repassword = $this->input->post("repassword", true);

        						$phpass = new PasswordHash(12, false);

		      					// check password
	      						if ($phpass->CheckPassword($password, $user->password)) {

	      							$stamp_pass = $this->protect->encrypt($newpassword);

	      							$this->users_model->update_user($user->id, array(
								        "password"	=> $stamp_pass
								        )
								    );

								    $response = array ('event' => 'success', 'message' => 'Password updated');

									echo json_encode($response);

	      						} else {

	      							$response = array ('event' => 'fail', 'message' => 'Invalid password');

									echo json_encode($response);

	      						}

							}

						} else {

							$response = array ('event' => 'fail', 'message' => 'Your account has been blocked');

							echo json_encode($response);

						}

					} else {

						$response = array ('event' => 'fail', 'message' => 'User for app not found');

						echo json_encode($response);

					}

				} else {

					$response = array ('event' => 'fail', 'message' => 'User not found');

					echo json_encode($response);

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'User not login');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

	/*
	 * Reset password
	 */
	public function reset_password()
	{
		header('Access-Control-Allow-Origin: *');

		if (!empty($_GET["app_id"])) {

			$app_id = $this->security->xss_clean($_GET["app_id"]);

			if (!$this->input->get_request_header('authorization', TRUE)) {

				// post validation
				$this->form_validation->set_rules('username', "Username", 'trim|required|max_length[50]|min_length[3]|alpha_numeric');
				$this->form_validation->set_rules('email', "Email", 'trim|required|max_length[100]|valid_email');

				if ($this->form_validation->run() == false) {

					$response = array ('event' => 'fail', 'message' => validation_errors());

					echo json_encode($response);

				} else {


					// set variable for input data
					$username = $this->input->post("username", true);
					$email = $this->input->post("email", true);

					$user = $this->users_model->get_user_from_username($username);

	      			if ($user) {

	      				if ($user->email == $email) {

	      					$random_password = rand(0000000000, 5555555555);

	      					$phpass = new PasswordHash(12, false);

	      					$stamp_pass = $this->protect->encrypt($random_password);

	      					$this->users_model->update_user($user->id, array(
								"password"	=> $stamp_pass
								)
							);

							// send email notification
		        			$email_template = $this->template_model->get_email_template(2);

		        			if ($email_template->status == 1) {

		        				$app = $this->apps_model->get_app($app_id);

		        				$message = $email_template->message;
				        		$email_variables = array('[PASSWORD]', '[APPNAME]');
				        		$code_variable = array($random_password, $app->name);
				        		$replace = str_replace($email_variables, $code_variable, $message);

				        		$this->send_email->start_send($app_id, $user->email, $email_template->title, $replace);

		        			}

							$response = array ('event' => 'success');

							echo json_encode($response);

	      				} else {

	      					$response = array ('event' => 'fail', 'message' => 'User not found!');

							echo json_encode($response);

	      				}

	      			} else {

	      				$response = array ('event' => 'fail', 'message' => 'User not found!');

						echo json_encode($response);

	      			}

				}

			} else {

				$response = array ('event' => 'fail', 'message' => 'User in login');

				echo json_encode($response);

			}

		} else {

			$response = array ('event' => 'fail', 'message' => 'Parameter App ID not received');

			echo json_encode($response);

		}
	}

}