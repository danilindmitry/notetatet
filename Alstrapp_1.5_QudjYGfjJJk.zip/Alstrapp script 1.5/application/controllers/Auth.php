<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('auth_model');
    	$this->load->model('template_model');
    	$this->load->model('settings_model');

		// ** Load libraries ** //
		$this->load->library('protect');
		$this->load->library('send_email');

		// check language
		if (empty($_SESSION['lang'])) {

			$user_lang = $this->config->item('language');

		} else {

			$user_lang = $_SESSION['lang'];

		}

		// ** Load language ** //
		$this->lang->load('auth', $user_lang);
    $this->lang->load('layout', $user_lang);
    $this->lang->load('alert', $user_lang);
    $this->lang->load('seo', $user_lang);

	}

	/*
	 * Authorization page
	 */
	public function index()
	{
		// ** Check user session data ** //
		if (isset($_SESSION['id'])) {

			redirect(site_url('my/apps'));

		}

		$data = array(

		);

    	$this->template->set('title', $this->lang->line('seo_33'));
		$this->template->load('auth', 'contents' , 'auth/sign_in', $data);
	}

	/*
	 * Reset password
	 */
	public function reset_password()
	{
		// ** Check user session data ** //
		if (isset($_SESSION['id'])) {

			redirect(site_url('my/apps'));

		}

		$admin = $this->auth_model->get_admin_from_id(1);

		$data = array(
			"admin"	=> $admin
		);

    	$this->template->set('title', $this->lang->line('seo_34'));
		$this->template->load('auth', 'contents' , 'auth/reset', $data);
	}

	/*
	 * Start reset password
	 */
	public function start_reset_password()
	{
		$this->form_validation->set_rules('answer', "Answer to secret password reset question", 'trim|required|max_length[100]|min_length[2]');

		if ($this->form_validation->run() == false) {

			$this->session->set_flashdata('error', validation_errors());
      		redirect(site_url('auth/reset_password'));

		} else {

			$admin = $this->auth_model->get_admin_from_id(1);

			// Set variables for input data
	      	$answer = $this->input->post("answer", true);

	      	if ($admin->reset_answer == $answer) {

	      		$random_password = rand(0000000000, 5555555555);

	      		$phpass = new PasswordHash(12, false);

	      		$stamp_pass = $this->protect->encrypt($random_password);

	      		$this->auth_model->update_admin($admin->id, array(
        			"password"			=> $stamp_pass,
		            )
		        );

		        // send email notification
		        $email_template = $this->template_model->get_email_template(2);

		        if ($email_template->status == 1) {

		        	$message = $email_template->message;
				    $email_variables = array('[PASSWORD]');
				    $code_variable = array($random_password);
				    $replace = str_replace($email_variables, $code_variable, $message);

					$config = array(
			            'protocol'  => 'mail',
			            'charset'   => 'utf8',
			            'mailtype'  => 'html',
			            'wordwrap'  => 'true',
			        );

			        $this->load->library('email', $config);

			        $this->email->from('reset@password.com', 'Info');
			        $this->email->to($admin->email);

			        $this->email->subject('Reset password');
			        $this->email->message($replace);

			        $this->email->send();

		        }

		        $this->session->set_flashdata('success', $this->lang->line('alert_1'));
      			redirect(site_url('auth'));

	      	} else {

	      		$this->session->set_flashdata('error', $this->lang->line('alert_84'));
      			redirect(site_url('auth/reset_password'));

	      	}

		}
	}

	/*
	 * Login form
	 */
	public function sign_in()
	{
		// check login admin
		if (isset($_SESSION['id'])) {

			redirect(site_url('my/apps'));

		}

		// ** Start Input validation ** //
		$this->form_validation->set_rules('email', "Email address", 'trim|required|max_length[50]|valid_email');
		$this->form_validation->set_rules('password', "Password", 'trim|required|min_length[8]|max_length[200]');
		// ** End Input validation ** //

		// ** Check Result Form ** //
		if ($this->form_validation->run() == false) {

			$this->session->set_flashdata('error', validation_errors());
      		redirect(site_url('auth'));

		} else {

			// Set variables for input data
	      	$email = $this->input->post("email", true);
	      	$password = $this->input->post("password", true);

	      	// Get password stamp for email
      		$admin = $this->auth_model->get_admin($email);

      		if ($admin) {

      			$phpass = new PasswordHash(12, false);

      			// check password
      			if ($phpass->CheckPassword($password, $admin->password)) {

      				// add last login
		      		$this->auth_model->update_admin($admin->id, array(
		                "last_login"  =>  date('Y-m-d H:i:s')
		                )
		            );

      				// add true login session
      				$data_session = array(
        				'id' => $admin->id
        			);

      				$this->session->set_userdata($data_session);

			      	redirect(site_url('my/apps'));

      			} else {

      				$this->session->set_flashdata('error', $this->lang->line('alert_85'));
	      			redirect(site_url('auth'));

      			}

      		} else {

      			// Admin does not exist
      			$this->session->set_flashdata('error', $this->lang->line('alert_86'));
	      		redirect(site_url('auth'));

      		}

		}
	}

	/*
	 * Logout
	 */
	public function logout()
	{
		if (isset($_SESSION['id'])) {

			$this->session->unset_userdata('id');
			redirect(site_url('auth'));

		} else {

			// admin not login
			redirect(site_url('auth'));

		}
	}

}