<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Phonegap extends CI_Controller {

	public function __construct() {

		parent::__construct();

		// ** Load models ** //
    	$this->load->model('apps_model');
    	$this->load->model('configuration_model');

	}

	/*
	 * Check code Phonegap for connect account
	 */
	public function index()
	{
		if (!empty($_GET["code"])) {

			$code = $this->security->xss_clean($_GET["code"]);

			$configuration = $this->configuration_model->get_configuration();

			// get access token
		    $ch = curl_init();
		    curl_setopt($ch, CURLOPT_URL,"https://build.phonegap.com/authorize/token?");
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, 
			http_build_query(array('client_id' => $configuration->client_id, 'client_secret' => $configuration->client_secret, 'code' => $code)));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$server_output = curl_exec($ch);
			$server_output = json_decode($server_output, true);
			curl_close ($ch);

			if ($server_output['access_token']) {

				// update
		        $this->configuration_model->update_configuration(array(
			        "access_token"	=> $server_output['access_token']
			        )
			    );

			    $this->session->set_flashdata('success', "Success");
            	redirect(site_url('my/configuration'));

			} else {

				$this->session->set_flashdata('error', $server_output['error']);
            	redirect(site_url('my/configuration'));

			}

		} else {

			$this->session->set_flashdata('error', "Authorization refused!");
            redirect(site_url('my/configuration'));

		}
	}

}