<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* Russian language for builder page
*/

$lang['builder_1']		=	'Конструктор приложения';
$lang['builder_2']		=	'Phonegap';
$lang['builder_3']		=	'Локальное хранилище';
$lang['builder_4']		=	'Менеджер версий';
$lang['builder_5']		=	'Хранилище Phonegap';
$lang['builder_6']		=	'Новая сборка';
$lang['builder_7']		=	'Название';
$lang['builder_8']		=	'Версия';
$lang['builder_9']		=	'Создано';
$lang['builder_10']		=	'Скачать';
$lang['builder_11']		=	'Phonegap App ID';
$lang['builder_12']		=	'Ссылка на загрузку будет доступна в течение 5 минут. Обновите страницу для проверки';
$lang['builder_13']		=	'Сохранить локально';
$lang['builder_14']		=	'Удалить';
$lang['builder_15']		=	'Удалить версию из';
$lang['builder_16']		=	'Уверен? Данное действие невозможно отменить. Версия будет удалена на сервере Phonegap';
$lang['builder_17']		=	'Нет, не сейчас';
$lang['builder_18']		=	'Да, удалить';
$lang['builder_19']		=	'Получить файлы приложения';
$lang['builder_20']		=	'Просто нажми старт и получи готовое мобильное приложение';
$lang['builder_21']		=	'Начать сборку';
$lang['builder_22']		=	'Подпись приложения';
$lang['builder_23']		=	'Android';
$lang['builder_24']		=	'iOS';
$lang['builder_25']		=	'Подпись';
$lang['builder_26']		=	'Без подписи';
$lang['builder_27']		=	'ID подписи Android';
$lang['builder_28']		=	'Пароль для ключа';
$lang['builder_29']		=	'Пароль для хранилища ключа';
$lang['builder_30']		=	'ID подписи iOS';
$lang['builder_31']		=	'Пароль для сертификата';
$lang['builder_32']		=	'Закрыть';
$lang['builder_33']		=	'Загрузка файлов для сборки приложения';
$lang['builder_34']		=	'Это займет несколько минут';
$lang['builder_35']		=	'Копирование файлов';
$lang['builder_36']		=	'Успешно';
$lang['builder_37']		=	'Приложение будет доступно для загрузки через 5 минут';
$lang['builder_38']		=	'Продолжить';
$lang['builder_39']		=	'Неудачный запрос';
$lang['builder_40']		=	'Обновить страницу';
$lang['builder_41']		=	'Проверь доступность сервера';
$lang['builder_42']		=	'Уверен? Данное действие невозможно отменить';
$lang['builder_43']		=	'Нет сохраненных версий';
$lang['builder_44']		=	'Ты можешь хранить приложения здесь и не использовать платные ресурсы Phonegap';