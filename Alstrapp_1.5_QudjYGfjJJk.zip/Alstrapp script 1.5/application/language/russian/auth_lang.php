<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* Russian language for auth page
*/

$lang['auth_1']		=	'Сбросить пароль';
$lang['auth_2']		=	'Отправить новый пароль';
$lang['auth_3']		=	'Вернуться ко входу';
$lang['auth_4']		=	'Вход в Alstrapp';
$lang['auth_5']		=	'Email';
$lang['auth_6']		=	'Пароль';
$lang['auth_7']		=	'Вход';
$lang['auth_8']		=	'Сбросить пароль';