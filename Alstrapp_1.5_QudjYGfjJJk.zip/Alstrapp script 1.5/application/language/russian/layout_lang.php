<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* Russian language for layout
*/

$lang['layout_1']		=	'Все проекты';
$lang['layout_2']		=	'Конфигурация';
$lang['layout_3']		=	'Мой аккаунт';
$lang['layout_4']		=	'Выход';
$lang['layout_5']		=	'Создать приложение';
$lang['layout_6']		=	'Название приложение';
$lang['layout_7']		=	'App ID';
$lang['layout_8']		=	'Шаблон дизайна';
$lang['layout_9']		=	'Тема устройства для шаблона';
$lang['layout_10']	=	'Автоопределение устройства';
$lang['layout_11']	=	'Закрыть';
$lang['layout_12']	=	'Создать';

$lang['layout_13']	=	'Дашборд';
$lang['layout_14']	=	'Навигация';
$lang['layout_15']	=	'Посты';
$lang['layout_16']	=	'Новый пост';
$lang['layout_17']	=	'Все посты';
$lang['layout_18']	=	'Категории';
$lang['layout_19']	=	'Комментарии';
$lang['layout_20']	=	'Пользователи';
$lang['layout_21']	=	'Новый пользователь';
$lang['layout_22']	=	'Все пользователи';
$lang['layout_23']	=	'Группы пользователей';
$lang['layout_24']	=	'Галереи';
$lang['layout_25']	=	'Формы';
$lang['layout_26']	=	'Сообщения';
$lang['layout_27']	=	'Оповещения';
$lang['layout_28']	=	'PUSH рассылка';
$lang['layout_29']	=	'Alert оповещения';
$lang['layout_30']	=	'Статистика визитов';
$lang['layout_31']	=	'Настройки';
$lang['layout_32']	=	'Версия:';
$lang['layout_33']	=	'Опубликовано:';
$lang['layout_34']	=	'Черновик';
$lang['layout_35']	=	'Активно';
$lang['layout_36']	=	'Конструктор';
$lang['layout_37']	=	'Предпросмотр';
$lang['layout_38']	=	'Preview app';

$lang['layout_39']	=	'Онлайн Конструктор';
$lang['layout_40']	=	'Создавайте профессиональные пиложения для любых сайтов с помощью CMS и интегрированых плагинов';
$lang['layout_41']	=	'Конвертировать сайт';
$lang['layout_42']	=	'Просто укажите адрес вашего сайта и получите готовое приложение в два клика';
$lang['layout_43']	=	'Шаг 1:';
$lang['layout_44']	=	'Какое приложение вы хотите создать?';
$lang['layout_45']	=	'Шаг 2:';
$lang['layout_46']	=	'Создание проекта для онлайн конструктора';
$lang['layout_47']	=	'Введите адрес сайта и скачайте приложение';
$lang['layout_48']	=	'Адрес вашего сайта';