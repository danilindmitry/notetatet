<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* Russian language for statistic page
*/

$lang['statistic_1']		=	'Статистика визитов';
$lang['statistic_2']		=	'Отчет за месяц';
$lang['statistic_3']		=	'Годовой отчет';
$lang['statistic_4']		=	'Статистика для';
$lang['statistic_5']		=	'Всего';
$lang['statistic_6']		=	'Дата';
$lang['statistic_7']		=	'Пользователь';
$lang['statistic_8']		=	'Устройство';
$lang['statistic_9']		=	'Удалить';
$lang['statistic_10']		=	'Удалить элемент статистики от';
$lang['statistic_11']		=	'Уверен? Данное действие невозможно отменить';
$lang['statistic_12']		=	'Нет, не сейчас';
$lang['statistic_13']		=	'Да, удалить';
$lang['statistic_14']		=	'Нет визитов';
$lang['statistic_15']		=	'Все еще впереди! Статистика запуска приложения будет отображаться здесь';