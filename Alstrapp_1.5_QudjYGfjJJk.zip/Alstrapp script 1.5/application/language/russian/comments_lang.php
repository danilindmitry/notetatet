<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* Russian language for comments page
*/

$lang['comments_1']	  =	'Комментарии';
$lang['comments_2']	  =	'Все комментарии';
$lang['comments_3']	  =	'Поиск';
$lang['comments_4']	  =	'Опубликованные комментарии';
$lang['comments_5']	  =	'Неопубликованные комментарии';
$lang['comments_6']	  =	'Результаты поиска';
$lang['comments_7']	  =	'Поиск выполнен по запросу';
$lang['comments_8']	  =	'Сортировать по статусу';
$lang['comments_9']	  =	'Опубликовано';
$lang['comments_10']  =	'Неопубликовано';
$lang['comments_11']  =	'Пользователь';
$lang['comments_12']  =	'Комментарий';
$lang['comments_13']  =	'Создано';
$lang['comments_14']  =	'Просмотр всех комментариев';
$lang['comments_15']  =	'Снять с публикации';
$lang['comments_16']  =	'Опубликовать';
$lang['comments_17']  =	'Удалить';
$lang['comments_18']  =	'Здесь ничего нет';
$lang['comments_19']  =	'Вы сможете отвечать на комментарии, когда они появятся';
$lang['comments_20']  =	'Ничего не найдено';
$lang['comments_21']  =	'Попробуй изменить условия поиска и тебе повезет';
$lang['comments_22']  =	'Вернуться ко всем комментариям';
$lang['comments_23']  =	'Ты можешь использовать для поиска значение комментария';
$lang['comments_24']  =	'Что мы ищем';
$lang['comments_25']	=	'Ответить';
$lang['comments_26']  =	'Твой комментарий';
$lang['comments_27']  =	'Создать';