<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* Russian language for settings page
*/

$lang['settings_1']		=	'Настройки';
$lang['settings_2']		=	'Настройки приложения';
$lang['settings_3']		=	'Настройки PUSH';
$lang['settings_4']		=	'Иконки и экран';
$lang['settings_5']		=	'Emails';
$lang['settings_6']		=	'Аватары';
$lang['settings_7']		=	'Для чата и комментариев в приложении';
$lang['settings_8']		=	'Настройки иконки';
$lang['settings_9']		=	'Просмотр';
$lang['settings_10']		=	'Размер';
$lang['settings_11']		=	'Название';
$lang['settings_12']		=	'Название файла';
$lang['settings_13']		=	'Аватар чата';
$lang['settings_14']		=	'Загрузить';
$lang['settings_15']		=	'Аватар для комментариев';
$lang['settings_16']		=	'Метод отправки';
$lang['settings_17']		=	'Метод отправки email оповещений';
$lang['settings_18']		=	'Email админа';
$lang['settings_19']		=	'Имя отправителя';
$lang['settings_20']		=	'Email отправителя';
$lang['settings_21']		=	'SMTP настройки';
$lang['settings_22']		=	'SMTP порт';
$lang['settings_23']		=	'SMTP хост';
$lang['settings_24']		=	'Пароль для email отправителя';
$lang['settings_25']		=	'Обновить';
$lang['settings_26']		=	'Иконки приложения';
$lang['settings_27']		=	'Иконка по умолчанию';
$lang['settings_28']		=	'Заставка';
$lang['settings_29']		=	'Иконка для PUSH оповещения';
$lang['settings_30']		=	'Настройки иконки Retina';
$lang['settings_31']		=	'Spotlight иконка';
$lang['settings_32']		=	'Spotlight иконка Retina';
$lang['settings_33']		=	'iPad Spotlight и настройки иконки';
$lang['settings_34']		=	'iPhone 6 по умолчанию Retina';
$lang['settings_35']		=	'iPhone 6 по умолчанию портрет Retina';
$lang['settings_36']		=	'Название приложения';
$lang['settings_37']		=	'ID приложения';
$lang['settings_38']		=	'Описание приложения';
$lang['settings_39']		=	'Автор';
$lang['settings_40']		=	'Версия';
$lang['settings_41']		=	'Модерация комментариев';
$lang['settings_42']		=	'Нет';
$lang['settings_43']		=	'Да';
$lang['settings_44']		=	'One Signal APP ID';
$lang['settings_45']		=	'REST API key';
$lang['settings_46']		=	'User auth key';