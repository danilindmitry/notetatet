<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* Russian language for messages page
*/

$lang['messages_1']   = 'Сообщения';
$lang['messages_2']   = 'Непрочитанные';
$lang['messages_3']	  =	'Все';
$lang['messages_4']	  =	'Поиск';
$lang['messages_5']	  =	'Все диалоги';
$lang['messages_6']	  =	'Создать диалог';
$lang['messages_7']	  =	'Пользователь';
$lang['messages_8']	  =	'Последние сообщения';
$lang['messages_9']	  =	'Всего сообщений';
$lang['messages_10']  =	'Здесь ничего нет';
$lang['messages_11']  =	'Все отправленные пользователями формы будут храниться здесь';
$lang['messages_12']  =	'Создать новый диалог';
$lang['messages_13']	=	'Логин';
$lang['messages_14']	=	'Вы можете создать только один диалог для одного пользователя';
$lang['messages_15']  =	'Создать';
$lang['messages_16']  =	'Непрочитанные сообщения';
$lang['messages_17']  =	'Нет непрочитанных сообщений';
$lang['messages_18']  =	'Все непрочитанные входящие сообщения от пользователей будут отображаться здесь';
$lang['messages_19']  =	'Обновить страницу';
$lang['messages_20']  =	'Запрос не выполнен';
$lang['messages_21']  =	'Вы можете искать любую фразу из любых сообщений';
$lang['messages_22']  =	'Что мы ищем';
$lang['messages_23']  =	'Результаты поиска';
$lang['messages_24']  =	'Поиск по запросу завершен';
$lang['messages_25']  =	'Сбросить поиск';
$lang['messages_26']  =	'Сообщение';
$lang['messages_27']  =	'Ничего не найдено';
$lang['messages_28']  =	'Попробуй изменить условия поиска и тебе повезет';
$lang['messages_29']  =	'Вернуться к поиску';
$lang['messages_30']  =	'Диалог с';
$lang['messages_31']  =	'Заблокировать пользователя';
$lang['messages_32']  =	'Очистить чат';
$lang['messages_33']  =	'Этот пользователь был заблокирован и не может отправлять сообщения';
$lang['messages_34']  =	'Разблокировать пользователя';
$lang['messages_35']  =	'Твое сообщение';
$lang['messages_36']  =	'Отправить';
$lang['messages_37']  =	'Ты';
$lang['messages_38']  =	'Ошибка';
$lang['messages_39']  =	'Ошибка запроса. Перезагрузите страницу и попробуйте снова';