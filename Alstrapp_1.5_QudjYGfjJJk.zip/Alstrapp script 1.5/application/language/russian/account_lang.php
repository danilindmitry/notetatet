<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* Russian language for account page
*/

$lang['account_1']		=	'Test value';
$lang['account_2']		=	'Аккаунт';
$lang['account_3']		=	'Настройки аккаунта';
$lang['account_4']		=	'Email';
$lang['account_5']		=	'Новый пароль';
$lang['account_6']		=	'Минимум 5, максимум 150 знаков без пробелов';
$lang['account_7']		=	'Повторите новый пароль';
$lang['account_8']		=	'Вопрос для сброса пароля';
$lang['account_9']		=	'Кличка вашего первого питомца';
$lang['account_10']		=	'Ответ на секретный вопрос для сброса пароля';
$lang['account_11']		=	'Обновить';