<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* Russian language for navigation page
*/

$lang['navigation_1']  = 'Навигация';
$lang['navigation_2']  = 'Главное меню';
$lang['navigation_3']  = 'Меню входа';
$lang['navigation_4']  = 'Меню пользователя';
$lang['navigation_5']  = 'Новый элемент';
$lang['navigation_6']  = 'Создайте свой первый элемент меню';
$lang['navigation_7']  = 'Это меню доступно на стартовой странице приложения';
$lang['navigation_8']  = 'Создать новый элемент';
$lang['navigation_9']  = 'Название';
$lang['navigation_10']  = 'Ссылка';
$lang['navigation_11']  = 'Конструктор';
$lang['navigation_12']  = 'Удалить';
$lang['navigation_13']  = 'Удалить элемент меню';
$lang['navigation_14']  = 'Уверен? Данное действие невозможно отменить';
$lang['navigation_15']  = 'Нет, не сейчас';
$lang['navigation_16']  = 'Да, удалить';
$lang['navigation_17']  = 'Добавить элемент меню';
$lang['navigation_18']  = 'Название элемента';
$lang['navigation_19']  = 'Посты';
$lang['navigation_20']  = 'Тип элемента';
$lang['navigation_21']  = 'Внешняя ссылка';
$lang['navigation_22']  = 'Категория постов';
$lang['navigation_23']  = 'Пост';
$lang['navigation_24']  = 'Галерея';
$lang['navigation_25']  = 'Форма';
$lang['navigation_26']  = 'Список категорий';
$lang['navigation_27']  = 'Библиотека иконок';
$lang['navigation_28']  = 'Иконка';
$lang['navigation_29']  = 'Вы можете проверить иконки на сайте';
$lang['navigation_30']  = 'и';
$lang['navigation_31']  = 'Создать и продолжить';
$lang['navigation_32']  = 'Элемент меню';
$lang['navigation_33']  = 'Редактор';
$lang['navigation_34']  = 'Настройки';
$lang['navigation_35']  = 'У вас еще нет добавленных категорий';
$lang['navigation_36']  = 'Создать сейчас';
$lang['navigation_37']  = 'Выбрать категорию для элемента меню';
$lang['navigation_38']  = 'Просмотр';
$lang['navigation_39']  = 'У вас еще нет добавленных постов';
$lang['navigation_40']  = 'Выбрать пост для элемента меню';
$lang['navigation_41']  = 'У вас еще нет добавленной галереи';
$lang['navigation_42']  = 'Выбрать галерею для элемента меню';
$lang['navigation_43']  = 'У вас еще нет добавленных форм';
$lang['navigation_44']  = 'Выбрать форму для элемента меню';
$lang['navigation_45']  = 'Права доступа';
$lang['navigation_46']  = 'Все пользователи';
$lang['navigation_47']  = 'Только незарегистрированные пользователи';
$lang['navigation_48']  = 'Только зарегистрированные пользователи';
$lang['navigation_49']  = 'Группа пользователей';
$lang['navigation_50']  = 'Все группы';
$lang['navigation_51']  = 'Обновить';