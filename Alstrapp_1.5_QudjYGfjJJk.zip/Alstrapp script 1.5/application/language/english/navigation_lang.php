<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for navigation page
*/

$lang['navigation_1']  = 'Navigation';
$lang['navigation_2']  = 'Main menu';
$lang['navigation_3']  = 'Auth menu';
$lang['navigation_4']  = 'User menu';
$lang['navigation_5']  = 'New item';
$lang['navigation_6']  = 'Create your first menu item';
$lang['navigation_7']  = 'This menu is available on the start page of app';
$lang['navigation_8']  = 'Create new item';
$lang['navigation_9']  = 'Name';
$lang['navigation_10']  = 'Link';
$lang['navigation_11']  = 'Builder';
$lang['navigation_12']  = 'Delete';
$lang['navigation_13']  = 'Delete menu item';
$lang['navigation_14']  = 'Are you sure about this? This action cannot be undone';
$lang['navigation_15']  = 'No, nevermind';
$lang['navigation_16']  = 'Yes, delete';
$lang['navigation_17']  = 'Add menu item';
$lang['navigation_18']  = 'Name item';
$lang['navigation_19']  = 'Posts';
$lang['navigation_20']  = 'Type item';
$lang['navigation_21']  = 'External link';
$lang['navigation_22']  = 'Posts category';
$lang['navigation_23']  = 'Post';
$lang['navigation_24']  = 'Gallery';
$lang['navigation_25']  = 'Form';
$lang['navigation_26']  = 'Category List';
$lang['navigation_27']  = 'Icons library';
$lang['navigation_28']  = 'Icon';
$lang['navigation_29']  = 'You can check the icons on the site';
$lang['navigation_30']  = 'and';
$lang['navigation_31']  = 'Create and continue';
$lang['navigation_32']  = 'Menu item';
$lang['navigation_33']  = 'Editor';
$lang['navigation_34']  = 'Settings';
$lang['navigation_35']  = 'You have not added any categories yet';
$lang['navigation_36']  = 'Create now';
$lang['navigation_37']  = 'Select category for menu item';
$lang['navigation_38']  = 'View';
$lang['navigation_39']  = 'You have not added any posts yet';
$lang['navigation_40']  = 'Select post for menu item';
$lang['navigation_41']  = 'You have not added any gallery yet';
$lang['navigation_42']  = 'Select gallery for menu item';
$lang['navigation_43']  = 'You have not added any forms yet';
$lang['navigation_44']  = 'Select form for menu item';
$lang['navigation_45']  = 'Access rights';
$lang['navigation_46']  = 'All users';
$lang['navigation_47']  = 'Only unregistered users';
$lang['navigation_48']  = 'Only registered users';
$lang['navigation_49']  = 'Users group';
$lang['navigation_50']  = 'All groups';
$lang['navigation_51']  = 'Update';







