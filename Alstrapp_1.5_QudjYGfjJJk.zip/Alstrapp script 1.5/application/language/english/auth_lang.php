<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for auth page
*/

$lang['auth_1']		=	'Reset password';
$lang['auth_2']		=	'Send new password';
$lang['auth_3']		=	'Return to login';
$lang['auth_4']		=	'Sign in to Alstrapp';
$lang['auth_5']		=	'Email address';
$lang['auth_6']		=	'Password';
$lang['auth_7']		=	'Sign in';
$lang['auth_8']		=	'Reset password';