<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for comments page
*/

$lang['comments_1']	  =	'Comments';
$lang['comments_2']	  =	'All comments';
$lang['comments_3']	  =	'Search';
$lang['comments_4']	  =	'Published comments';
$lang['comments_5']	  =	'Unpublished comments';
$lang['comments_6']	  =	'Search results';
$lang['comments_7']	  =	'Search is completed by request';
$lang['comments_8']	  =	'Sort by status';
$lang['comments_9']	  =	'Published';
$lang['comments_10']  =	'Unpublished';
$lang['comments_11']  =	'User';
$lang['comments_12']  =	'Comment';
$lang['comments_13']  =	'Created';
$lang['comments_14']  =	'View all comments';
$lang['comments_15']  =	'Unpublish';
$lang['comments_16']  =	'Publish';
$lang['comments_17']  =	'Delete';
$lang['comments_18']  =	'There is nothing';
$lang['comments_19']  =	'You will be able to reply to comments when they appear';
$lang['comments_20']  =	'Nothing found';
$lang['comments_21']  =	'Try changing your search and you are lucky';
$lang['comments_22']  =	'Return to all comments';
$lang['comments_23']  =	'You can using for search comment value';
$lang['comments_24']  =	'What are we looking for';
$lang['comments_25']	=	'Reply';
$lang['comments_26']  =	'Your comment';
$lang['comments_27']  =	'Create';