<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for builder page
*/

$lang['builder_1']		=	'Builder app';
$lang['builder_2']		=	'Phonegap';
$lang['builder_3']		=	'Local storage';
$lang['builder_4']		=	'Version manager';
$lang['builder_5']		=	'Phonegap storage';
$lang['builder_6']		=	'New build';
$lang['builder_7']		=	'Name';
$lang['builder_8']		=	'Version';
$lang['builder_9']		=	'Created';
$lang['builder_10']		=	'Download';
$lang['builder_11']		=	'Phonegap App ID';
$lang['builder_12']		=	'Download link will be available within 5 minutes. Refresh page to check';
$lang['builder_13']		=	'Save to local';
$lang['builder_14']		=	'Delete';
$lang['builder_15']		=	'Delete version from';
$lang['builder_16']		=	'Are you sure about this? This action cannot be undone. Version will be removed on the server Phonegap';
$lang['builder_17']		=	'No, nevermind';
$lang['builder_18']		=	'Yes, delete';
$lang['builder_19']		=	'Get application files';
$lang['builder_20']		=	'Just click start and get finished mobile application';
$lang['builder_21']		=	'Start build';
$lang['builder_22']		=	'Signing app';
$lang['builder_23']		=	'Android';
$lang['builder_24']		=	'iOS';
$lang['builder_25']		=	'Signature';
$lang['builder_26']		=	'Without signature';
$lang['builder_27']		=	'Android Signature ID';
$lang['builder_28']		=	'Key password';
$lang['builder_29']		=	'Keystore password';
$lang['builder_30']		=	'iOS Signature ID';
$lang['builder_31']		=	'Certificate password';
$lang['builder_32']		=	'Close';
$lang['builder_33']		=	'Upload files for build app';
$lang['builder_34']		=	'It will take a few minutes';
$lang['builder_35']		=	'Copying files';
$lang['builder_36']		=	'Success';
$lang['builder_37']		=	'Application will be available for download in 5 minutes';
$lang['builder_38']		=	'Continue';
$lang['builder_39']		=	'Request failed';
$lang['builder_40']		=	'Refresh page';
$lang['builder_41']		=	'Check your server availability';
$lang['builder_42']		=	'Are you sure about this? This action cannot be undone';
$lang['builder_43']		=	'No saved versions';
$lang['builder_44']		=	'You can store applications here to not use paid Phonegap resources';