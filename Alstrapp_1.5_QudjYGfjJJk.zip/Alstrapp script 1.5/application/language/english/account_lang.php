<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for account page
*/

$lang['account_1']		=	'Test value';
$lang['account_2']		=	'Account';
$lang['account_3']		=	'Account settings';
$lang['account_4']		=	'Email';
$lang['account_5']		=	'New password';
$lang['account_6']		=	'Minimum 5, maximum 150 characters without spaces';
$lang['account_7']		=	'Repeat new password';
$lang['account_8']		=	'Password reset question';
$lang['account_9']		=	'What is the name of my first pet';
$lang['account_10']		=	'Answer to secret password reset question';
$lang['account_11']		=	'Update';