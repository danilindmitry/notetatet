<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for dashboard page
*/

$lang['dash_1']	  =	'Dashboard';
$lang['dash_2']	  =	'Users';
$lang['dash_3']	  =	'Comments';
$lang['dash_4']	  =	'Dialogues';
$lang['dash_5']	  =	'Forms';
$lang['dash_6']	  =	'App launch statistics for';
$lang['dash_7']	  =	'Detail statistics';
$lang['dash_8']	  =	'Last 5 unpublished comments';
$lang['dash_9']	  =	'View more';
$lang['dash_10']  =	'View all comments';
$lang['dash_11']  =	'There is nothing';

$lang['dash_12']  =	'Almost done!';
$lang['dash_13']  =	'Preview of the application is not available in this mode. Just make a new build and test the application on your device.';
$lang['dash_14']  =	'Build now!';