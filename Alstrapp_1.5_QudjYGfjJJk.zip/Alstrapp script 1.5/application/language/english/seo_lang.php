<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for seo titles
*/

$lang['seo_1']		=	'Account';
$lang['seo_2']		=	'Personal apps';
$lang['seo_3']		=	'Builder app';
$lang['seo_4']		=	'Comments';
$lang['seo_5']		=	'Configuration';
$lang['seo_6']		=	'Dashboard';
$lang['seo_7']		=	'Forms';
$lang['seo_8']		=	'Galleries';
$lang['seo_9']		=	'Messages';
$lang['seo_10']		=	'Navigation';
$lang['seo_11']		=	'Alert notifications';
$lang['seo_12']		=	'New notification';
$lang['seo_13']		=	'Edit notification';
$lang['seo_14']		=	'PUSH newsletter';
$lang['seo_15']		=	'Detail notification';
$lang['seo_16']		=	'New newsletter';
$lang['seo_17']		=	'Posts';
$lang['seo_18']		=	'Posts categories';
$lang['seo_19']		=	'Edit category';
$lang['seo_20']		=	'New category';
$lang['seo_21']		=	'New post';
$lang['seo_22']		=	'Edit post';
$lang['seo_23']		=	'Settings';
$lang['seo_24']		=	'PUSH settings';
$lang['seo_25']		=	'Icons app';
$lang['seo_26']		=	'Avatars settings';
$lang['seo_27']		=	'Settings emails';
$lang['seo_28']		=	'Visitor statistics';
$lang['seo_29']		=	'Users';
$lang['seo_30']		=	'Users groups';
$lang['seo_31']		=	'New user';
$lang['seo_32']		=	'Edit user';
$lang['seo_33']		=	'Sign in';
$lang['seo_34']		=	'Reset password';