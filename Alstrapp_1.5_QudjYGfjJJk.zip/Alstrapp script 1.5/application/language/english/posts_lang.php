<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for posts page
*/

$lang['post_1']		=	'New category';
$lang['post_2']		=	'Editor';
$lang['post_3']		=	'Settings';
$lang['post_4']		=	'Name';
$lang['post_5']		=	'News';
$lang['post_6']		=	'Cover image';
$lang['post_7']		=	'Publication status';
$lang['post_8']		=	'Published';
$lang['post_9']		=	'Unpublished';
$lang['post_10']		=	'Category description';
$lang['post_11']		=	'Access rights';
$lang['post_12']		=	'All users';
$lang['post_13']		=	'Only unregistered users';
$lang['post_14']		=	'Only registered users';
$lang['post_15']		=	'Users group';
$lang['post_16']		=	'All groups';
$lang['post_17']		=	'Template';
$lang['post_18']		=	'Blocks';
$lang['post_19']		=	'Cards';
$lang['post_20']		=	'List';
$lang['post_21']		=	'Create';
$lang['post_22']		=	'New post';
$lang['post_23']		=	'Title';
$lang['post_24']		=	'Categories';
$lang['post_25']		=	'Description for list';
$lang['post_26']		=	'Content';
$lang['post_27']		=	'Author';
$lang['post_28']		=	'Attach gallery';
$lang['post_29']		=	'No galleries';
$lang['post_30']		=	'Comments';
$lang['post_31']		=	'Enabled';
$lang['post_32']		=	'Disabled';
$lang['post_33']		=	'Posts categories';
$lang['post_34']		=	'All categories';
$lang['post_35']		=	'Search';
$lang['post_36']		=	'Published categories';
$lang['post_37']		=	'Unpublished categories';
$lang['post_38']		=	'Search results';
$lang['post_39']		=	'Search is completed by request';
$lang['post_40']		=	'Sort by status';
$lang['post_41']		=	'Descreption';
$lang['post_42']		=	'Posts';
$lang['post_43']		=	'Created';
$lang['post_44']		=	'Edit';
$lang['post_45']		=	'Unpublish';
$lang['post_46']		=	'Publish';
$lang['post_47']		=	'Delete';
$lang['post_48']		=	'Delete category';
$lang['post_49']		=	'Are you sure about this? This action cannot be undone';
$lang['post_50']		=	'No, nevermind';
$lang['post_51']		=	'Yes, delete';
$lang['post_52']		=	'Create your first category';
$lang['post_53']		=	'You can add posts to categories and control user access';
$lang['post_54']		=	'Create new category';
$lang['post_55']		=	'Nothing found';
$lang['post_56']		=	'Try changing your search and you are lucky';
$lang['post_57']		=	'Return to all categories';
$lang['post_58']		=	'You can using for search category name and descreption';
$lang['post_59']		=	'What are we looking for';
$lang['post_60']		=	'Check current image';
$lang['post_61']		=	'Update';
$lang['post_62']		=	'Edit post';
$lang['post_63']		=	'Image has not been uploaded';
$lang['post_64']		=	'All posts';
$lang['post_65']		=	'Sort by category';
$lang['post_66']		=	'Category';
$lang['post_67']		=	'Views';
$lang['post_68']		=	'Delete post';
$lang['post_69']		=	'Create your first post';
$lang['post_70']		=	'Create posts and manage access to them';
$lang['post_71']		=	'Create new post';
$lang['post_72']		=	'Return to all posts';
$lang['post_73']		=	'You can using for search title post, content and author value';




