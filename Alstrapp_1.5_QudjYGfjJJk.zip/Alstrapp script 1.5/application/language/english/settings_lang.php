<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for settings page
*/

$lang['settings_1']		=	'Settings';
$lang['settings_2']		=	'App settings';
$lang['settings_3']		=	'PUSH settings';
$lang['settings_4']		=	'Icons and screen';
$lang['settings_5']		=	'Emails';
$lang['settings_6']		=	'Avatars';
$lang['settings_7']		=	'For chat and comments in app';
$lang['settings_8']		=	'Settings Icon';
$lang['settings_9']		=	'Preview';
$lang['settings_10']		=	'Size';
$lang['settings_11']		=	'Name';
$lang['settings_12']		=	'File name';
$lang['settings_13']		=	'Chat avatar';
$lang['settings_14']		=	'Upload';
$lang['settings_15']		=	'Avatar for comments';
$lang['settings_16']		=	'Send method';
$lang['settings_17']		=	'Send method email nottifications';
$lang['settings_18']		=	'Admin email';
$lang['settings_19']		=	'Sender name';
$lang['settings_20']		=	'Sender email';
$lang['settings_21']		=	'SMTP settings';
$lang['settings_22']		=	'SMTP port';
$lang['settings_23']		=	'SMTP host';
$lang['settings_24']		=	'Password for sender email';
$lang['settings_25']		=	'Update';
$lang['settings_26']		=	'Icons app';
$lang['settings_27']		=	'Default icon';
$lang['settings_28']		=	'Splash screen';
$lang['settings_29']		=	'Icon for PUSH notification';
$lang['settings_30']		=	'Settings Icon Retina';
$lang['settings_31']		=	'Spotlight Icon';
$lang['settings_32']		=	'Spotlight Icon Retina';
$lang['settings_33']		=	'iPad Spotlight and Settings Icon';
$lang['settings_34']		=	'iPhone 6 default Retina';
$lang['settings_35']		=	'iPhone 6 default portrait Retina';
$lang['settings_36']		=	'App name';
$lang['settings_37']		=	'App ID';
$lang['settings_38']		=	'App description';
$lang['settings_39']		=	'Author';
$lang['settings_40']		=	'Version';
$lang['settings_41']		=	'Comments moderation';
$lang['settings_42']		=	'No';
$lang['settings_43']		=	'Yes';
$lang['settings_44']		=	'One Signal APP ID';
$lang['settings_45']		=	'REST API key';
$lang['settings_46']		=	'User auth key';