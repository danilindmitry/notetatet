<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for statistic page
*/

$lang['statistic_1']		=	'Visitor statistics';
$lang['statistic_2']		=	'Monthly report';
$lang['statistic_3']		=	'Annual report';
$lang['statistic_4']		=	'Statistics for';
$lang['statistic_5']		=	'Total';
$lang['statistic_6']		=	'Date';
$lang['statistic_7']		=	'User';
$lang['statistic_8']		=	'Device';
$lang['statistic_9']		=	'Delete';
$lang['statistic_10']		=	'Delete statistics item from';
$lang['statistic_11']		=	'Are you sure about this? This action cannot be undone';
$lang['statistic_12']		=	'No, nevermind';
$lang['statistic_13']		=	'Yes, delete';
$lang['statistic_14']		=	'No visits';
$lang['statistic_15']		=	'Still ahead! The app launch statistics will be displayed here';