<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for layout
*/

$lang['layout_1']	=	'All projects';
$lang['layout_2']	=	'Configuration';
$lang['layout_3']	=	'My account';
$lang['layout_4']	=	'Logout';
$lang['layout_5']	=	'Create new app';
$lang['layout_6']	=	'App name';
$lang['layout_7']	=	'App ID';
$lang['layout_8']	=	'Design template';
$lang['layout_9']	=	'Device theme for template';
$lang['layout_10']	=	'Auto Detect Device';
$lang['layout_11']	=	'Cancel';
$lang['layout_12']	=	'Create app';

$lang['layout_13']	=	'Dashboard';
$lang['layout_14']	=	'Navigation';
$lang['layout_15']	=	'Posts';
$lang['layout_16']	=	'New post';
$lang['layout_17']	=	'All posts';
$lang['layout_18']	=	'Categories';
$lang['layout_19']	=	'Comments';
$lang['layout_20']	=	'Users';
$lang['layout_21']	=	'New user';
$lang['layout_22']	=	'All users';
$lang['layout_23']	=	'Users groups';
$lang['layout_24']	=	'Galleries';
$lang['layout_25']	=	'Forms';
$lang['layout_26']	=	'Messages';
$lang['layout_27']	=	'User Notifications';
$lang['layout_28']	=	'PUSH newsletter';
$lang['layout_29']	=	'Alert notifications';
$lang['layout_30']	=	'Visitor statistics';
$lang['layout_31']	=	'Settings';
$lang['layout_32']	=	'Version app:';
$lang['layout_33']	=	'Published:';
$lang['layout_34']	=	'Draft';
$lang['layout_35']	=	'Active';
$lang['layout_36']	=	'Builder';
$lang['layout_37']	=	'Preview app';
$lang['layout_38']	=	'Preview app';

$lang['layout_39']	=	'Online Builder';
$lang['layout_40']	=	'Build professional apps with content management system and integrated plugins';
$lang['layout_41']	=	'Convert site to mobile app';
$lang['layout_42']	=	'Just enter the address of your website and get finished application in 2 clicks';
$lang['layout_43']	=	'Step 1:';
$lang['layout_44']	=	'What application do you want to create?';
$lang['layout_45']	=	'Step 2:';
$lang['layout_46']	=	'Create project for online build';
$lang['layout_47']	=	'Enter site link and download app files';
$lang['layout_48']	=	'Link to your site';