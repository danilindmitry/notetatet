<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for notification page
*/

$lang['notify_1']  = 'New notification';
$lang['notify_2']  = 'Name';
$lang['notify_3']  = 'News';
$lang['notify_4']  = 'Maximum 15 characters';
$lang['notify_5']  = 'Start date';
$lang['notify_6']  = 'End date';
$lang['notify_7']  = 'Message';
$lang['notify_8']  = 'Maximum 80 characters';
$lang['notify_9']  = 'User group';
$lang['notify_10']  = 'No group';
$lang['notify_11']  = 'Access rights';
$lang['notify_12']  = 'All users';
$lang['notify_13']  = 'Only unregistered users';
$lang['notify_14']  = 'Only registered users';
$lang['notify_15']  = 'Create';
$lang['notify_16']  = 'New PUSH newsletter';
$lang['notify_17']  = 'Title';
$lang['notify_18']  = 'LED collor';
$lang['notify_19']  = 'Only Android! Sets the devices LED notification light (if the users device has one). If no LED Color is specified, the devices default color will show. Format: ARGB Hex value (E.g. FF9900FF)';
$lang['notify_20']  = 'Big picture';
$lang['notify_21']  = 'Only Android! Shows up in an expandable view below the notification text';
$lang['notify_22']  = 'Send message';
$lang['notify_23']  = 'Alert notifications';
$lang['notify_24']  = 'Active';
$lang['notify_25']  = 'Planned';
$lang['notify_26']  = 'Archive';
$lang['notify_27']  = 'Archive notifications';
$lang['notify_28']  = 'Add notice';
$lang['notify_29']  = 'Delete';
$lang['notify_30']  = 'Delete notifications';
$lang['notify_31']  = 'Are you sure about this? This action cannot be undone';
$lang['notify_32']  = 'No, nevermind';
$lang['notify_33']  = 'Yes, delete';
$lang['notify_34']  = 'Plan your first notices';
$lang['notify_35']  = 'Users will see your notification after launching app';
$lang['notify_36']  = 'Update';
$lang['notify_37']  = 'PUSH newsletter';
$lang['notify_38']  = 'List newsletters';
$lang['notify_39']  = 'Users available for newsletter';
$lang['notify_40']  = 'New newsletter';
$lang['notify_41']  = 'Added to queue';
$lang['notify_42']  = 'Title message';
$lang['notify_43']  = 'Detail';
$lang['notify_44']  = 'Planned notifications';
$lang['notify_45']  = 'PUSH message';
$lang['notify_46']  = 'Total clicked';
$lang['notify_47']  = 'Successful';
$lang['notify_48']  = 'Failed';
$lang['notify_49']  = 'Errored';
$lang['notify_50']  = 'Detail message';
$lang['notify_51']  = 'Content';