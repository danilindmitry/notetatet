<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for apps page
*/

$lang['app_1']		=	'Personal apps';
$lang['app_2']		=	'Apps';
$lang['app_3']		=	'Active apps';
$lang['app_4']		=	'Personal apps';
$lang['app_5']		=	'All apps';
$lang['app_6']		=	'Active apps';
$lang['app_7']		=	'Drafts';
$lang['app_8']		=	'Created';
$lang['app_9']		=	'Unread messages';
$lang['app_10']		=	'Unpublished comments';
$lang['app_11']		=	'Unread forms';
$lang['app_12']		=	'Unpublished forms';
$lang['app_13']		=	'Go to app';
$lang['app_14']		=	'Delete';
$lang['app_15']		=	'Delete app';
$lang['app_16']		=	'Are you sure about this? All related items and users with the application will be deleted. This action cannot be undone';
$lang['app_17']		=	'No, nevermind';
$lang['app_18']		=	'Yes, delete';
$lang['app_19']		=	'Have not published apps';
$lang['app_20']		=	'Try it - it is as easy as managing a site';
$lang['app_21']		=	'Create new app';
$lang['app_22']		=	'Create your first app';
$lang['app_23']		=	'Converted site';