<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for messages page
*/

$lang['messages_1']   = 'Messages';
$lang['messages_2']   = 'Unread';
$lang['messages_3']	  =	'All';
$lang['messages_4']	  =	'Search';
$lang['messages_5']	  =	'All dialogs';
$lang['messages_6']	  =	'Create dialogue';
$lang['messages_7']	  =	'User';
$lang['messages_8']	  =	'Last messages';
$lang['messages_9']	  =	'Total messages';
$lang['messages_10']  =	'There is nothing';
$lang['messages_11']  =	'All submitted forms will be stored here by users';
$lang['messages_12']  =	'Create new dialogue';
$lang['messages_13']	=	'Username';
$lang['messages_14']	=	'You can create only one dialog for one user';
$lang['messages_15']  =	'Create';
$lang['messages_16']  =	'Unread messages';
$lang['messages_17']  =	'No unread messages';
$lang['messages_18']  =	'All unread incoming messages from users will be displayed here';
$lang['messages_19']  =	'Refresh page';
$lang['messages_20']  =	'Request failed';
$lang['messages_21']  =	'You can search for any phrase from any messages';
$lang['messages_22']  =	'What are we looking for';
$lang['messages_23']  =	'Search results';
$lang['messages_24']  =	'Search is completed by request';
$lang['messages_25']  =	'Reset search';
$lang['messages_26']  =	'Message';
$lang['messages_27']  =	'Nothing found';
$lang['messages_28']  =	'Try changing your search and you are lucky';
$lang['messages_29']  =	'Return to search';
$lang['messages_30']  =	'Dialogue with';
$lang['messages_31']  =	'Block user';
$lang['messages_32']  =	'Clear chat';
$lang['messages_33']  =	'This user has been blocked and cannot send messages';
$lang['messages_34']  =	'Unblock user';
$lang['messages_35']  =	'Your message';
$lang['messages_36']  =	'Send';
$lang['messages_37']  =	'You';
$lang['messages_38']  =	'Error';
$lang['messages_39']  =	'The request failed. Reload the page and try again';