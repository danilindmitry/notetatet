<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
* English language for galleries page
*/

$lang['gallery_1']		=	'Galleries';
$lang['gallery_2']		=	'All galleries';
$lang['gallery_3']		=	'Search';
$lang['gallery_4']		=	'Add gallery';
$lang['gallery_5']		=	'Name';
$lang['gallery_6']		=	'Created';
$lang['gallery_7']		=	'Images';
$lang['gallery_8']		=	'Upload';
$lang['gallery_9']		=	'Delete';
$lang['gallery_10']		=	'Delete gallery';
$lang['gallery_11']		=	'Are you sure about this? This action cannot be undone';
$lang['gallery_12']		=	'No, nevermind';
$lang['gallery_13']		=	'Yes, delete';
$lang['gallery_14']		=	'Edit gallery';
$lang['gallery_15']		=	'Gallery name';
$lang['gallery_16']		=	'Default';
$lang['gallery_17']		=	'No, not now';
$lang['gallery_18']		=	'Yes, edit';
$lang['gallery_19']		=	'Create your first photo gallery';
$lang['gallery_20']		=	'Upload photos and share them with your users';
$lang['gallery_21']		=	'Create new gallery';
$lang['gallery_22']		=	'Nothing found';
$lang['gallery_23']		=	'Try changing your search and you are lucky';
$lang['gallery_24']		=	'Return to all galleries';
$lang['gallery_25']		=	'You can using for search name gallery';
$lang['gallery_26']		=	'What are we looking for';
$lang['gallery_27']		=	'Name gallery';
$lang['gallery_28']		=	'Maximum 150 characters';
$lang['gallery_29']		=	'Create';
$lang['gallery_30']		=	'Upload images for';
$lang['gallery_31']		=	'All images';
$lang['gallery_32']		=	'Add images';
$lang['gallery_33']		=	'Delete this image';
$lang['gallery_34']		=	'Upload your first images';
$lang['gallery_35']		=	'You will be able to attach images to the post or show them in photo gallery';
$lang['gallery_36']		=	'Add new images';
$lang['gallery_37']		=	'Start images upload';
$lang['gallery_38']		=	'Choose one or more images to upload. Supported JPG, PNG, JPEG and GIF formats';
$lang['gallery_39']		=	'Select images';